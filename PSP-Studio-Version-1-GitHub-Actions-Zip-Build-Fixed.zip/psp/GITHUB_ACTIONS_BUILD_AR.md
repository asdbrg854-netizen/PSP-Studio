# بناء PSP Studio عبر GitHub Actions

1. ارفع محتويات المشروع إلى مستودع GitHub.
2. افتح تبويب Actions.
3. اختر `PSP Studio Android Release`.
4. اضغط `Run workflow`.
5. بعد نجاح البناء، افتح الـworkflow ثم قسم Artifacts.
6. نزّل `PSP-Studio-v1-release`.

المشروع يستخدم Android SDK 35 وNDK 27.3.13750724 وCMake 3.22.1 في بيئة GitHub Actions.

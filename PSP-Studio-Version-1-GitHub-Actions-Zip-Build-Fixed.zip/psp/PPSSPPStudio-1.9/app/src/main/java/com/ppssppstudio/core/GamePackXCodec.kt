package com.ppssppstudio.core

import java.io.*
import java.security.MessageDigest
import java.util.zip.Deflater
import java.util.zip.Inflater

/**
 * Native Android GamePack X v1 codec.
 *
 * This implements the portable GPJ v1 container and the STORE, RLE and
 * LZ payload codecs. It is fully self-contained and does not require
 * Python or Termux. GPJ files produced here are readable by the
 * GamePack X v1 reference implementation.
 */
object GamePackXCodec {
    private val MAGIC = byteArrayOf(0x47,0x50,0x4a,0x01) // GPJ1
    private val FOOTER = byteArrayOf(0x47,0x50,0x4a,0x46) // GPJF
    private const val HEADER_SIZE = 64
    private const val ENTRY_SIZE = 68
    private const val CHUNK_SIZE = 1024 * 1024
    private const val METHOD_STORE = 0
    private const val METHOD_RLE = 1
    private const val METHOD_LZ = 2

    data class Result(val originalSize:Long, val outputSize:Long, val chunks:Int, val sha256:String)

    fun compress(input: File, output: File, level: Int = 3, progress: ((Long, Long) -> Unit)? = null, cancelled: (() -> Boolean)? = null): Result {
        require(input.isFile) { "ملف المصدر غير موجود" }
        val entries = ArrayList<Entry>()
        val payloadFile = File(output.parentFile ?: input.parentFile, ".gpx_payload_${System.nanoTime()}")
        var originalSize = 0L
        try {
            RandomAccessFile(input, "r").use { src ->
                FileOutputStream(payloadFile).use { pout ->
                    val buf = ByteArray(CHUNK_SIZE)
                    while (true) {
                        val n = src.read(buf)
                        if (n <= 0) break
                        val data = if (n == buf.size) buf.copyOf() else buf.copyOf(n)
                        if (cancelled?.invoke() == true) error("تم إلغاء العملية")
                        val best = choose(data, level)
                        val sha = sha256(data)
                        val crc = crc32c(data)
                        val offset = 0L // filled after index size is known
                        entries += Entry(best.method, 0, data.size.toLong(), best.payload.size.toLong(),
                            sha, crc, offset, 0)
                        pout.write(best.payload)
                        originalSize += n
                        progress?.invoke(originalSize, input.length())
                    }
                }
            }

            // Assign payload offsets. Header + metadata + index precede payload.
            val metadata = "GamePack X v1\n".toByteArray(Charsets.UTF_8)
            val indexOffset = HEADER_SIZE.toLong() + metadata.size
            val dataOffset = indexOffset + ENTRY_SIZE.toLong() * entries.size
            var cursor = dataOffset
            val fixed = ArrayList<Entry>(entries.size)
            for (e in entries) {
                fixed += e.copy(payloadOffset = cursor)
                cursor += e.compressedSize
            }

            // Deduplicate identical uncompressed chunks, using 1-based references.
            val seen = HashMap<String, Int>()
            val deduped = fixed.mapIndexed { i, e ->
                val key = bytesToHex(e.sha)
                val prior = seen[key]
                if (prior != null) e.copy(method = METHOD_STORE, compressedSize = 0, payloadOffset = 0, reference = (prior + 1).toLong())
                else { seen[key] = i; e }
            }

            FileOutputStream(output).use { out ->
                val header = ByteArray(HEADER_SIZE)
                put(header,0,MAGIC)
                putU16(header,4,1); putU16(header,6,0)
                putU64(header,8,originalSize)
                putU64(header,16,deduped.size.toLong())
                putU64(header,24,HEADER_SIZE.toLong()) // metadata
                putU64(header,32,indexOffset)
                putU64(header,40,dataOffset)
                putU64(header,48,cursor)
                putU64(header,56,0)
                out.write(header)
                out.write(metadata)
                for (e in deduped) writeEntry(out,e)
                FileInputStream(payloadFile).use { it.copyTo(out, 1024*1024) }
                out.flush()
            }

            val digest = sha256Prefix(output, cursor)
            RandomAccessFile(output,"rw").use { r ->
                r.seek(cursor)
                r.write(FOOTER)
                r.write(hexToBytes(digest))
            }
            return Result(originalSize, output.length(), deduped.size, digest)
        } finally { payloadFile.delete() }
    }

    fun decompress(input: File, output: File, progress: ((Long, Long) -> Unit)? = null, cancelled: (() -> Boolean)? = null): Result {
        require(input.isFile) { "ملف GPJ غير موجود" }
        RandomAccessFile(input,"r").use { r ->
            val h=ByteArray(64); r.readFully(h)
            check(h.copyOfRange(0,4).contentEquals(MAGIC)){"ليس ملف GamePack X صالحًا"}
            check(u16(h,4)==1){"إصدار GPJ غير مدعوم"}
            val original=u64(h,8); val count=u64(h,16)
            val index=u64(h,32); val data=u64(h,40); val footer=u64(h,48)
            check(count<=Int.MAX_VALUE){"عدد الكتل كبير جدًا"}
            check(index>=64 && data>=index && footer>=data && footer+36<=r.length()){"مواقع GPJ غير صالحة"}
            val stored=ByteArray(32)
            r.seek(footer+4); r.readFully(stored)
            val actual=hexToBytes(sha256Prefix(input,footer))
            check(stored.contentEquals(actual)){"فشل تحقق SHA-256 للحاوية"}

            val entries=ArrayList<Entry>(count.toInt())
            r.seek(index)
            repeat(count.toInt()) {
                val b=ByteArray(ENTRY_SIZE); r.readFully(b)
                val method=b[0].toInt() and 255
                val filter=b[1].toInt() and 255
                val flags=u16(b,2)
                val os=u64(b,4); val cs=u64(b,12)
                val sha=b.copyOfRange(20,52)
                val crc=u32(b,52)
                val off=u64(b,56); val ref=u32(b,64)
                entries += Entry(method,filter,os,cs,sha,crc,off,ref)
            }

            val chunks = arrayOfNulls<ByteArray>(entries.size)
            FileOutputStream(output).use { out ->
                var total=0L
                for (i in entries.indices) {
                    if (cancelled?.invoke() == true) error("تم إلغاء العملية")
                    val e=entries[i]
                    val dataBytes: ByteArray
                    if (e.reference != 0L) {
                        val target=(e.reference-1).toInt()
                        check(target>=0 && target<i){"مرجع GPJ غير صالح"}
                        dataBytes=chunks[target] ?: error("مرجع غير محلول")
                    } else {
                        check(e.payloadOffset>=data && e.payloadOffset+e.compressedSize<=footer){"بيانات GPJ خارج الحدود"}
                        check(e.compressedSize<=Int.MAX_VALUE){"كتلة مضغوطة كبيرة جدًا"}
                        val p=ByteArray(e.compressedSize.toInt())
                        r.seek(e.payloadOffset); r.readFully(p)
                        dataBytes=decodePayload(e.method,p,e.originalSize.toInt())
                        check(dataBytes.size.toLong()==e.originalSize){"حجم الكتلة بعد الفك غير صحيح"}
                        check(sha256(dataBytes).contentEquals(e.sha)){"فشل SHA-256 للكتلة $i"}
                        check(crc32c(dataBytes)==e.crc){"فشل CRC32C للكتلة $i"}
                    }
                    chunks[i]=dataBytes
                    out.write(dataBytes)
                    total += dataBytes.size
                    progress?.invoke(total, original)
                }
                check(total==original){"الحجم النهائي لا يطابق GPJ"}
            }
            return Result(original,output.length(),entries.size,bytesToHex(sha256(output)))
        }
    }

    fun inspect(input:File): String {
        RandomAccessFile(input,"r").use { r ->
            val h=ByteArray(64); r.readFully(h)
            check(h.copyOfRange(0,4).contentEquals(MAGIC)){"ليس GamePack X (.gpj)"}
            val count=u64(h,16)
            val methods=mutableSetOf<Int>()
            r.seek(u64(h,32))
            repeat(count.toInt()) { val b=ByteArray(ENTRY_SIZE);r.readFully(b);methods += b[0].toInt() and 255 }
            return "GPJ v1 • ${count} كتلة • الطرق: ${methods.joinToString(",")}"
        }
    }

    private data class Entry(val method:Int,val filter:Int,val originalSize:Long,val compressedSize:Long,
        val sha:ByteArray,val crc:Long,val payloadOffset:Long,val reference:Long)
    private data class Candidate(val method:Int,val payload:ByteArray)

    private fun choose(data:ByteArray, level:Int):Candidate {
        val store=data
        val rle=encodeRle(data)
        var best=Candidate(METHOD_STORE,store)
        if(rle.size<best.payload.size) best=Candidate(METHOD_RLE,rle)
        val lz=encodeLz(data, level)
        if(lz.size<best.payload.size) best=Candidate(METHOD_LZ,lz)
        return best
    }

    private fun encodeRle(data:ByteArray):ByteArray {
        val out=ByteArrayOutputStream()
        var i=0
        while(i<data.size){
            val b=data[i]
            var j=i+1
            while(j<data.size && data[j]==b && j-i<Int.MAX_VALUE) j++
            writeU32(out,(j-i).toLong());out.write(b.toInt())
            i=j
        }
        return out.toByteArray()
    }
    private fun decodeRle(p:ByteArray):ByteArray {
        require(p.size%5==0){"RLE GPJ تالف"}
        val out=ByteArrayOutputStream()
        var i=0
        while(i<p.size){
            val n=u32(p,i).toInt(); val b=p[i+4].toInt() and 255
            require(n>0){"RLE run غير صالح"}
            repeat(n){out.write(b)}
            i+=5
        }
        return out.toByteArray()
    }

    // Deterministic LZ77 compatible with GamePack X v1 raw LZ token format.
    private fun encodeLz(data:ByteArray, level:Int):ByteArray {
        if(data.size<3) return ByteArray(2*data.size){k -> if(k%2==0) 0 else data[k/2]}
        val depth=when(level){1->16;2->32;3->64;4->128;else->128}
        val nice=when(level){1->64;2->128;3->256;4->1024;else->4096}
        val chains=HashMap<Int,MutableList<Int>>()
        val out=ByteArrayOutputStream(data.size*2)
        var i=0
        while(i<data.size){
            var bestLen=0; var bestDist=0
            if(i+2<data.size){
                val key=key3(data,i)
                val chain=chains[key]
                if(chain!=null){
                    var checked=0
                    for(pos in chain.asReversed()){
                        if(checked++>=depth) break
                        val dist=i-pos
                        if(dist>65535) break
                        val limit=minOf(65535,data.size-i)
                        var ln=0
                        while(ln<limit && data[pos+ln]==data[i+ln]) ln++
                        if(ln>bestLen){bestLen=ln;bestDist=dist;if(ln>=nice)break}
                    }
                }
            }
            if(bestLen>=3){
                out.write(1);writeU16(out,bestDist);writeU16(out,bestLen)
                val end=i+bestLen
                while(i<end){
                    if(i+2<data.size) chains.getOrPut(key3(data,i)){mutableListOf()}.add(i)
                    i++
                }
            }else{
                out.write(0);out.write(data[i].toInt() and 255)
                if(i+2<data.size) chains.getOrPut(key3(data,i)){mutableListOf()}.add(i)
                i++
            }
        }
        return out.toByteArray()
    }

    private fun decodeLz(p:ByteArray, expected:Int):ByteArray {
        val out=ByteArray(expected)
        var size=0
        var i=0
        while(i<p.size){
            when(p[i++].toInt() and 255){
                0 -> {require(i<p.size && size<expected){"LZ literal ناقص"};out[size++]=p[i++]}
                1 -> {
                    require(i+4<=p.size){"LZ match ناقص"}
                    val dist=u16(p,i);val len=u16(p,i+2);i+=4
                    require(dist>0 && len>0 && dist<=size && size+len<=expected){"LZ match غير صالح"}
                    repeat(len){out[size]=out[size-dist];size++}
                }
                else -> error("طريقة LZ غير معروفة")
            }
        }
        require(size==expected){"LZ decoded size mismatch"}
        return out
    }

    private fun decodePayload(method:Int,p:ByteArray,size:Int)=when(method){
        METHOD_STORE -> { require(p.size==size){"STORE size mismatch"};p }
        METHOD_RLE -> decodeRle(p)
        METHOD_LZ -> decodeLz(p,size)
        else -> error("طريقة GPJ غير مدعومة على Android: $method")
    }

    private fun key3(b:ByteArray,i:Int):Int =
        ((b[i].toInt() and 255) shl 16) or ((b[i+1].toInt() and 255) shl 8) or (b[i+2].toInt() and 255)

    private fun sha256(b:ByteArray)=MessageDigest.getInstance("SHA-256").digest(b)
    private fun sha256(f:File):ByteArray {
        val md=MessageDigest.getInstance("SHA-256")
        f.inputStream().use { input -> val b=ByteArray(1024*1024);while(true){val n=input.read(b);if(n<=0)break;md.update(b,0,n)}}
        return md.digest()
    }
    private fun sha256Prefix(f:File,end:Long):String {
        val md=MessageDigest.getInstance("SHA-256")
        RandomAccessFile(f,"r").use { r -> r.seek(0);var left=end;val b=ByteArray(1024*1024);while(left>0){val n=r.read(b,0,minOf(left,b.size.toLong()).toInt());if(n<=0)break;md.update(b,0,n);left-=n}}
        return bytesToHex(md.digest())
    }
    private fun crc32c(data:ByteArray):Long {
        var crc=0xffffffffL
        for(x in data){
            crc=crc xor (x.toInt() and 255).toLong()
            repeat(8){crc=if((crc and 1L) != 0L)(crc ushr 1) xor 0x82f63b78L else crc ushr 1}
        }
        return crc xor 0xffffffffL
    }
    private fun writeEntry(out:OutputStream,e:Entry){
        out.write(e.method);out.write(e.filter);writeU16(out,0)
        writeU64(out,e.originalSize);writeU64(out,e.compressedSize);out.write(e.sha)
        writeU32(out,e.crc);writeU64(out,e.payloadOffset);writeU32(out,e.reference)
    }
    private fun put(b:ByteArray,o:Int,v:ByteArray){System.arraycopy(v,0,b,o,v.size)}
    private fun putU16(b:ByteArray,o:Int,v:Int){b[o]=(v and 255).toByte();b[o+1]=(v ushr 8).toByte()}
    private fun putU64(b:ByteArray,o:Int,v:Long){for(i in 0..7)b[o+i]=(v ushr (8*i)).toByte()}
    private fun u16(b:ByteArray,o:Int)=(b[o].toInt() and 255) or ((b[o+1].toInt() and 255) shl 8)
    private fun u32(b:ByteArray,o:Int):Long=(b[o].toLong() and 255) or ((b[o+1].toLong() and 255) shl 8) or ((b[o+2].toLong() and 255) shl 16) or ((b[o+3].toLong() and 255) shl 24)
    private fun u64(b:ByteArray,o:Int):Long{var x=0L;for(i in 0..7)x=x or ((b[o+i].toLong() and 255) shl (8*i));return x}
    private fun writeU16(out:OutputStream,v:Int){out.write(v and 255);out.write((v ushr 8) and 255)}
    private fun writeU32(out:OutputStream,v:Long){for(i in 0..3)out.write((v ushr (8*i)).toInt() and 255)}
    private fun writeU64(out:OutputStream,v:Long){for(i in 0..7)out.write((v ushr (8*i)).toInt() and 255)}
    private fun bytesToHex(b:ByteArray)=b.joinToString(""){String.format("%02x",it)}
    private fun hexToBytes(s:String)=ByteArray(s.length/2){s.substring(it*2,it*2+2).toInt(16).toByte()}
}

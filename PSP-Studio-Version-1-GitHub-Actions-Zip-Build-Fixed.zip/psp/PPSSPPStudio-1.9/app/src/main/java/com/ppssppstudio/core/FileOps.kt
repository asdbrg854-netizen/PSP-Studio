package com.ppssppstudio.core

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile

/** SAF file operations: works without root and supports files/directories. */
object FileOps {
    fun rename(context: Context, uri: Uri, newName: String): Boolean =
        DocumentFile.fromSingleUri(context, uri)?.renameTo(newName) ?: false

    fun delete(context: Context, uri: Uri): Boolean =
        DocumentFile.fromSingleUri(context, uri)?.delete() ?: false

    fun size(context: Context, uri: Uri): Long =
        DocumentFile.fromSingleUri(context, uri)?.length() ?: -1L

    fun copy(context: Context, source: Uri, destinationDir: Uri): Uri {
        val src = DocumentFile.fromSingleUri(context, source) ?: error("Source not found")
        val dst = DocumentFile.fromTreeUri(context, destinationDir) ?: error("Destination not found")
        return copyDocument(context, src, dst)
    }

    fun move(context: Context, source: Uri, destinationDir: Uri): Uri {
        val out = copy(context, source, destinationDir)
        if (!(DocumentFile.fromSingleUri(context, source)?.delete() ?: false)) error("Copied but could not delete source")
        return out
    }

    private fun copyDocument(context: Context, src: DocumentFile, dst: DocumentFile): Uri {
        val name = src.name ?: error("Unnamed source")
        if (src.isDirectory) {
            val target = dst.findFile(name) ?: dst.createDirectory(name) ?: error("Cannot create directory")
            src.listFiles().forEach { copyDocument(context, it, target) }
            return target.uri
        }
        val existing = dst.findFile(name)
        existing?.delete()
        val target = dst.createFile(src.type ?: "application/octet-stream", name) ?: error("Cannot create file")
        SafFs.copy(context, src.uri, target.uri)
        return target.uri
    }
}

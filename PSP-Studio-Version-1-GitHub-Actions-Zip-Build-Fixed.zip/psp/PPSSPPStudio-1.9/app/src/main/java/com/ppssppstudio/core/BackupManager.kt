package com.ppssppstudio.core

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object BackupManager {
    private const val PREF = "backup_history"
    private const val KEY = "last"
    data class Item(val relative: String, val backupUri: String)

    fun backupFiles(context: Context, gameRoot: Uri, files: List<String>): List<Item> {
        val stamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date())
        val backupRoot = SafFs.createDir(context, gameRoot, ".ppssppstudio_backup")
        val session = SafFs.createDir(context, backupRoot, stamp)
        val items = mutableListOf<Item>()
        for (rel in files.distinct()) {
            val src = SafFs.findByRelative(context, gameRoot, rel) ?: continue
            val dest = SafFs.relativeChild(context, session, rel)
            SafFs.copy(context, src.uri, dest)
            items += Item(rel, dest.toString())
        }
        val arr = JSONArray().apply { items.forEach { put(JSONObject().put("relative", it.relative).put("backupUri", it.backupUri)) } }
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, JSONObject().put("root", gameRoot.toString()).put("items", arr).toString()).apply()
        return items
    }

    fun undoLast(context: Context): Int {
        val raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null) ?: return 0
        val obj = JSONObject(raw)
        val root = Uri.parse(obj.getString("root"))
        val arr = obj.getJSONArray("items")
        var restored = 0
        for (i in 0 until arr.length()) {
            val item = arr.getJSONObject(i)
            val rel = item.getString("relative")
            val backup = Uri.parse(item.getString("backupUri"))
            val dest = SafFs.relativeChild(context, root, rel)
            SafFs.copy(context, backup, dest)
            restored++
        }
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove(KEY).apply()
        return restored
    }
}

private fun SafFs.findByRelative(context: Context, rootUri: Uri, relative: String): DocumentFile? {
    var current = DocumentFile.fromTreeUri(context, rootUri) ?: return null
    val parts = relative.replace('\\', '/').split('/').filter { it.isNotBlank() && it != "." }
    require(parts.none { it == ".." }) { "مسار غير آمن" }
    for (part in parts) {
        current = current.findFile(part) ?: return null
    }
    return current
}

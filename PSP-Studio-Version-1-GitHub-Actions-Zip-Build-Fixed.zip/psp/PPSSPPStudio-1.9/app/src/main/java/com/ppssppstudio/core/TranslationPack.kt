package com.ppssppstudio.core
import java.io.*
import java.util.zip.*
import org.json.JSONObject
object TranslationPack {
    data class Manifest(val name:String,val gameId:String?,val version:String)
    fun create(pack:File,manifest:Manifest,files:Map<String,File>){
        ZipOutputStream(BufferedOutputStream(FileOutputStream(pack))).use{z->
            val json=JSONObject().put("name",manifest.name).put("gameId",manifest.gameId).put("version",manifest.version)
            z.putNextEntry(ZipEntry("manifest.json"));z.write(json.toString(2).toByteArray());z.closeEntry()
            files.forEach{(path,f)->z.putNextEntry(ZipEntry("files/$path"));f.inputStream().use{it.copyTo(z)};z.closeEntry()}
        }
    }
    fun readManifest(pack:File):Manifest{
        ZipFile(pack).use{z->val e=z.getEntry("manifest.json")?:error("حزمة بلا manifest.json");val j=JSONObject(z.getInputStream(e).bufferedReader().readText());return Manifest(j.optString("name",""),j.optString("gameId",null),j.optString("version","1.0"))}
    }
    fun extractFiles(pack:File,dest:File){
        ZipFile(pack).use{z->z.entries().asSequence().filter{it.name.startsWith("files/")&&!it.isDirectory}.forEach{e->
            val rel=e.name.removePrefix("files/");val out=File(dest,rel);out.parentFile?.mkdirs();z.getInputStream(e).use{input->out.outputStream().use{input.copyTo(it)}}}}
    }
}

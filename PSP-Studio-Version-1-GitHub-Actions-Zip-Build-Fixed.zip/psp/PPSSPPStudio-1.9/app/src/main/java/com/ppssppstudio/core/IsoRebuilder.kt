package com.ppssppstudio.core
import java.io.*
/**
 * Safe PSP-oriented operation: replaces an existing ISO9660 file in-place only
 * when the new payload fits in its original extent. This preserves the ISO layout
 * and avoids producing a non-bootable image by blindly rebuilding UMD structures.
 */
object IsoRebuilder {
    fun replaceInPlace(iso:File,entry:IsoEntry,replacement:File){
        require(!entry.directory){"لا يمكن استبدال مجلد"}
        require(replacement.length()<=entry.size){"الملف الجديد أكبر من المساحة الأصلية؛ أعد بناء ISO كاملًا عبر أداة متخصصة"}
        RandomAccessFile(iso,"rw").use{r->r.seek(entry.extent*Iso9660.SECTOR);replacement.inputStream().use{input->val b=ByteArray(1024*1024);var left=replacement.length();while(left>0){val n=input.read(b,0,minOf(b.size,left.toInt()));if(n<0)break;r.write(b,0,n);left-=n};while(left<entry.size){val n=minOf(b.size,(entry.size-left).toInt());r.write(ByteArray(n));left+=n}}}
    }
}

package com.ppssppstudio

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.documentfile.provider.DocumentFile
import com.ppssppstudio.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.isActive
import java.util.concurrent.atomic.AtomicBoolean
import java.io.File
import java.text.DecimalFormat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { Studio(this) } }
}

private enum class Screen { FILES, COMPRESS, PATCH, TRANSLATIONS, TOOLS }
private fun tr(ar: String, en: String, english: Boolean): String = if (english) en else ar
private val LocalEnglish = compositionLocalOf { false }
private enum class Pending { NONE, CSO, ISO, GPJ, UNGPJ, PATCH, ISO_EXTRACT, ISO_REPLACE }
private enum class FileAction { NONE, COPY, MOVE }
private data class NodeRow(val uri: Uri, val name: String, val dir: Boolean, val size: Long, val type: String?)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun Studio(context: Context) {
    val scope = rememberCoroutineScope()
    var screen by remember { mutableStateOf(Screen.FILES) }
    val prefs = remember { context.getSharedPreferences("settings", Context.MODE_PRIVATE) }
    var english by remember { mutableStateOf(prefs.getBoolean("english", false)) }
    var multiSelect by remember { mutableStateOf(false) }
    val selectedUris = remember { mutableStateListOf<Uri>() }
    var fileAction by remember { mutableStateOf(FileAction.NONE) }
    var renameNode by remember { mutableStateOf<NodeRow?>(null) }
    var renameText by remember { mutableStateOf("") }
    var refreshTick by remember { mutableStateOf(0) }
    var rootUri by remember { mutableStateOf<Uri?>(null) }
    var currentUri by remember { mutableStateOf<Uri?>(null) }
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedName by remember { mutableStateOf("") }
    var patchUri by remember { mutableStateOf<Uri?>(null) }
    var gameUri by remember { mutableStateOf<Uri?>(null) }
    var translationUri by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf(tr("جاهز","Ready",english)) }
    var progress by remember { mutableStateOf(-1f) }
    var busy by remember { mutableStateOf(false) }
    var quality by remember { mutableStateOf(1) }
    var pending by remember { mutableStateOf(Pending.NONE) }
    var showMenu by remember { mutableStateOf(false) }
    var showFileMenu by remember { mutableStateOf(false) }
    var menuNode by remember { mutableStateOf<NodeRow?>(null) }
    var showPatchPicker by remember { mutableStateOf(false) }
    var showLogs by remember { mutableStateOf(false) }
    var showIso by remember { mutableStateOf(false) }
    var isoEntries by remember { mutableStateOf<List<IsoEntry>>(emptyList()) }
    var isoSelected by remember { mutableStateOf<IsoEntry?>(null) }
    var isoExtractMode by remember { mutableStateOf(false) }
    var replacementUri by remember { mutableStateOf<Uri?>(null) }
    var info by remember { mutableStateOf("") }
    var job by remember { mutableStateOf<Job?>(null) }
    val cancelFlag = remember { AtomicBoolean(false) }

    fun setBusy(v: Boolean) { busy = v; if (!v) progress = -1f }
    fun pickFile(mimes: Array<String>, callback: (Uri?) -> Unit) = Unit

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { selectedUri = uri; selectedName = DocumentFile.fromSingleUri(context, uri)?.name ?: tr("ملف","File",LocalEnglish.current); status = "تم اختيار $selectedName" }
    }
    val patchPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { patchUri = uri; status = "تم اختيار Patch: ${DocumentFile.fromSingleUri(context, uri)?.name ?: "Patch"}" }
    }
    val translationPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { translationUri = uri; status = tr("تم اختيار حزمة الترجمة","Translation pack selected",english) }
    }
    val replacementPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { replacementUri = uri; status = tr("تم اختيار ملف الاستبدال","Replacement file selected",english) }
    }
    val treePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, IntentFlags.READ_WRITE) } catch (_: Throwable) {}
            rootUri = uri; currentUri = uri; gameUri = uri; status = tr("تم اختيار مجلد اللعبة","Game folder selected",english); OperationLog.add(context,tr("مجلد","Folder",LocalEnglish.current),tr("تم تحديد مجلد لعبة","Game folder selected",english),true)
        }
    }
    val destinationPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, IntentFlags.READ_WRITE) } catch (_: Throwable) {}
            val action = fileAction
            val targets = selectedUris.toList()
            scope.launch {
                busy = true
                try {
                    withContext(Dispatchers.IO) { targets.forEach { u -> if (action == FileAction.COPY) FileOps.copy(context, u, uri) else FileOps.move(context, u, uri) } }
                    val label = if (action == FileAction.COPY) tr("نسخ","Copy",english) else tr("نقل","Move",english)
                    status = "$label: ${targets.size}"
                    OperationLog.add(context,label,"${targets.size} ${tr("عنصر","items",english)}",true)
                    selectedUris.clear(); multiSelect=false
                } catch (e: Throwable) {
                    status = "${tr("فشل","Failed",english)}: ${e.message}"
                    OperationLog.add(context,tr("إدارة الملفات","File Manager",english),e.message ?: "Error",false)
                } finally { busy=false; fileAction=FileAction.NONE; refreshFiles() }
            }
        } else fileAction = FileAction.NONE
    }
    val outputPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { outUri ->
        if (outUri == null) { pending = Pending.NONE; return@rememberLauncherForActivityResult }
        val inUri = selectedUri
        val patch = patchUri
        val p = pending
        if (inUri == null && p != Pending.PATCH) { status = tr("اختر ملف المصدر أولًا","Choose the source file first",english); pending = Pending.NONE; return@rememberLauncherForActivityResult }
        job?.cancel()
        cancelFlag.set(false)
        job = scope.launch {
            busy = true; progress = 0f
            val tmpIn = File.createTempFile("pp_in_", ".bin", context.cacheDir)
            val tmpOut = File.createTempFile("pp_out_", ".bin", context.cacheDir)
            try {
                when (p) {
                    Pending.CSO, Pending.ISO -> {
                        SafFs.copyToFile(context, inUri!!, tmpIn) { d,t -> progress = if(t>0) d.toFloat()/t else -1f }
                        status = if (p==Pending.CSO) tr("ضغط ISO → CSO…","Compressing ISO → CSO…",english) else tr("فك CSO/ZSO → ISO…","Decompressing CSO/ZSO → ISO…",english)
                        withContext(Dispatchers.IO) { NativeBridge.convert(tmpIn.absolutePath,tmpOut.absolutePath,if(p==Pending.ISO) 1 else 0,quality) }
                            .also { result -> if(result != "OK") error(result) }
                        SafFs.copyFromFile(context,tmpOut,outUri) { d,t -> progress=if(t>0)d.toFloat()/t else -1f }
                        status = tr("اكتملت العملية","Operation completed",english)
                        OperationLog.add(context, if(p==Pending.CSO) "ISO → CSO" else "CSO → ISO", selectedName, true)
                    }
                    Pending.GPJ -> {
                        SafFs.copyToFile(context,inUri!!,tmpIn)
                        status=tr("ضغط GamePack X…","Compressing GamePack X…",english)
                        withContext(Dispatchers.IO) { GamePackXCodec.compress(tmpIn,tmpOut,quality+2,{d,t -> progress=if(t>0)d.toFloat()/t else -1f},{cancelFlag.get()}) }
                        SafFs.copyFromFile(context,tmpOut,outUri)
                        status=tr("تم إنشاء GPJ","GPJ created",english); OperationLog.add(context,"GamePack X","تم ضغط $selectedName",true)
                    }
                    Pending.UNGPJ -> {
                        SafFs.copyToFile(context,inUri!!,tmpIn)
                        status=tr("فك GamePack X…","Decompressing GamePack X…",english)
                        withContext(Dispatchers.IO) { GamePackXCodec.decompress(tmpIn,tmpOut,{d,t -> progress=if(t>0)d.toFloat()/t else -1f},{cancelFlag.get()}) }
                        SafFs.copyFromFile(context,tmpOut,outUri)
                        status=tr("تم فك GPJ","GPJ decompressed",english); OperationLog.add(context,"GamePack X","تم فك $selectedName",true)
                    }
                    Pending.ISO_EXTRACT -> {
                        require(inUri != null && isoSelected != null) { tr("اختر ISO وملفًا من المستكشف","Choose an ISO and a file in the explorer",english) }
                        SafFs.copyToFile(context,inUri,tmpIn)
                        val entry = isoSelected!!
                        status = "استخراج ${entry.path}…"
                        withContext(Dispatchers.IO) { Iso9660(tmpIn).extract(entry,tmpOut) }
                        SafFs.copyFromFile(context,tmpOut,outUri)
                        status = tr("تم استخراج الملف","File extracted",english); OperationLog.add(context,"ISO","استخراج ${entry.path}",true)
                    }
                    Pending.ISO_REPLACE -> {
                        require(inUri != null && isoSelected != null && replacementUri != null) { tr("اختر ISO والملف البديل","Choose an ISO and replacement file",english) }
                        SafFs.copyToFile(context,inUri,tmpIn)
                        val tmpRep=File.createTempFile("pp_rep_",".bin",context.cacheDir)
                        try {
                            SafFs.copyToFile(context,replacementUri!!,tmpRep)
                            withContext(Dispatchers.IO) { IsoRebuilder.replaceInPlace(tmpIn,isoSelected!!,tmpRep) }
                            SafFs.copyFromFile(context,tmpIn,outUri)
                            status="تم استبدال ${isoSelected!!.path}"; OperationLog.add(context,"ISO","استبدال ${isoSelected!!.path}",true)
                        } finally { tmpRep.delete() }
                    }
                    Pending.PATCH -> {
                        require(patch != null) { tr("اختر ملف Patch","Choose a Patch file",english) }
                        SafFs.copyToFile(context,inUri!!,tmpIn)
                        val tmpPatch=File.createTempFile("pp_patch_", ".bin", context.cacheDir)
                        try {
                            SafFs.copyToFile(context,patch,tmpPatch)
                            val kind=PatchEngine.detect(DocumentFile.fromSingleUri(context,patch)?.name ?: "") ?: error(tr("صيغة Patch غير مدعومة","Unsupported Patch format",english))
                            status="تطبيق ${kind.name}…"
                            withContext(Dispatchers.IO) { PatchEngine.apply(kind,tmpIn,tmpPatch,tmpOut) }
                            SafFs.copyFromFile(context,tmpOut,outUri)
                            status=tr("تم تطبيق Patch بنجاح","Patch applied successfully",english); OperationLog.add(context,"Patch",kind.name,true)
                        } finally { tmpPatch.delete() }
                    }
                    else -> Unit
                }
            } catch (e: Throwable) {
                status="فشل: ${e.message ?: "خطأ غير معروف"}"; OperationLog.add(context,tr("عملية","Operation",english),e.message ?: tr("فشل","Failed",english),false)
            } finally { tmpIn.delete(); tmpOut.delete(); pending=Pending.NONE; busy=false; progress=-1f }
        }
    }

    fun refreshFiles() { refreshTick++ }
    val nodes = remember(currentUri, busy, status) { mutableStateListOf<NodeRow>() }
    LaunchedEffect(currentUri, refreshTick) {
        if (currentUri != null) {
            nodes.clear(); nodes.addAll(withContext(Dispatchers.IO) { SafFs.list(context,currentUri!!).map { NodeRow(it.uri,it.name,it.dir,it.size,it.mime) } })
        }
    }

    CompositionLocalProvider(LocalEnglish provides english, LocalLayoutDirection provides if (english) LayoutDirection.Ltr else LayoutDirection.Rtl) {
    Scaffold(
        topBar={
            TopAppBar(
                title={
                    Column {
                        Text(
                            if (screen == Screen.FILES) currentUri?.let { DocumentFile.fromTreeUri(context,it)?.name ?: tr("مدير الملفات","File Manager",english) } ?: tr("مدير الملفات","File Manager",english)
                            else when(screen){Screen.COMPRESS->tr("ضغط وفك الضغط","Compress / Decompress",english);Screen.PATCH->"Patch";Screen.TRANSLATIONS->tr("تركيب الترجمات","Install Translations",english);Screen.TOOLS->tr("أدوات","Tools",english);else->"PSP Studio"},
                            fontWeight=FontWeight.SemiBold, maxLines=1
                        )
                        if (screen == Screen.FILES) Text("PSP Studio",fontSize=11.sp)
                    }
                },
                navigationIcon={
                    if (screen == Screen.FILES && currentUri != null && currentUri != rootUri) {
                        IconButton(onClick={onUpOne(context,currentUri){ currentUri=it }}) { Icon(Icons.Default.ArrowBack,null) }
                    }
                },
                actions={
                    TextButton(onClick={ english = !english; prefs.edit().putBoolean("english", english).apply() }) { Text(if (english) "AR" else "EN", fontWeight=FontWeight.Bold) }
                    IconButton(onClick={showMenu=true}) { Icon(Icons.Default.MoreVert,null) }
                    DropdownMenu(expanded=showMenu,onDismissRequest={showMenu=false}) {
                        DropdownMenuItem(text={Text(tr("اختيار ملف","Choose File",english))},onClick={showMenu=false;filePicker.launch(arrayOf("*/*"))})
                        DropdownMenuItem(text={Text(tr("اختيار مجلد","Choose Folder",LocalEnglish.current))},onClick={showMenu=false;treePicker.launch(null)})
                        DropdownMenuItem(text={Text(tr("تحديد متعدد","Multi-select",english))},onClick={showMenu=false;multiSelect=true})
                        DropdownMenuItem(text={Text(tr("سجل العمليات","Operation Log",english))},onClick={showMenu=false;showLogs=true})
                    }
                }
            )
        },
        bottomBar={NavigationBar{Nav(Screen.FILES,tr("ملفات","Files",english),Icons.Default.Folder,screen){screen=it};Nav(Screen.COMPRESS,tr("ضغط","Compress",english),Icons.Default.Archive,screen){screen=it};Nav(Screen.PATCH,"Patch",Icons.Default.Build,screen){screen=it};Nav(Screen.TRANSLATIONS,tr("ترجمات","Translations",english),Icons.Default.Language,screen){screen=it};Nav(Screen.TOOLS,tr("أدوات","Tools",english),Icons.Default.Settings,screen){screen=it}}},
        floatingActionButton={if(screen==Screen.FILES)FloatingActionButton(onClick={filePicker.launch(arrayOf("*/*"))}){Icon(Icons.Default.Add,null)}}
    ){ pad ->
        if (screen == Screen.FILES && selectedUris.isNotEmpty()) {
            Surface(Modifier.fillMaxWidth().padding(pad).padding(horizontal=10.dp), tonalElevation=3.dp) {
                Row(Modifier.padding(8.dp), verticalAlignment=Alignment.CenterVertically) {
                    Text("${selectedUris.size} ${tr("محدد","selected",english)}", Modifier.weight(1f), fontWeight=FontWeight.SemiBold)
                    TextButton(onClick={fileAction=FileAction.COPY;destinationPicker.launch(null)}) { Text(tr("نسخ","Copy",english)) }
                    TextButton(onClick={fileAction=FileAction.MOVE;destinationPicker.launch(null)}) { Text(tr("نقل","Move",english)) }
                    TextButton(onClick={
                        val targets=selectedUris.toList(); scope.launch { busy=true; try { withContext(Dispatchers.IO){ targets.forEach{ FileOps.delete(context,it) } }; status="${tr("تم حذف","Deleted",english)} ${targets.size}"; OperationLog.add(context,tr("حذف","Delete",english),"${targets.size}",true); selectedUris.clear(); multiSelect=false } catch(e:Throwable){status="${tr("فشل الحذف","Delete failed",english)}: ${e.message}";OperationLog.add(context,"Delete",e.message ?: "Error",false)} finally {busy=false;refreshFiles()} }
                    }) { Text(tr("حذف","Delete",english)) }
                    TextButton(onClick={selectedUris.clear();multiSelect=false}) { Text(tr("إلغاء","Cancel",english)) }
                }
            }
        }
        LazyColumn(Modifier.fillMaxSize().padding(pad),contentPadding=PaddingValues(10.dp,8.dp,10.dp,88.dp),verticalArrangement=Arrangement.spacedBy(3.dp)) {
            when(screen) {
                Screen.FILES -> {
                    item { StorageHeader(currentUri, context, nodes) }
                    item { PathCrumbs(currentUri, rootUri, context) { if (it != null) currentUri = it } }
                    if(currentUri==null) item { EmptyFiles { treePicker.launch(null) } }
                    else if(nodes.isEmpty()) item { EmptyFolder() }
                    else items(nodes, key={it.uri.toString()}) { n ->
                        FileManagerRow(n, selectedUris.contains(n.uri), multiSelect,
                            onOpen={ if(n.dir) currentUri=n.uri else { if(multiSelect){ if(selectedUris.contains(n.uri)) selectedUris.remove(n.uri) else selectedUris.add(n.uri) } else { selectedUri=n.uri; selectedName=n.name; status="تم تحديد ${n.name}" } } },
                            onMenu={ menuNode=n; showFileMenu=true }
                        )
                    }
                }
                Screen.COMPRESS -> {
                    item{Header(tr("ضغط وفك الضغط","Compress / Decompress",english),tr("تنفيذ maxcso و GamePack X على الملفات الحقيقية","Run maxcso and GamePack X on real files",english))}
                    item{PickRow(tr("ملف المصدر","Source file",english),selectedName){filePicker.launch(arrayOf("*/*"))}}
                    item{Quality(quality){quality=it}}
                    item{Action("ISO → CSO","maxcso",Icons.Default.ArrowDownward,selectedUri!=null&&!busy){pending=Pending.CSO;outputPicker.launch("game.cso")}}
                    item{Action("CSO / ZSO → ISO","maxcso",Icons.Default.ArrowUpward,selectedUri!=null&&!busy){pending=Pending.ISO;outputPicker.launch("game.iso")}}
                    item{Action(tr("ملف → GPJ","File → GPJ",english),"GamePack X v1",Icons.Default.Archive,selectedUri!=null&&!busy){pending=Pending.GPJ;outputPicker.launch("game.gpj")}}
                    item{Action(tr("GPJ → ملف","GPJ → File",english),"GamePack X v1",Icons.Default.Unarchive,selectedUri!=null&&!busy){pending=Pending.UNGPJ;outputPicker.launch("restored.bin")}}
                    item{ProgressCard(status,progress,busy){cancelFlag.set(true);job?.cancel()}}
                }
                Screen.PATCH -> {
                    item{Header("Patch",tr("IPS و UPS فعليان + مسار XDelta3","Real IPS/UPS + XDelta3 path",english))}
                    item{PickRow(tr("ملف اللعبة","Game file",english),selectedName){filePicker.launch(arrayOf("*/*"))}}
                    item{PickRow(tr("ملف Patch","Patch file",english),patchUri?.let{DocumentFile.fromSingleUri(context,it)?.name ?: "Patch"} ?: tr("لم يتم اختيار Patch","No Patch selected",english)){patchPicker.launch(arrayOf("*/*"))}}
                    item{Action(tr("تطبيق Patch","Apply Patch",english),tr("اختر IPS / UPS / XDelta ثم حدد ملف الإخراج","Choose IPS / UPS / XDelta, then select the output file",english),Icons.Default.Build,selectedUri!=null&&patchUri!=null&&!busy){pending=Pending.PATCH;outputPicker.launch("patched.bin")}}
                    item{Action(tr("فحص Patch","Check Patch",english),tr("اكتشاف الصيغة قبل التطبيق","Detect format before applying",english),Icons.Default.Info,patchUri!=null&&!busy){status="الصيغة: ${PatchEngine.detect(DocumentFile.fromSingleUri(context,patchUri!!)?.name ?: "") ?: tr("غير معروفة","Unknown",english)}"}}
                    item{ProgressCard(status,progress,busy){cancelFlag.set(true);job?.cancel()}}
                }
                Screen.TRANSLATIONS -> {
                    item{Header(tr("تركيب الترجمات","Install Translations",english),tr("حزمة ترجمة تُركّب داخل مجلد اللعبة مع فحص المسارات ونسخة احتياطية","Translation pack installed into the game folder with path validation and backup",english))}
                    item{PickRow(tr("حزمة الترجمة","Translation pack",english),translationUri?.let{DocumentFile.fromSingleUri(context,it)?.name ?: tr("حزمة","Pack",english)} ?: tr("لم يتم اختيار حزمة","No pack selected",english)){translationPicker.launch(arrayOf("application/zip","application/octet-stream","*/*"))}}
                    item{PickRow(tr("مجلد اللعبة","Game folder",english),gameUri?.let{DocumentFile.fromTreeUri(context,it)?.name ?: tr("مجلد","Folder",LocalEnglish.current)} ?: tr("لم يتم اختيار مجلد","No folder selected",english)){treePicker.launch(null)}}
                    item{Action(tr("فحص الحزمة","Check pack",english),tr("عرض Game ID والملفات قبل التركيب","Show Game ID and files before installation",english),Icons.Default.Verified,translationUri!=null&&!busy){scope.launch{try{val plan=withContext(Dispatchers.IO){TranslationInstaller.inspect(context,translationUri!!)};status="${plan.manifest.name} • Game ID: ${plan.manifest.gameId ?: tr("غير محدد","Not selected",english)} • ${plan.files.size} ملف"}catch(e:Throwable){status="فشل الفحص: ${e.message}"}}}}
                    item{Action(tr("تركيب الترجمة","Install Translation",english),tr("Backup للملفات المستبدلة + نسخ آمن","Backup replaced files + safe copy",english),Icons.Default.InstallMobile,translationUri!=null&&gameUri!=null&&!busy){scope.launch{busy=true;progress=0f;try{val count=withContext(Dispatchers.IO){TranslationInstaller.install(context,translationUri!!,gameUri!!){p,rel->progress=p/100f;status="تركيب: $rel"}};status="تم تركيب $count ملفًا";OperationLog.add(context,tr("ترجمة","Translation",english),tr("تم تركيب الحزمة","Pack installed",english),true)}catch(e:Throwable){status="فشل التركيب: ${e.message}";OperationLog.add(context,tr("ترجمة","Translation",english),e.message ?: tr("فشل","Failed",english),false)}finally{busy=false;progress=-1f}}}}
                    item{Action(tr("تراجع عن آخر Backup","Undo last backup",english),tr("استعادة الملفات التي تم استبدالها","Restore replaced files",english),Icons.Default.Undo, !busy){scope.launch{busy=true;try{val n=withContext(Dispatchers.IO){BackupManager.undoLast(context)};status="تمت استعادة $n ملفًا";OperationLog.add(context,"Undo",tr("استعادة Backup","Restore Backup",english),true)}catch(e:Throwable){status="لا يوجد Backup قابل للاستعادة: ${e.message}"}finally{busy=false}}}}
                    item{ProgressCard(status,progress,busy){cancelFlag.set(true);job?.cancel()}}
                }
                Screen.TOOLS -> {
                    item{Header(tr("أدوات","Tools",english),tr("فحص اللعبة ومستكشف ISO وسجل العمليات","Game check, ISO explorer and operation log",english))}
                    item{PickRow(tr("ISO / ملف اللعبة","ISO / Game file",english),selectedName){filePicker.launch(arrayOf("*/*"))}}
                    item{Action(tr("معلومات اللعبة","Game Info",english),tr("Game ID من PSP_GAME/PARAM.SFO","Game ID from PSP_GAME/PARAM.SFO",english),Icons.Default.Info,selectedUri!=null&&!busy){scope.launch{busy=true;try{val f=File.createTempFile("info_",".iso",context.cacheDir);SafFs.copyToFile(context,selectedUri!!,f);info="Game ID: ${PspInfo.gameId(f) ?: tr("غير موجود","Not found",english)}";status=info;f.delete()}catch(e:Throwable){status="فشل: ${e.message}"}finally{busy=false}}}}
                    item{Action(tr("التحقق SHA-256","SHA-256 verification",english),tr("حساب بصمة الملف المحدد","Calculate the selected file hash",english),Icons.Default.Verified,selectedUri!=null&&!busy){scope.launch{busy=true;try{val f=File.createTempFile("hash_",".bin",context.cacheDir);SafFs.copyToFile(context,selectedUri!!,f);status="SHA-256: ${Hashes.sha256(f)}";f.delete()}catch(e:Throwable){status="فشل: ${e.message}"}finally{busy=false}}}}
                    item{Action(tr("مستكشف ISO","ISO Explorer",english),tr("عرض مسارات ISO9660 واستخراج الملفات","Browse ISO9660 paths and extract files",english),Icons.Default.FolderOpen,selectedUri!=null&&!busy){scope.launch{busy=true;try{val f=File.createTempFile("iso_",".iso",context.cacheDir);SafFs.copyToFile(context,selectedUri!!,f);isoEntries=withContext(Dispatchers.IO){Iso9660(f).list()};showIso=true;f.delete()}catch(e:Throwable){status="فشل قراءة ISO: ${e.message}"}finally{busy=false}}}}
                    item{Action("استخراج الملف المحدد","اختر ملفًا من مستكشف ISO ثم حدد مكان الحفظ",Icons.Default.FileDownload,selectedUri!=null&&isoSelected!=null&&!busy){pending=Pending.ISO_EXTRACT;outputPicker.launch(isoSelected!!.path.substringAfterLast('/'))}}
                    item{Action("استبدال ملف داخل ISO","الاستبدال الآمن فقط إذا كان الحجم الجديد لا يتجاوز المساحة الأصلية",Icons.Default.Edit,selectedUri!=null&&isoSelected!=null&&replacementUri!=null&&!busy){pending=Pending.ISO_REPLACE;outputPicker.launch("patched.iso")}}
                    item{PickRow("ملف بديل داخل ISO",replacementUri?.let{DocumentFile.fromSingleUri(context,it)?.name ?: tr("ملف","File",LocalEnglish.current)} ?: "اختياري للاستبدال"){replacementPicker.launch(arrayOf("*/*"))}}
                    item{Action(tr("سجل العمليات","Operation Log",english),"آخر 50 عملية",Icons.Default.History,true){showLogs=true}}
                    item{ProgressCard(status,progress,busy){cancelFlag.set(true);job?.cancel()}}
                }
            }
        }
    }
    if(showFileMenu && menuNode != null) {
        val n = menuNode!!
        AlertDialog(
            onDismissRequest={showFileMenu=false},
            title={Text(n.name,maxLines=2)},
            text={Column {
                Text(if(n.dir) tr("مجلد","Folder",LocalEnglish.current) else "${human(n.size)} • ${n.type ?: tr("ملف","File",LocalEnglish.current)}",fontSize=12.sp)
                Spacer(Modifier.height(10.dp))
                Text(if(n.dir) tr("مجلد","Folder",LocalEnglish.current) else tr("ملف","File",LocalEnglish.current),fontSize=12.sp)
                if (!n.dir) {
                    TextButton(onClick={ showFileMenu=false; renameNode=n; renameText=n.name }) { Text(tr("إعادة تسمية","Rename",english)) }
                }
                TextButton(onClick={ showFileMenu=false; scope.launch { try { withContext(Dispatchers.IO){FileOps.delete(context,n.uri)}; status=tr("تم الحذف","Deleted",english); OperationLog.add(context,"Delete",n.name,true); refreshFiles() } catch(e:Throwable){status="${tr("فشل","Failed",english)}: ${e.message}";OperationLog.add(context,"Delete",e.message ?: "Error",false)} } }) { Text(tr("حذف","Delete",english)) }
            }},
            confirmButton={TextButton(onClick={
                showFileMenu=false
                if(n.dir) currentUri=n.uri else { selectedUri=n.uri; selectedName=n.name; status="تم تحديد ${n.name}" }
            }){Text(if(n.dir) tr("فتح المجلد","Open folder",english) else tr("تحديد","Select",english))}},
            dismissButton={TextButton(onClick={showFileMenu=false}){Text(tr("إلغاء","Cancel",english))}}
        )
    }
    if(renameNode != null) AlertDialog(onDismissRequest={renameNode=null}, title={Text(tr("إعادة تسمية","Rename",english))}, text={ OutlinedTextField(value=renameText,onValueChange={renameText=it},singleLine=true) }, confirmButton={ TextButton(onClick={ val n=renameNode!!; scope.launch{ try { require(renameText.isNotBlank() && !renameText.contains('/')); val ok=withContext(Dispatchers.IO){FileOps.rename(context,n.uri,renameText)}; require(ok); status=tr("تمت إعادة التسمية","Renamed successfully",english); OperationLog.add(context,"Rename","${n.name} → $renameText",true); renameNode=null; refreshFiles() } catch(e:Throwable){status="${tr("فشل","Failed",english)}: ${e.message}";OperationLog.add(context,"Rename",e.message ?: "Error",false)} } }){Text(tr("حفظ","Save",english))}}, dismissButton={TextButton(onClick={renameNode=null}){Text(tr("إلغاء","Cancel",english))}})
    if(showLogs)AlertDialog(onDismissRequest={showLogs=false},title={Text(tr("سجل العمليات","Operation Log",english))},text={LazyColumn{items(OperationLog.read(context)){Text(it,Modifier.padding(vertical=5.dp),fontSize=13.sp)}}},confirmButton={TextButton(onClick={showLogs=false}){Text("إغلاق")}})
    if(showIso)AlertDialog(onDismissRequest={showIso=false},title={Text(tr("مستكشف ISO","ISO Explorer",english))},text={Column{Text("حدد ملفًا لاستخراجه أو استبداله",fontSize=12.sp);LazyColumn(Modifier.heightIn(max=420.dp)){items(isoEntries.filter{!it.directory}){e->ListItem(headlineContent={Text(e.path,maxLines=1)},supportingContent={Text(human(e.size))},leadingContent={Icon(Icons.Default.InsertDriveFile,null)},modifier=Modifier.clickable{isoSelected=e;showIso=false;status="تم تحديد ${e.path}"})}}}},confirmButton={TextButton(onClick={showIso=false}){Text("إغلاق")}})
    }
}

private object IntentFlags { const val READ_WRITE = 3 }
@Composable private fun Nav(s:Screen,l:String,i:androidx.compose.ui.graphics.vector.ImageVector,c:Screen,on:(Screen)->Unit){
    NavigationBar {
        NavigationBarItem(selected=s==c,onClick={on(s)},icon={Icon(i,null)},label={Text(l,fontSize=10.sp)})
    }
}

@Composable private fun StorageHeader(uri:Uri?, context:Context, nodes:List<NodeRow>) {
    val files = nodes.count { !it.dir }
    val folders = nodes.count { it.dir }
    Surface(Modifier.fillMaxWidth(), tonalElevation=0.dp) {
        Column(Modifier.padding(horizontal=4.dp, vertical=6.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Default.Storage, null, Modifier.size(22.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(uri?.let { DocumentFile.fromTreeUri(context,it)?.name ?: tr("التخزين","Storage",LocalEnglish.current) } ?: tr("التخزين الداخلي","Internal storage",LocalEnglish.current), fontWeight=FontWeight.Medium)
                    Text(if (LocalEnglish.current) "$folders folders • $files files" else "$folders مجلد • $files ملف", fontSize=11.sp)
                }
            }
        }
    }
}

@Composable private fun PathCrumbs(uri:Uri?, root:Uri?, context:Context, onUp:(Uri?)->Unit) {
    Surface(Modifier.fillMaxWidth(), tonalElevation=1.dp, shape=RoundedCornerShape(4.dp)) {
        Row(Modifier.padding(horizontal=10.dp, vertical=7.dp), verticalAlignment=Alignment.CenterVertically) {
            Icon(Icons.Default.FolderOpen, null, Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(uri?.let { DocumentFile.fromTreeUri(context,it)?.name ?: tr("المجلد الحالي","Current folder",LocalEnglish.current) } ?: tr("اختر مجلدًا","Choose a folder",LocalEnglish.current), Modifier.weight(1f), fontSize=13.sp, maxLines=1)
            if (uri != null && uri != root) {
                TextButton(onClick={onUp(root)}) { Text(tr("الرئيسي","Root",LocalEnglish.current), fontSize=11.sp) }
            }
        }
    }
}

private fun onUpOne(context:Context, uri:Uri?, on:(Uri?)->Unit):()->Unit = {
    if (uri != null) {
        val doc = DocumentFile.fromTreeUri(context, uri)
        if (doc != null) on(doc.parentFile?.uri)
    }
}

@Composable private fun EmptyFiles(on:()->Unit){
    Column(Modifier.fillMaxWidth().padding(55.dp),horizontalAlignment=Alignment.CenterHorizontally){
        Icon(Icons.Default.FolderOpen,null,Modifier.size(52.dp))
        Text(tr("لا يوجد مجلد مفتوح","No folder open",LocalEnglish.current),Modifier.padding(top=12.dp),fontWeight=FontWeight.Medium)
        Text(tr("اختر مجلد التخزين لبدء التصفح","Choose a storage folder to start browsing",LocalEnglish.current),Modifier.padding(top=4.dp),fontSize=12.sp)
        OutlinedButton(onClick=on,Modifier.padding(top=14.dp)){Text(tr("اختيار مجلد","Choose Folder",LocalEnglish.current))}
    }
}

@Composable private fun EmptyFolder(){
    Column(Modifier.fillMaxWidth().padding(45.dp),horizontalAlignment=Alignment.CenterHorizontally){
        Icon(Icons.Default.FolderOpen,null,Modifier.size(44.dp))
        Text(tr("المجلد فارغ","Folder is empty",LocalEnglish.current),Modifier.padding(top=10.dp),fontSize=14.sp)
    }
}

@Composable private fun FileManagerRow(n:NodeRow, selected:Boolean, multiSelect:Boolean, onOpen:()->Unit, onMenu:()->Unit){
    val icon = when {
        n.dir -> Icons.Default.Folder
        n.name.endsWith(".iso",true) -> Icons.Default.InsertDriveFile
        n.name.endsWith(".cso",true) || n.name.endsWith(".zso",true) -> Icons.Default.Archive
        n.name.endsWith(".gpj",true) || n.name.endsWith(".7z",true) || n.name.endsWith(".zip",true) -> Icons.Default.Archive
        n.name.endsWith(".ips",true) || n.name.endsWith(".ups",true) || n.name.endsWith(".xdelta",true) || n.name.endsWith(".xdelta3",true) -> Icons.Default.Build
        else -> Icons.Default.InsertDriveFile
    }
    ListItem(
        headlineContent={Text(n.name,maxLines=1,fontWeight=if(selected) FontWeight.SemiBold else FontWeight.Normal)},
        supportingContent={Text(if(n.dir) tr("مجلد","Folder",LocalEnglish.current) else "${human(n.size)}${if(n.type!=null) " • ${n.type}" else ""}",fontSize=11.sp)},
        leadingContent={ if(multiSelect){ Checkbox(checked=selected,onCheckedChange={onOpen()}) } else Icon(icon,null,Modifier.size(28.dp)) },
        trailingContent={IconButton(onClick=onMenu){Icon(Icons.Default.MoreVert,tr("خيارات","Options",LocalEnglish.current))}},
        modifier=Modifier.clickable(onClick=onOpen)
    )
    HorizontalDivider()
}

private fun human(n:Long):String{if(n<1024)return "$n B";val units=arrayOf("KB","MB","GB","TB");var x=n.toDouble();var i=0;while(x>=1024&&i<units.lastIndex){x/=1024;i++};return DecimalFormat("0.##").format(x)+" "+units[i]}

package com.ppssppstudio.core
import java.io.File

object GamePackX {
    data class Info(val version:Int,val originalSize:Long,val chunks:Long,val methods:Set<Int>,val sha256:String)
    fun inspect(file:File):Info {
        val text=GamePackXCodec.inspect(file)
        val parts=text.split("•")
        val count=parts.getOrNull(1)?.trim()?.split(" ")?.firstOrNull()?.toLongOrNull() ?: 0
        val methods=parts.getOrNull(2)?.substringAfter(":")?.split(",")?.mapNotNull{it.trim().toIntOrNull()}?.toSet() ?: emptySet()
        return Info(1,0,count,methods,"")
    }
}

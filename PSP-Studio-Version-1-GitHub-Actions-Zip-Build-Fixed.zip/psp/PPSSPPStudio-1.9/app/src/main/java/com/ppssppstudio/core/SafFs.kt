package com.ppssppstudio.core

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream

/** SAF-backed file manager. Never assumes a raw filesystem path for user storage. */
object SafFs {
    data class Node(val uri: Uri, val name: String, val dir: Boolean, val size: Long, val mime: String?)

    fun root(context: Context, uri: Uri): DocumentFile =
        (DocumentFile.fromTreeUri(context, uri) ?: DocumentFile.fromSingleUri(context, uri))
            ?: error("مجلد التخزين غير صالح")

    fun list(context: Context, uri: Uri): List<Node> = root(context, uri).listFiles()
        .map { Node(it.uri, it.name ?: "بدون اسم", it.isDirectory, it.length(), it.type) }
        .sortedWith(compareByDescending<Node> { it.dir }.thenBy(String.CASE_INSENSITIVE_ORDER) { it.name })

    fun open(context: Context, uri: Uri): InputStream = context.contentResolver.openInputStream(uri)
        ?: error("تعذر فتح الملف")

    fun createFile(context: Context, parent: Uri, name: String, mime: String): Uri {
        val p = root(context, parent)
        return p.createFile(mime, name)?.uri ?: error("تعذر إنشاء الملف")
    }

    fun createDir(context: Context, parent: Uri, name: String): Uri {
        val p = root(context, parent)
        return p.createDirectory(name)?.uri ?: error("تعذر إنشاء المجلد")
    }

    fun delete(context: Context, uri: Uri) {
        DocumentFile.fromSingleUri(context, uri)?.delete() ?: error("تعذر الحذف")
    }

    fun copy(context: Context, from: Uri, to: Uri, progress: ((Long, Long) -> Unit)? = null) {
        val total = DocumentFile.fromSingleUri(context, from)?.length() ?: -1L
        context.contentResolver.openInputStream(from).use { input ->
            context.contentResolver.openOutputStream(to, "w").use { output ->
                requireNotNull(input) { "تعذر فتح المصدر" }
                requireNotNull(output) { "تعذر فتح الوجهة" }
                copyStream(input, output, total, progress)
            }
        }
    }

    fun copyToFile(context: Context, from: Uri, to: File, progress: ((Long, Long) -> Unit)? = null) {
        to.parentFile?.mkdirs()
        context.contentResolver.openInputStream(from).use { input ->
            requireNotNull(input) { "تعذر فتح المصدر" }
            FileOutputStream(to).use { out ->
                val total = DocumentFile.fromSingleUri(context, from)?.length() ?: -1L
                copyStream(input, out, total, progress)
            }
        }
    }

    fun copyFromFile(context: Context, from: File, to: Uri, progress: ((Long, Long) -> Unit)? = null) {
        FileInputStream(from).use { input ->
            context.contentResolver.openOutputStream(to, "w").use { out ->
                requireNotNull(out) { "تعذر فتح الوجهة" }
                copyStream(input, out, from.length(), progress)
            }
        }
    }

    fun copyStream(input: InputStream, output: OutputStream, total: Long, progress: ((Long, Long) -> Unit)? = null) {
        val b = ByteArray(1024 * 1024)
        var done = 0L
        while (true) {
            val n = input.read(b)
            if (n <= 0) break
            output.write(b, 0, n)
            done += n
            progress?.invoke(done, total)
        }
        output.flush()
    }

    fun findChild(context: Context, parent: Uri, name: String): DocumentFile? =
        root(context, parent).listFiles().firstOrNull { it.name.equals(name, true) }

    fun relativeChild(context: Context, rootUri: Uri, relative: String, create: Boolean = true): Uri {
        var current = root(context, rootUri)
        val parts = relative.replace('\\', '/').split('/').filter { it.isNotBlank() && it != "." }
        require(parts.none { it == ".." }) { "مسار غير آمن" }
        for ((index, part) in parts.withIndex()) {
            var child = current.findFile(part)
            val last = index == parts.lastIndex
            if (last) {
                return child?.uri ?: if (create) {
                    current.createFile("application/octet-stream", part)?.uri ?: error("تعذر إنشاء الملف")
                } else error("الملف غير موجود")
            }
            if (child == null && create) child = current.createDirectory(part)
            current = child ?: error("المجلد غير موجود: $part")
            require(current.isDirectory) { "المسار ليس مجلدًا" }
        }
        return current.uri
    }
}

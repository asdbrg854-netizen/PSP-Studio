package com.ppssppstudio.core

import java.io.File

/** Xdelta 3 bridge. The native build supplies the actual VCDIFF decoder. */
object XdeltaBridge {
    init { try { System.loadLibrary("ppssppstudio") } catch (_: Throwable) {} }
    external fun apply(source: String, patch: String, output: String): String
    external fun create(source: String, target: String, patch: String): String
}

package com.ppssppstudio.core
import java.io.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.CRC32
object UpsPatch {
    private fun readVar(b: ByteArray, pos0: Int): Pair<Long, Int> {
        var p = pos0; var value = 0L; var shift = 0
        while (p < b.size) {
            val x = b[p++].toInt() and 255
            value += ((x and 0x7f) + if (shift == 0) 0 else 1).toLong() shl shift
            if ((x and 0x80) != 0) return value to p
            shift += 7
        }
        error("UPS VLV ناقص")
    }
    private fun writeVar(o: ByteArrayOutputStream, x0: Long) { var x=x0; while(true){ val d=(x and 0x7f).toInt(); x=x ushr 7; if(x==0L){o.write(d or 0x80);return}else{o.write(d);x--} } }
    private fun crc(b: ByteArray): Long = CRC32().apply { update(b) }.value
    private fun le(v: Long)=ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(v.toInt()).array()
    fun create(source: File, target: File, patch: File) {
        val a=source.readBytes(); val b=target.readBytes(); val o=ByteArrayOutputStream(); o.write("UPS1".toByteArray()); writeVar(o,a.size.toLong()); writeVar(o,b.size.toLong()); var pos=0
        while(pos<b.size){ var start=pos; while(pos<b.size&&pos<a.size&&a[pos]==b[pos])pos++; if(pos>=b.size)break; writeVar(o,(pos-start).toLong()); var terminated=false; while(pos<b.size&&(pos>=a.size||a[pos]!=b[pos])){val x=(if(pos<a.size)a[pos].toInt() else 0) xor b[pos].toInt();o.write(x);pos++;if(x==0){terminated=true;break}};if(!terminated){o.write(0);pos++} }
        val body=o.toByteArray(); val all=ByteArrayOutputStream(); all.write(body); all.write(le(crc(a))); all.write(le(crc(b))); val preCrc=all.toByteArray(); all.write(le(crc(preCrc))); patch.parentFile?.mkdirs(); patch.outputStream().use{it.write(all.toByteArray())}
    }
    fun apply(source: File, patch: File, target: File) {
        val p=patch.readBytes(); require(p.size>=16&&String(p.copyOfRange(0,4))=="UPS1"){"UPS غير صالح"}; var at=4; val (srcSize,n1)=readVar(p,at); at=n1; val (outSize,n2)=readVar(p,at); at=n2; val src=source.readBytes(); require(src.size.toLong()>=srcSize){"حجم المصدر أصغر من المطلوب"}; require(at<=p.size-12){"UPS تالف"}
        val expectedSrc=ByteBuffer.wrap(p,p.size-12,4).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xffffffffL; require(crc(src)==expectedSrc){"CRC للمصدر لا يطابق الـUPS"}
        val expectedPatch=ByteBuffer.wrap(p,p.size-4,4).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xffffffffL; require(crc(p.copyOf(p.size-4))==expectedPatch){"CRC لملف UPS غير صحيح"}
        val out=ByteArray(outSize.toInt()); var srcPos=0; var outPos=0
        while(at<p.size-12 && outPos<out.size){ val(skip,n)=readVar(p,at);at=n; repeat(skip.toInt()){ require(outPos<out.size){"UPS يتجاوز حجم الناتج"}; out[outPos++]=if(srcPos<src.size) src[srcPos] else 0; srcPos++ }; while(at<p.size-12 && outPos<out.size){val x=p[at++].toInt() and 255; val sv=if(srcPos<src.size) src[srcPos].toInt() else 0; out[outPos++]=(sv xor x).toByte(); srcPos++; if(x==0)break } }
        while(outPos<out.size && srcPos<src.size){ out[outPos++]=src[srcPos++] }
        val expectedOut=ByteBuffer.wrap(p,p.size-8,4).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xffffffffL; require(crc(out)==expectedOut){"CRC الناتج لا يطابق الـUPS"}; target.parentFile?.mkdirs();target.outputStream().use{it.write(out)}
    }
}

package com.ppssppstudio.core
import java.io.File
import java.security.MessageDigest
import java.util.zip.CRC32
object Hashes {
    data class Result(val size:Long,val crc32:String,val sha1:String,val sha256:String)
    fun calculate(f:File):Result {
        val crc=CRC32(); val sha1=MessageDigest.getInstance("SHA-1"); val sha256=MessageDigest.getInstance("SHA-256")
        val buf=ByteArray(1024*1024); var total=0L
        f.inputStream().buffered().use { input ->
            while(true){ val n=input.read(buf); if(n<0) break; crc.update(buf,0,n); sha1.update(buf,0,n); sha256.update(buf,0,n); total+=n }
        }
        fun hex(b:ByteArray)=b.joinToString(""){"%02x".format(it)}
        return Result(total,"%08x".format(crc.value),hex(sha1.digest()),hex(sha256.digest()))
    }
}

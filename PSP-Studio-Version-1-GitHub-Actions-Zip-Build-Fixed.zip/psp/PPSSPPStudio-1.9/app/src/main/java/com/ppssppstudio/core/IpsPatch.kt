package com.ppssppstudio.core
import java.io.*
object IpsPatch {
    private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 255) shl 8) or (b[o + 1].toInt() and 255)
    private fun u24(b: ByteArray, o: Int) = ((b[o].toInt() and 255) shl 16) or ((b[o + 1].toInt() and 255) shl 8) or (b[o + 2].toInt() and 255)
    private fun w16(out: ByteArrayOutputStream, v: Int) { out.write(v ushr 8); out.write(v) }
    private fun w24(out: ByteArrayOutputStream, v: Int) { out.write(v ushr 16); out.write(v ushr 8); out.write(v) }
    fun apply(source: File, patch: File, target: File) {
        val a = source.readBytes(); val p = patch.readBytes(); require(p.size >= 8 && String(p.copyOfRange(0, 5)) == "PATCH") { "IPS غير صالح" }
        val out = a.toMutableList(); var i = 5
        while (i + 2 < p.size) {
            if ((p[i].toInt() and 255) == 0x45 && (p[i + 1].toInt() and 255) == 0x4f && (p[i + 2].toInt() and 255) == 0x46) break
            require(i + 5 <= p.size) { "سجل IPS ناقص" }
            val off = u24(p, i); i += 3; val len = u16(p, i); i += 2
            if (len == 0) {
                require(i + 3 <= p.size) { "سجل RLE ناقص" }
                val n = u16(p, i); i += 2; val v = p[i].toInt() and 255; i++
                while (out.size < off + n) out.add(0)
                repeat(n) { out[off + it] = v.toByte() }
            } else {
                require(i + len <= p.size) { "بيانات IPS ناقصة" }
                while (out.size < off + len) out.add(0)
                for (j in 0 until len) out[off + j] = p[i + j]
                i += len
            }
        }
        target.parentFile?.mkdirs(); target.outputStream().use { it.write(out.toByteArray()) }
    }
    fun create(source: File, target: File, patch: File) {
        val a = source.readBytes(); val b = target.readBytes(); val out = ByteArrayOutputStream(); out.write("PATCH".toByteArray()); var i = 0
        while (i < maxOf(a.size, b.size)) {
            if (i < a.size && i < b.size && a[i] == b[i]) { i++; continue }
            val start = i; val data = ByteArrayOutputStream()
            while (i < maxOf(a.size, b.size) && data.size() < 65535) {
                if (i < a.size && i < b.size && a[i] == b[i]) break
                data.write(if (i < b.size) b[i].toInt() and 255 else 0); i++
            }
            w24(out, start); w16(out, data.size()); out.write(data.toByteArray())
        }
        out.write("EOF".toByteArray()); patch.parentFile?.mkdirs(); patch.outputStream().use { it.write(out.toByteArray()) }
    }
}

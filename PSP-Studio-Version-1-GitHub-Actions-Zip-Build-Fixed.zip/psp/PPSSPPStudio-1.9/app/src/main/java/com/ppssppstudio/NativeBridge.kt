package com.ppssppstudio

object NativeBridge {
    init { System.loadLibrary("ppssppstudio") }
    external fun convert(input: String, output: String, format: Int, quality: Int): String
    external fun version(): String
}

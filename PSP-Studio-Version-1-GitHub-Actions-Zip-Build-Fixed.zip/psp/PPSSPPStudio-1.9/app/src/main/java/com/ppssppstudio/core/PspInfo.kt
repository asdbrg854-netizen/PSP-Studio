package com.ppssppstudio.core
import java.io.File
import java.nio.charset.Charset
object PspInfo {
    fun gameId(iso:File):String? {
        val e=Iso9660(iso).find("PSP_GAME/PARAM.SFO") ?: return null
        val tmp=File.createTempFile("param",".sfo")
        try {
            Iso9660(iso).extract(e,tmp)
            val b=tmp.readBytes()
            val s=String(b,Charsets.ISO_8859_1)
            val re=Regex("[A-Z0-9]{4}-[A-Z0-9]{5}")
            return re.find(s)?.value
        } finally { tmp.delete() }
    }
}

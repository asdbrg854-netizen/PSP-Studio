package com.ppssppstudio.core

import java.io.File

object PatchEngine {
    enum class Kind { IPS, UPS, XDELTA }
    fun detect(name: String): Kind? = when (name.substringAfterLast('.', "").lowercase()) {
        "ips" -> Kind.IPS
        "ups" -> Kind.UPS
        "xdelta", "xd3", "vcdiff" -> Kind.XDELTA
        else -> null
    }
    fun apply(kind: Kind, source: File, patch: File, output: File) {
        when (kind) {
            Kind.IPS -> IpsPatch.apply(source, patch, output)
            Kind.UPS -> UpsPatch.apply(source, patch, output)
            Kind.XDELTA -> {
                val result = XdeltaBridge.apply(source.absolutePath, patch.absolutePath, output.absolutePath)
                if (result != "OK") error(result)
            }
        }
    }
}

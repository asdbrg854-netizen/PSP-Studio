package com.ppssppstudio.core
import java.io.*
import java.nio.charset.Charset
data class IsoEntry(val path:String,val extent:Long,val size:Long,val directory:Boolean)

class Iso9660(private val file:File) {
    companion object { const val SECTOR=2048 }
    private val entries=mutableListOf<IsoEntry>()
    fun list():List<IsoEntry>{ if(entries.isEmpty()) readRoot(); return entries.toList() }
    private fun readRoot(){
        RandomAccessFile(file,"r").use { r ->
            r.seek(16L*SECTOR); val pvd=ByteArray(SECTOR); r.readFully(pvd)
            require(pvd[0].toInt()==1 && String(pvd,1,5,Charsets.US_ASCII)=="CD001"){"ليس ISO9660 صالحًا"}
            val rootOff=19; val extent=u32(pvd,rootOff); val size=u32(pvd,rootOff+8)
            walk(r,extent,size,"")
        }
    }
    private fun walk(r:RandomAccessFile,extent:Long,size:Long,parent:String){
        val data=ByteArray(size.toInt()); r.seek(extent*SECTOR); r.readFully(data)
        var p=0
        while(p+34<=data.size){
            val len=data[p].toInt() and 255; if(len==0){p=((p/SECTOR)+1)*SECTOR; continue}
            if(p+len>data.size) break
            val ext=u32(data,p+2); val sz=u32(data,p+10)
            val flags=data[p+25].toInt() and 255; val nameLen=data[p+32].toInt() and 255
            if(33+nameLen<=len){
                var name=String(data,p+33,nameLen,Charsets.ISO_8859_1)
                if(name.endsWith(";1")) name=name.substringBeforeLast(";1")
                if(name!="." && name!=".."){
                    val path=if(parent.isEmpty()) name else "$parent/$name"
                    val dir=(flags and 2)!=0
                    entries.add(IsoEntry(path,ext,sz,dir))
                    if(dir && name!=".") walk(r,ext,sz,path)
                }
            }
            p+=len
        }
    }
    fun extract(entry:IsoEntry,out:File){
        require(!entry.directory){"المسار مجلد"}
        RandomAccessFile(file,"r").use { r -> out.parentFile?.mkdirs(); FileOutputStream(out).use { o ->
            r.seek(entry.extent*SECTOR); var left=entry.size; val b=ByteArray(1024*1024)
            while(left>0){val n=r.read(b,0,minOf(b.size,left.toInt())); if(n<=0)break;o.write(b,0,n);left-=n}
        }}
    }
    fun find(path:String)=list().firstOrNull{it.path.equals(path.trim('/'),true)}
    private fun u32(b:ByteArray,o:Int):Long=(b[o].toLong() and 255) or ((b[o+1].toLong() and 255) shl 8) or ((b[o+2].toLong() and 255) shl 16) or ((b[o+3].toLong() and 255) shl 24)
}

package com.ppssppstudio.core
import java.io.*
import org.apache.commons.compress.archivers.sevenz.*
import org.apache.commons.compress.archivers.zip.*
object Archive7z {
    fun extract7z(src:File,dest:File){SevenZFile(src).use{z->while(true){val e=z.nextEntry?:break;if(e.isDirectory)continue;val o=File(dest,e.name);o.parentFile?.mkdirs();o.outputStream().use{out->z.getInputStream(e).copyTo(out)}}}}
    fun create7z(srcDir:File,out:File){SevenZOutputFile(out).use{z->srcDir.walkTopDown().filter{it.isFile}.forEach{f->val rel=f.relativeTo(srcDir).path.replace(File.separatorChar,'/');val e=SevenZArchiveEntry();e.name=rel;e.size=f.length();z.putArchiveEntry(e);f.inputStream().use{it.copyTo(z)};z.closeArchiveEntry()}}}
    fun extractZip(src:File,dest:File){ZipFile(src).use{z->z.entries().asSequence().forEach{e->val o=File(dest,e.name);if(e.isDirectory)o.mkdirs()else{o.parentFile?.mkdirs();z.getInputStream(e).use{input->o.outputStream().use{input.copyTo(it)}}}}}}
}

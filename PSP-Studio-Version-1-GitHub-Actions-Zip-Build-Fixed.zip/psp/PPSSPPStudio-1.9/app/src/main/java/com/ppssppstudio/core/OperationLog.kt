package com.ppssppstudio.core

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object OperationLog {
    private const val PREF = "operation_log"
    private const val KEY = "items"
    fun add(context: Context, type: String, detail: String, ok: Boolean) {
        val old = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(old)
        arr.put(JSONObject().put("time", System.currentTimeMillis()).put("type", type).put("detail", detail).put("ok", ok))
        while (arr.length() > 50) arr.remove(0)
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
    fun read(context: Context): List<String> {
        val arr = JSONArray(context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]"))
        return (arr.length() - 1 downTo 0).map { i ->
            val o = arr.getJSONObject(i)
            val mark = if (o.optBoolean("ok")) "" else ""
            "$mark  ${o.optString("type")}: ${o.optString("detail")}"
        }
    }
}

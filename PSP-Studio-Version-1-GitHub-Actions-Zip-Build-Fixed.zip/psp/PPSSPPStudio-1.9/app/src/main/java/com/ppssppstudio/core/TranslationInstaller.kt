package com.ppssppstudio.core

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipFile

object TranslationInstaller {
    data class Manifest(val name: String, val gameId: String?, val version: String)
    data class Plan(val manifest: Manifest, val files: List<String>)

    fun inspect(context: Context, pack: Uri): Plan {
        val tmp = File.createTempFile("translation_", ".zip", context.cacheDir)
        try {
            SafFs.copyToFile(context, pack, tmp)
            ZipFile(tmp).use { z ->
                val me = z.getEntry("manifest.json") ?: error("حزمة الترجمة لا تحتوي manifest.json")
                val j = JSONObject(z.getInputStream(me).bufferedReader().use { it.readText() })
                val m = Manifest(j.optString("name", "ترجمة"), j.optString("gameId", null), j.optString("version", "1.0"))
                val files = z.entries().asSequence().filter { !it.isDirectory && it.name.startsWith("files/") }
                    .map { it.name.removePrefix("files/") }.filter { it.isNotBlank() }.toList()
                require(files.none { it.split('/').any { p -> p == ".." } }) { "الحزمة تحتوي مسارًا غير آمن" }
                return Plan(m, files)
            }
        } finally { tmp.delete() }
    }

    fun install(context: Context, pack: Uri, gameRoot: Uri, progress: (Int, String) -> Unit): Int {
        val plan = inspect(context, pack)
        if (!plan.manifest.gameId.isNullOrBlank()) {
            val param = SafFs.findByRelative(context, gameRoot, "PSP_GAME/PARAM.SFO")
            if (param != null && param.isFile) {
                val tmpParam = File.createTempFile("param_", ".sfo", context.cacheDir)
                try {
                    SafFs.copyToFile(context, param.uri, tmpParam)
                    val detected = Regex("[A-Z0-9]{4}-[A-Z0-9]{5}").find(String(tmpParam.readBytes(), Charsets.ISO_8859_1))?.value
                    require(detected.equals(plan.manifest.gameId, true)) { "Game ID غير متطابق: الحزمة ${plan.manifest.gameId} / اللعبة ${detected ?: "غير معروف"}" }
                } finally { tmpParam.delete() }
            }
        }
        val existing = plan.files.filter { SafFs.findByRelative(context, gameRoot, it) != null }
        BackupManager.backupFiles(context, gameRoot, existing)
        val tmp = File.createTempFile("translation_", ".zip", context.cacheDir)
        try {
            SafFs.copyToFile(context, pack, tmp)
            ZipFile(tmp).use { z ->
                val entries = z.entries().asSequence().filter { !it.isDirectory && it.name.startsWith("files/") }.toList()
                entries.forEachIndexed { idx, e ->
                    val rel = e.name.removePrefix("files/")
                    require(rel.split('/').none { it == ".." || it.isBlank() && rel.startsWith("/") }) { "مسار ترجمة غير آمن" }
                    val dest = SafFs.relativeChild(context, gameRoot, rel)
                    z.getInputStream(e).use { input ->
                        context.contentResolver.openOutputStream(dest, "w").use { out ->
                            requireNotNull(out) { "تعذر كتابة $rel" }
                            SafFs.copyStream(input, out, e.size) { done, total ->
                                val pct = if (total > 0) (done * 100 / total).toInt() else 0
                                progress(((idx * 100) + pct) / entries.size, rel)
                            }
                        }
                    }
                }
                val installed = context.getSharedPreferences("translations", Context.MODE_PRIVATE)
                installed.edit().putString(plan.manifest.name, JSONObject().put("root", gameRoot.toString()).put("files", plan.files).toString()).apply()
            }
            return plan.files.size
        } finally { tmp.delete() }
    }

    fun uninstall(context: Context, name: String): Int {
        val pref = context.getSharedPreferences("translations", Context.MODE_PRIVATE)
        val raw = pref.getString(name, null) ?: error("لا توجد ترجمة مسجلة بهذا الاسم")
        val o = JSONObject(raw); val root = Uri.parse(o.getString("root")); val files = o.getJSONArray("files")
        var count = 0
        for (i in 0 until files.length()) {
            val f = SafFs.findByRelative(context, root, files.getString(i))
            if (f != null && f.isFile) { f.delete(); count++ }
        }
        pref.edit().remove(name).apply()
        return count
    }
}

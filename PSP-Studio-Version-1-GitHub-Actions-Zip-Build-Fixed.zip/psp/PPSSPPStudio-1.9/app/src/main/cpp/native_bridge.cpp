#include <jni.h>
#include <string>
#include <vector>
#include <mutex>
#include "compress.h"

static std::string g_error;
static std::mutex g_mutex;

extern "C" JNIEXPORT jstring JNICALL
Java_com_ppssppstudio_NativeBridge_convert(JNIEnv *env, jobject,
        jstring input_, jstring output_, jint format, jint quality) {
    const char *input = env->GetStringUTFChars(input_, nullptr);
    const char *output = env->GetStringUTFChars(output_, nullptr);

    maxcso::Task task;
    task.input = input ? input : "";
    task.output = output ? output : "";
    task.block_size = maxcso::DEFAULT_BLOCK_SIZE;
    task.orig_max_cost_percent = 0.0;
    task.lz4_max_cost_percent = 0.0;
    task.flags = maxcso::TASKFLAG_DEFAULT;

    if (format == 1) task.flags |= maxcso::TASKFLAG_DECOMPRESS;
    else if (format == 2) task.flags |= maxcso::TASKFLAG_FMT_CSO_2;
    else if (format == 3) task.flags |= maxcso::TASKFLAG_FMT_ZSO;
    else if (format == 4) task.flags |= maxcso::TASKFLAG_FMT_DAX;

    // Phone-friendly quality presets.
    // 0 = fast, 1 = balanced, 2 = maximum.
    if (quality == 0) {
        task.flags |= maxcso::TASKFLAG_NO_ZOPFLI | maxcso::TASKFLAG_NO_7ZIP |
                      maxcso::TASKFLAG_NO_LZ4_HC_BRUTE;
    } else if (quality == 1) {
        task.flags |= maxcso::TASKFLAG_NO_ZOPFLI | maxcso::TASKFLAG_NO_LZ4_HC_BRUTE;
    }

    {
        std::lock_guard<std::mutex> lock(g_mutex);
        g_error.clear();
    }

    task.progress = [](const maxcso::Task *, maxcso::TaskStatus, int64_t, int64_t, int64_t) {};
    task.error = [](const maxcso::Task *, maxcso::TaskStatus, const char *reason) {
        std::lock_guard<std::mutex> lock(g_mutex);
        g_error = reason ? reason : "Unknown maxcso error";
    };

    std::vector<maxcso::Task> tasks;
    tasks.push_back(task);
    maxcso::Compress(tasks);

    env->ReleaseStringUTFChars(input_, input);
    env->ReleaseStringUTFChars(output_, output);

    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_error.empty()) return env->NewStringUTF("OK");
    return env->NewStringUTF(g_error.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_ppssppstudio_NativeBridge_version(JNIEnv *env, jobject) {
    return env->NewStringUTF("maxcso 1.13.0 / PSP Studio native");
}

#ifdef PPSSPPSTUDIO_XDELTA
#include "xdelta3.h"
#include <fstream>
#include <limits>

static bool read_all(const char *path, std::vector<uint8_t> &out, std::string &err) {
    std::ifstream f(path, std::ios::binary | std::ios::ate);
    if (!f) { err = "تعذر فتح ملف XDelta"; return false; }
    const std::streamoff n = f.tellg();
    if (n < 0 || static_cast<unsigned long long>(n) > 512ULL * 1024ULL * 1024ULL) { err = "ملف XDelta أكبر من حد الذاكرة 512MB"; return false; }
    out.resize(static_cast<size_t>(n)); f.seekg(0); if (n && !f.read(reinterpret_cast<char*>(out.data()), n)) { err = "تعذر قراءة ملف XDelta"; return false; }
    return true;
}
static std::string xd3_run(bool encode, const char *aPath, const char *bPath, const char *outPath) {
    std::vector<uint8_t> a,b; std::string err;
    if (!read_all(aPath,a,err) || !read_all(bPath,b,err)) return err;
    size_t cap = std::max<size_t>(16 * 1024 * 1024, a.size() + b.size() + 1024 * 1024);
    cap = std::min<size_t>(cap, 512ULL * 1024ULL * 1024ULL);
    std::vector<uint8_t> out(cap); usize_t outSize = 0;
    int flags = XD3_SEC_NOALL | XD3_COMPLEVEL_6;
    int rc;
    if (encode) rc = xd3_encode_memory(b.data(), (usize_t)b.size(), a.data(), (usize_t)a.size(), out.data(), &outSize, (usize_t)out.size(), flags);
    else rc = xd3_decode_memory(b.data(), (usize_t)b.size(), a.data(), (usize_t)a.size(), out.data(), &outSize, (usize_t)out.size(), 0);
    if (rc != 0) return std::string("XDelta3: ") + (xd3_strerror(rc) ? xd3_strerror(rc) : "فشل غير معروف");
    std::ofstream o(outPath, std::ios::binary | std::ios::trunc); if (!o) return "تعذر إنشاء ناتج XDelta";
    o.write(reinterpret_cast<const char*>(out.data()), outSize); if (!o) return "فشل كتابة ناتج XDelta";
    return "OK";
}
#endif

extern "C" JNIEXPORT jstring JNICALL
Java_com_ppssppstudio_core_XdeltaBridge_apply(JNIEnv *env, jobject,
        jstring source_, jstring patch_, jstring output_) {
    const char *s=env->GetStringUTFChars(source_,nullptr), *p=env->GetStringUTFChars(patch_,nullptr), *o=env->GetStringUTFChars(output_,nullptr);
#ifdef PPSSPPSTUDIO_XDELTA
    std::string r=xd3_run(false,s,p,o);
#else
    std::string r="XDelta3 غير مضمّن في هذه البنية";
#endif
    env->ReleaseStringUTFChars(source_,s); env->ReleaseStringUTFChars(patch_,p); env->ReleaseStringUTFChars(output_,o);
    return env->NewStringUTF(r.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_ppssppstudio_core_XdeltaBridge_create(JNIEnv *env, jobject,
        jstring source_, jstring target_, jstring patch_) {
    const char *s=env->GetStringUTFChars(source_,nullptr), *t=env->GetStringUTFChars(target_,nullptr), *p=env->GetStringUTFChars(patch_,nullptr);
#ifdef PPSSPPSTUDIO_XDELTA
    std::string r=xd3_run(true,s,t,p);
#else
    std::string r="XDelta3 غير مضمّن في هذه البنية";
#endif
    env->ReleaseStringUTFChars(source_,s); env->ReleaseStringUTFChars(target_,t); env->ReleaseStringUTFChars(patch_,p);
    return env->NewStringUTF(r.c_str());
}

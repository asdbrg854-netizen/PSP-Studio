# Third-party components

- maxcso 1.13.0: included under `native/maxcso/` and retains its upstream license files.
- libuv, zlib, zopfli, lz4, libdeflate, and 7-Zip/Deflate sources used by maxcso are included in that tree with their upstream license/copyright files.
- Apache Commons Compress is used by the Android archive layer for ZIP/7Z operations.

Before public distribution, review all upstream license notices and package attribution requirements.

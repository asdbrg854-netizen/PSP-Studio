# GamePack X v1.2 Advanced

GamePack X is a lossless, adaptive, multi-stage compression engine reference implementation in Python 3.11+.

It is designed around a versioned `.gpj` container, chunk-local method selection, integrity checking, deduplication, deterministic output, bounded-memory operation, and an extensible codec/filter registry.

## Status

This delivery is a **working v1.2 advanced reference implementation**. v1.2 is a development pass over v1.1 focused on making the "advanced" paths (BWT, context modeling) actually reachable at real file sizes, fixing two correctness bugs found while doing that, and measuring speed/ratio changes rather than assuming them. See `docs/V1_2.md` for the full, itemized list of what changed and why, including the optimizations that were *tried and didn't help* -- kept in the docs so they aren't re-attempted blind.

The architecture still exposes the requested extension points, while deliberately keeping some high-cost filters (BCJ, true full-PPM with escape) as conservative compatibility stubs until their full independent implementation is added. Unsupported methods are never silently encoded.

The implemented baseline includes:

- GPX v1 container (dedup reference field is 1-based on the wire -- see `docs/FORMAT.md`)
- fixed and content-defined chunking
- STORE, RLE, LZ (level-tunable search depth + lazy matching), LZ+rANS (per-stream entropy-coded LZ tokens)
- optional C acceleration for LZ matching, rANS, MTF, and CRC32C (`gpx/native/`), auto-built and cached on first use, with a verified bit-exact pure-Python fallback when no C compiler is available
- BWT (O(n log^2 n) suffix array, NumPy-accelerated with a pure-Python fallback) + MTF + rANS, sub-blocked for large chunks
- deterministic rANS entropy coding
- real order-1 static context model, plus a documented order-0 rANS baseline
- delta filters
- conservative executable-filter architecture
- chunk SHA-256 + CRC32C
- whole-file SHA-256
- chunk deduplication
- local/previous/global dictionary architecture
- adaptive cost-based selection (single implementation, in `gpx/selector.py`)
- multiprocessing compression (`ProcessPoolExecutor`, so `-j` gives real multi-core speedup)
- memory budget heuristics
- CLI
- correctness, corruption, determinism and fuzz tests, plus v1.2 regression tests for the bugs found
- benchmark harness and documentation

## Example

```bash
python -m cli.gpx compress game.iso game.gpj -l 5 -j 8
python -m cli.gpx test game.gpj
python -m cli.gpx decompress game.gpj restored.iso
python -m cli.gpx verify game.gpj game.iso
```

The successful verification target is:

```text
VERIFIED
SHA256 MATCH
BYTE-FOR-BYTE MATCH
```

No claim is made that GamePack X is universally better than other compressors. It attempts to find a practical representation from its available reversible transforms and coders.

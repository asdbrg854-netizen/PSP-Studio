"""Fixed and content-defined chunking."""
from hashlib import blake2s

def fixed_chunks(data: bytes, size: int):
    if size <= 0: raise ValueError("chunk size must be positive")
    for i in range(0, len(data), size):
        yield data[i:i+size]

def cdc_chunks(data: bytes, min_size=256*1024, avg_size=1024*1024, max_size=4*1024*1024):
    if not (0 < min_size <= avg_size <= max_size):
        raise ValueError("invalid CDC bounds")
    if not data: return
    mask = avg_size - 1 if avg_size & (avg_size-1) == 0 else None
    start=0; h=0
    for i,b in enumerate(data):
        h=((h<<5)-h+b)&0xffffffff
        span=i-start+1
        cut = span >= min_size and ((h & (mask if mask is not None else 0xFFFF)) == 0)
        if span >= max_size: cut=True
        if cut:
            yield data[start:i+1]; start=i+1
    if start < len(data): yield data[start:]

"""Lightweight content analysis used as a hint, never as a correctness decision."""
import math, collections, struct

def analyze(data: bytes) -> dict:
    n=len(data)
    if not n:
        return {"kind":"empty","entropy":0.0,"repeat":1.0,"alignment":1}
    c=collections.Counter(data)
    ent=-sum((v/n)*math.log2(v/n) for v in c.values())
    repeat=1.0-len(c)/256.0
    alignment=4 if n>=8 and n%4==0 else 1
    kind="binary"
    if data.startswith((b"MZ", b"\x7fELF")): kind="executable"
    elif data.startswith((b"PK\x03\x04", b"\x1f\x8b", b"BZh")): kind="archive"
    elif ent > 7.8: kind="high_entropy"
    elif sum(32 <= x < 127 or x in (9,10,13) for x in data[:4096]) > min(n,4096)*0.85: kind="text"
    return {"kind":kind,"entropy":ent,"repeat":repeat,"alignment":alignment}


def segment_entropy_spread(data: bytes, n_segments: int = 8) -> float:
    """How much local entropy varies across the block, in bits.

    Used to decide *before* running BWT whether a chunk is roughly
    homogeneous (one suffix sort covering the whole thing helps) or a mix
    of very different regions (a large sort gets diluted by the noisy part
    -- see docs/V1_2.md's block-size investigation). This is O(n) with a
    small constant (Counter-based entropy over a handful of slices, no
    suffix sorting), typically a few tens of milliseconds even on a 1 MiB
    chunk -- cheap enough to run before deciding whether to pay for a
    multi-second BWT pass, let alone two of them.
    """
    n = len(data)
    if n < n_segments * 64:
        return 0.0
    seg_len = n // n_segments
    entropies = []
    for i in range(n_segments):
        seg = data[i * seg_len:(i + 1) * seg_len]
        counts = collections.Counter(seg)
        total = len(seg)
        h = -sum((v / total) * math.log2(v / total) for v in counts.values())
        entropies.append(h)
    return max(entropies) - min(entropies)

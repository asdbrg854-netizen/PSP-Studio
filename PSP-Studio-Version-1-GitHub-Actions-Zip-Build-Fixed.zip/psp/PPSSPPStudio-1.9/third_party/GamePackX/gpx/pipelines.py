"""Composite codec pipelines shared by the encoder, decoder, and selector.

v1.1 gated the BWT+MTF+rANS path to whole chunks under 32768 bytes, and
never split a chunk into smaller pieces for it. With the default 1 MiB
chunk size, that meant the "advanced" path was silently unreachable for
almost any real file -- everything larger than 32 KiB fell back to plain
LZ. It also duplicated the same three-codec glue code independently in
gpx/encoder.py and gpx/decoder.py, which is exactly the kind of drift that
let the 32768-byte limit disagree with the 2 MiB limit written into the
(unused) gpx/selector.py.

This module is now the single place that combines BWT + MTF + rANS into a
container-level method, splitting large input into independently BWT'd
sub-blocks (the same idea bzip2 uses, since suffix-sorting cost grows
faster than linearly with block size). Encoder, decoder, and selector all
call the same two functions, so there is one payload format and one set of
size limits to reason about.
"""
import struct

from .codecs.bwt import encode as _bwt_encode, decode as _bwt_decode
from .codecs.mtf import encode as _mtf_encode, decode as _mtf_decode
from .codecs.rans import encode as _rans_encode, decode_n as _rans_decode_n

_SUBBLOCK_HEADER = struct.Struct("<I")   # sub-block count
_SUBBLOCK_ENTRY = struct.Struct("<II")   # original_len, compressed_len


def bwt_block_size_for_level(level: int) -> int:
    """Sub-block size used for the BWT path at a given level.

    Larger blocks give the suffix sort more context (usually better ratio)
    at roughly O(size * log(size)^2) cost. These defaults keep a single
    sub-block's encode time in the low seconds on typical hardware; pass a
    smaller --chunk-size on the CLI for tighter latency, or rely on -j to
    parallelize across chunks/sub-blocks on multi-core machines.
    """
    return {1: 0, 2: 0, 3: 256 * 1024, 4: 1024 * 1024, 5: 4 * 1024 * 1024}.get(level, 256 * 1024)


def encode(data: bytes, block_size: int) -> bytes:
    if block_size <= 0:
        raise ValueError("block_size must be positive")
    blocks = [data[i:i + block_size] for i in range(0, len(data), block_size)] or [b""]
    out = bytearray()
    out += _SUBBLOCK_HEADER.pack(len(blocks))
    for blk in blocks:
        b = _bwt_encode(blk)
        b = b[:4] + _mtf_encode(b[4:])
        z = _rans_encode(b)
        out += _SUBBLOCK_ENTRY.pack(len(b), len(z))
        out += z
    return bytes(out)


def decode(payload: bytes) -> bytes:
    if len(payload) < _SUBBLOCK_HEADER.size:
        raise ValueError("truncated bwt pipeline payload")
    (n_blocks,) = _SUBBLOCK_HEADER.unpack_from(payload, 0)
    pos = _SUBBLOCK_HEADER.size
    out = bytearray()
    for _ in range(n_blocks):
        if pos + _SUBBLOCK_ENTRY.size > len(payload):
            raise ValueError("truncated bwt pipeline index")
        orig_len, comp_len = _SUBBLOCK_ENTRY.unpack_from(payload, pos)
        pos += _SUBBLOCK_ENTRY.size
        if pos + comp_len > len(payload):
            raise ValueError("truncated bwt pipeline block")
        z = payload[pos:pos + comp_len]
        pos += comp_len
        b = _rans_decode_n(z, orig_len)
        blk = _bwt_decode(b[:4] + _mtf_decode(b[4:]))
        out += blk
    return bytes(out)

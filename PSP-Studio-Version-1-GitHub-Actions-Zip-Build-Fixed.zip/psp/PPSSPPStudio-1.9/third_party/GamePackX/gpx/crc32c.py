"""Pure-Python CRC32C (Castagnoli), with a C fallback-preferred path.

Uses gpx._native's C implementation when available -- CRC was never the
dominant cost in this pipeline (see the note below on the slice-by-4
experiment that didn't pay off in pure Python), but since the C module
exists now for LZ/rANS/MTF anyway, there's no reason not to use it here
too when it's there; bit-exact with the pure-Python table method either
way.

We tried the standard "slice-by-4/8" trick here (fold multiple bytes per
loop iteration to cut the iteration count) and measured it end to end: it
did not help, and was sometimes slightly slower. In CPython the interpreter
dispatch overhead per bytecode dominates over the table lookups themselves,
so combining bytes with shifts before the lookup costs about as much as the
lookups it saves -- slicing tricks pay off in C, where they reduce memory
traffic, not in an interpreted loop. Rather than ship extra complexity for
no measured benefit, this stays the straightforward byte-at-a-time table
method as its pure-Python fallback.
"""
from . import _native

_POLY = 0x82F63B78
_TABLE = []
for n in range(256):
    c = n
    for _ in range(8):
        c = (c >> 1) ^ (_POLY if c & 1 else 0)
    _TABLE.append(c)


def _crc32c_py(data: bytes, crc: int = 0) -> int:
    c = crc ^ 0xFFFFFFFF
    table = _TABLE
    for b in data:
        c = table[(c ^ b) & 0xFF] ^ (c >> 8)
    return (c ^ 0xFFFFFFFF) & 0xFFFFFFFF


def crc32c(data: bytes, crc: int = 0) -> int:
    if _native.AVAILABLE:
        return _native.crc32c(data, crc)
    return _crc32c_py(data, crc)

from .store import encode as store_encode, decode as store_decode
from .rle import encode as rle_encode, decode as rle_decode
from .lz import encode as lz_encode, decode as lz_decode
from .bwt import encode as bwt_encode, decode as bwt_decode
from .mtf import encode as mtf_encode, decode as mtf_decode
from .rans import encode as rans_encode, decode as rans_decode
from .arithmetic import encode as arithmetic_encode, decode as arithmetic_decode
from .ppm import encode as ppm_encode, decode as ppm_decode
from .lz_entropy import encode as lz_entropy_encode, decode as lz_entropy_decode

METHOD_STORE = 0
METHOD_RLE = 1
METHOD_LZ = 2
METHOD_BWT_MTF_RANS = 3
METHOD_PPM_RANS = 4
METHOD_PPM_ARITH = 5
METHOD_LZ_ENTROPY = 6  # LZ77 tokens, split into streams and rANS-coded (gpx.codecs.lz_entropy)

__all__ = ["METHOD_STORE", "METHOD_RLE", "METHOD_LZ", "METHOD_BWT_MTF_RANS",
           "METHOD_PPM_RANS", "METHOD_PPM_ARITH", "METHOD_LZ_ENTROPY"]

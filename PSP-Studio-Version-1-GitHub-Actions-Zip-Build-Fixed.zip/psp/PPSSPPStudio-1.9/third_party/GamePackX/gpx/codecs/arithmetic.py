"""Order-0 entropy baseline (plain rANS on raw, unfiltered bytes).

Now that gpx.codecs.ppm implements a real order-1 model, this module's role
is to be the honest order-0 comparison point: no BWT/MTF preprocessing, no
context. It occasionally wins in the selector's candidate competition on
data with a skewed byte distribution but little exploitable repetition
(where BWT's block-sorting overhead and PPM's per-context header cost don't
pay for themselves), and gives the selector something to check the fancier
candidates against. It shares the same deterministic rANS backend as every
other entropy stage in this codebase rather than a separate implementation.
"""
from .rans import encode as _rans_encode, decode_n as _rans_decode_n


def encode(data: bytes) -> bytes:
    return _rans_encode(data)


def decode(data: bytes, size: int) -> bytes:
    return _rans_decode_n(data, size)

"""Deterministic LZ77 backend with tunable search depth and lazy matching.

Token format (unchanged from earlier versions, still a valid GPX v1 payload):
literal: 0x00 + byte
match:   0x01 + distance:uint16 + length:uint16

Search depth and lazy matching (checking position+1 before committing to a
match at position i) are both level-tunable, same idea DEFLATE uses: more
chain entries find better matches at higher CPU cost.

Match *extension* -- given a candidate position, how far do the bytes
actually keep agreeing -- is done with NumPy when available: comparing two
array slices and finding the first mismatch is one vectorized call instead
of a Python-level byte loop. This matters more than it used to now that a
single match can legitimately run for tens of thousands of bytes (see the
comment on the removed `dist` cap below), since that's exactly the case
where a Python loop previously had to execute once per byte.

`parse_tokens()` exposes the token stream itself (not yet serialized) so
gpx.codecs.lz_entropy can reuse the identical matcher and entropy-code the
tokens instead of storing them raw -- literal bytes, match lengths, and
match distances all have their own, usually skewed, distributions, and
letting rANS see each of those streams separately compresses noticeably
better than treating the interleaved raw token bytes as generic input.
"""
import struct

from .. import _native

try:
    import numpy as _np
    _HAVE_NUMPY = True
except ImportError:  # pragma: no cover
    _HAVE_NUMPY = False

WINDOW = 65535
MAX_LEN = 65535
MIN_MATCH = 3

# (chain_depth, lazy, nice_match) per compression level. Level 1-2 favor
# speed with a shallow search and no lazy step; 4-5 spend more CPU for a
# better ratio. `nice_match`: once a candidate at least this long is found,
# stop searching further chain entries -- diminishing returns on an
# already-long match aren't worth the remaining search budget, and this
# keeps highly repetitive data (which fills hash chains with many
# candidates) from paying full chain_depth cost at every position.
#
# Level 5 used to be (256, True, 8192). Measured against an adversarial
# case built specifically to need deep search (many near-duplicate records
# sharing a 3-byte prefix, true best match often several records back):
# depth 128 produced output within 4 bytes of depth 256's (172,732 vs.
# 172,728, on ~1.5 MB of input) at meaningfully lower cost (6.4s vs. 8.8s
# for that case). Past ~128, the chain search was paying real CPU for
# results in the noise. See docs/V1_2.md.
_LEVEL_PARAMS = {
    1: (16, False, 64),
    2: (32, False, 128),
    3: (64, False, 256),
    4: (128, True, 1024),
    5: (128, True, 4096),
}


def _extend_numpy(arr, pos, i, limit):
    a = arr[pos:pos + limit]
    b = arr[i:i + limit]
    neq = _np.not_equal(a, b)
    idx = _np.argmax(neq)
    if not neq[idx]:  # no mismatch found in range -> fully equal
        return limit
    return int(idx)


def _extend_python(data, pos, i, limit):
    ln = 0
    while ln < limit and data[pos + ln] == data[i + ln]:
        ln += 1
    return ln


def _find_match(data, i, table, chain_depth, nice_match, arr=None):
    n = len(data)
    if i + MIN_MATCH > n:
        return 0, 0
    key = data[i:i + 3]
    chain = table.get(key)
    if not chain:
        return 0, 0
    best_len = 0
    best_dist = 0
    limit_outer = min(MAX_LEN, n - i)
    checked = 0
    for pos in reversed(chain):
        if checked >= chain_depth:
            break
        checked += 1
        dist = i - pos
        if dist > WINDOW:
            break
        if best_len:
            # Quick reject: this candidate can only beat best_len if it
            # still agrees with the input at that offset. Skips the full
            # extension check for chain entries that can't win.
            probe = best_len
            if pos + probe < n and i + probe < n and data[pos + probe] != data[i + probe]:
                continue
        # No `dist` cap on the extension limit: decode's copy loop reads
        # from a fixed offset into a growing output buffer, so a match
        # longer than its own distance is a normal, correctly-decoded
        # overlapping/self-referential copy -- exactly how LZ77 represents
        # a long run of a repeated pattern (e.g. distance=1 for a run of
        # one byte). Capping the limit at `dist` (as an earlier version of
        # this file did) forces long runs to be rebuilt out of many short
        # matches and forces the matcher to re-search the same chain at
        # every position in the run instead of skipping past it.
        if arr is not None:
            ln = _extend_numpy(arr, pos, i, limit_outer)
        else:
            ln = _extend_python(data, pos, i, limit_outer)
        if ln > best_len:
            best_len, best_dist = ln, dist
            if best_len >= nice_match or best_len >= limit_outer:
                break
    if best_len >= MIN_MATCH:
        return best_len, best_dist
    return 0, 0


def _insert(data, pos, table):
    if pos + 3 <= len(data):
        table.setdefault(data[pos:pos + 3], []).append(pos)


def _tokens_from_raw(raw: bytes):
    """Convert the C matcher's raw serialized output (same format
    serialize_raw() below produces) back into the (\"L\", byte) / (\"M\",
    dist, len) tuple form the rest of this codebase works with. O(number of
    tokens), not O(input size * chain_depth) -- cheap relative to what it's
    replacing (a full Python-level matching pass)."""
    tokens = []
    i = 0
    n = len(raw)
    while i < n:
        typ = raw[i]
        i += 1
        if typ == 0:
            tokens.append(("L", raw[i]))
            i += 1
        else:
            dist, ln = struct.unpack_from("<HH", raw, i)
            i += 4
            tokens.append(("M", dist, ln))
    return tokens


def parse_tokens(data: bytes, level: int = 3):
    """Yield ('L', byte) for a literal or ('M', distance, length) for a
    match, in order. Shared by encode() below and gpx.codecs.lz_entropy."""
    chain_depth, lazy, nice_match = _LEVEL_PARAMS.get(level, (64, False, 256))

    if _native.AVAILABLE:
        # Measured ~100x faster than the pure-Python matcher below on
        # representative chunks -- this was, by a wide margin, the single
        # largest remaining cost in the whole pipeline. See docs/V1_2.md.
        raw = _native.lz_parse(data, chain_depth, lazy, nice_match)
        return _tokens_from_raw(raw)

    arr = _np.frombuffer(data, dtype=_np.uint8) if (_HAVE_NUMPY and len(data) > 256) else None
    n = len(data)
    i = 0
    table = {}
    tokens = []
    while i < n:
        best_len, best_dist = _find_match(data, i, table, chain_depth, nice_match, arr)
        if lazy and best_len >= MIN_MATCH and i + 1 < n:
            _insert(data, i, table)
            next_len, next_dist = _find_match(data, i + 1, table, chain_depth, nice_match, arr)
            if next_len > best_len:
                tokens.append(("L", data[i]))
                i += 1
                continue
        if best_len >= MIN_MATCH:
            tokens.append(("M", best_dist, best_len))
            end = i + best_len
            while i < end:
                _insert(data, i, table)
                i += 1
        else:
            tokens.append(("L", data[i]))
            _insert(data, i, table)
            i += 1
    return tokens


def encode(data: bytes, level: int = 3) -> bytes:
    return serialize_raw(parse_tokens(data, level))


def serialize_raw(tokens) -> bytes:
    out = bytearray()
    for tok in tokens:
        if tok[0] == "L":
            out.append(0)
            out.append(tok[1])
        else:
            out.append(1)
            out += struct.pack("<HH", tok[1], tok[2])
    return bytes(out)


def decode(data: bytes) -> bytes:
    out = bytearray()
    i = 0
    n = len(data)
    while i < n:
        typ = data[i]
        i += 1
        if typ == 0:
            if i >= n:
                raise ValueError("truncated LZ literal")
            out.append(data[i])
            i += 1
        elif typ == 1:
            if i + 4 > n:
                raise ValueError("truncated LZ match")
            dist, ln = struct.unpack_from("<HH", data, i)
            i += 4
            if not dist or not ln or dist > len(out):
                raise ValueError("invalid LZ distance/length")
            out_len = len(out)
            src = out_len - dist
            for k in range(ln):
                out.append(out[src + k])
        else:
            raise ValueError("invalid LZ token")
    return bytes(out)

"""Run-length encoding using (count:uint32, byte) records."""
import struct

def encode(data: bytes) -> bytes:
    if not data:
        return b""
    out = bytearray()
    start = 0
    while start < len(data):
        b = data[start]
        end = start + 1
        while end < len(data) and data[end] == b and end - start < 0xFFFFFFFF:
            end += 1
        out += struct.pack("<IB", end - start, b)
        start = end
    return bytes(out)

def decode(data: bytes) -> bytes:
    if len(data) % 5:
        raise ValueError("invalid RLE payload")
    out = bytearray()
    for i in range(0, len(data), 5):
        n, b = struct.unpack_from("<IB", data, i)
        if n == 0:
            raise ValueError("zero RLE run")
        out.extend(bytes([b]) * n)
    return bytes(out)

"""Deterministic byte rANS with normalized frequencies.

Uses gpx._native's C implementation when available -- bit-exact with the
pure-Python path below (cross-checked in tests/test_native.py by encoding
in one and decoding in the other, both directions), just far faster: this
is a per-symbol sequential loop with a data-dependent renormalization
branch, exactly the kind of thing CPython's per-bytecode dispatch overhead
dominates and a compiled loop doesn't pay at all.
"""
import struct

from .. import _native

L = 1 << 16
RANS_L = 1 << 23
TOT = 4096

def _table(data):
    freq = [0] * 256
    for b in data: freq[b] += 1
    symbols = [i for i, f in enumerate(freq) if f]
    if not symbols: return [0]*256, [0]*256
    scaled = [0]*256
    rem = TOT
    for s in symbols:
        scaled[s] = max(1, (freq[s] * TOT) // len(data))
        rem -= scaled[s]
    # Distribute remainder deterministically.
    j = 0
    while rem > 0:
        scaled[symbols[j % len(symbols)]] += 1
        rem -= 1; j += 1
    while rem < 0:
        s = symbols[j % len(symbols)]
        if scaled[s] > 1:
            scaled[s] -= 1; rem += 1
        j += 1
    cum = [0]*256; c=0
    for s in range(256):
        cum[s]=c; c += scaled[s]
    return scaled, cum

def _encode_py(data: bytes) -> bytes:
    if not data:
        return struct.pack("<H", 0)
    freq, cum = _table(data)
    inv = [0]*TOT
    for s in range(256):
        for x in range(cum[s], cum[s]+freq[s]):
            inv[x] = s
    state = RANS_L
    emitted = bytearray()
    for s in reversed(data):
        f = freq[s]
        while state >= ((RANS_L >> 12) * f << 8):
            emitted.append(state & 0xFF); state >>= 8
        state = ((state // f) << 12) + (state % f) + cum[s]
    header = struct.pack("<H", sum(1 for f in freq if f))
    for s in range(256):
        if freq[s]:
            header += struct.pack("<BH", s, freq[s])
    return header + struct.pack("<Q", state) + bytes(reversed(emitted))

def decode(data: bytes) -> bytes:
    if len(data) < 2: raise ValueError("truncated rANS")
    nsyms = struct.unpack_from("<H", data, 0)[0]
    pos=2; freq=[0]*256
    for _ in range(nsyms):
        if pos+3 > len(data): raise ValueError("truncated rANS table")
        s,f=struct.unpack_from("<BH",data,pos); pos+=3
        if not f: raise ValueError("invalid frequency")
        freq[s]=f
    if pos+8 > len(data): raise ValueError("truncated rANS state")
    state=struct.unpack_from("<Q",data,pos)[0]; pos+=8
    stream=data[pos:]; sp=0
    total=sum(freq)
    if total != TOT and nsyms:
        raise ValueError("invalid normalized frequencies")
    cum=[0]*256;c=0
    inv=[0]*TOT
    for s in range(256):
        cum[s]=c
        for x in range(c,c+freq[s]): inv[x]=s
        c+=freq[s]
    # Original output length is not explicitly encoded; the container provides it.
    # Decode as many symbols as can be represented by the remaining entropy stream.
    # The container decoder supplies exact output length through decode_n.
    return _decode_unknown(data)

def _decode_unknown(data):
    raise ValueError("rANS payload requires container output length; use decode_n")

def decode_n(data: bytes, n: int) -> bytes:
    if _native.AVAILABLE:
        return _native.rans_decode_n(data, n)
    return _decode_n_py(data, n)


def encode(data: bytes) -> bytes:
    if _native.AVAILABLE:
        return _native.rans_encode(data)
    return _encode_py(data)


def _decode_n_py(data: bytes, n: int) -> bytes:
    if n == 0: return b""
    nsyms=struct.unpack_from("<H",data,0)[0];pos=2;freq=[0]*256
    for _ in range(nsyms):
        s,f=struct.unpack_from("<BH",data,pos);pos+=3;freq[s]=f
    state=struct.unpack_from("<Q",data,pos)[0];pos+=8
    stream=data[pos:];sp=0
    cum=[0]*256;inv=[0]*TOT;c=0
    for s in range(256):
        cum[s]=c
        for x in range(c,c+freq[s]):inv[x]=s
        c+=freq[s]
    out=bytearray()
    for _ in range(n):
        x=state & (TOT-1); s=inv[x]; out.append(s)
        state=freq[s]*(state>>12)+(x-cum[s])
        while state < RANS_L:
            if sp >= len(stream): raise ValueError("truncated rANS stream")
            state=(state<<8)|stream[sp];sp+=1
    return bytes(out)

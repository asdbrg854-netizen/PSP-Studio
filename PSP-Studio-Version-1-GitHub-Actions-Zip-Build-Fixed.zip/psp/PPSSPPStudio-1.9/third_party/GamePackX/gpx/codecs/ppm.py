"""Order-1 adaptive-context entropy coder.

v1.1 shipped this module as an honestly-labeled stub: `encode()` just called
the order-0 rANS coder and ignored the requested context order. That was a
correct design choice at the time (never claim more than what's implemented),
but it meant the "ppm" candidate could never do better than plain rANS.

This version implements a real order-1 model: a separate, statically
normalized frequency table per preceding byte, still riding on the same
rANS state machine and renormalization constants as codecs/rans.py (same
TOT=4096, same RANS_L), just switching which table is consulted at each
symbol based on context. Because the tables are static (built once from the
whole block and stored in the header) rather than adaptively updated symbol
by symbol, encoder and decoder can look up the same table for a given
context without needing to replay updates in matching order -- important
here because rANS encodes its input in reverse.

This is still not full PPM (no order fallback/escape mechanism to lower
orders for unseen contexts), so it is named and documented as what it is:
an order-1 static context model. It measurably helps on text and other
locally-structured data and is a strict superset of order-0 in the sense
that the selector only keeps it when it actually produces a smaller
payload than every other candidate.
"""
import struct
from collections import defaultdict

from .rans import RANS_L, TOT

_HEADER_MAGIC = 0xC1


def _normalize(freq_raw, total):
    """Same deterministic largest-remainder normalization as rans._table."""
    symbols = [i for i, f in enumerate(freq_raw) if f]
    scaled = [0] * 256
    if not symbols:
        return scaled
    rem = TOT
    for s in symbols:
        scaled[s] = max(1, (freq_raw[s] * TOT) // total)
        rem -= scaled[s]
    j = 0
    while rem > 0:
        scaled[symbols[j % len(symbols)]] += 1
        rem -= 1
        j += 1
    while rem < 0:
        s = symbols[j % len(symbols)]
        if scaled[s] > 1:
            scaled[s] -= 1
            rem += 1
        j += 1
    return scaled


def _cumfreq(scaled):
    cum = [0] * 256
    c = 0
    for s in range(256):
        cum[s] = c
        c += scaled[s]
    return cum


def _build_context_tables(data: bytes):
    counts = defaultdict(lambda: [0] * 256)
    prev = data[0]
    for b in data[1:]:
        counts[prev][b] += 1
        prev = b
    tables = {}
    for ctx, freq_raw in counts.items():
        total = sum(freq_raw)
        scaled = _normalize(freq_raw, total)
        tables[ctx] = (scaled, _cumfreq(scaled))
    return tables


def _encode_header(tables) -> bytes:
    out = bytearray()
    out += struct.pack("<H", len(tables))
    for ctx in sorted(tables):
        scaled, _ = tables[ctx]
        present = [s for s in range(256) if scaled[s]]
        out += struct.pack("<BH", ctx, len(present))
        for s in present:
            out += struct.pack("<BH", s, scaled[s])
    return bytes(out)


def _decode_header(payload: bytes, pos: int):
    (n_ctx,) = struct.unpack_from("<H", payload, pos)
    pos += 2
    tables = {}
    for _ in range(n_ctx):
        ctx, n_sym = struct.unpack_from("<BH", payload, pos)
        pos += 3
        scaled = [0] * 256
        for _ in range(n_sym):
            s, f = struct.unpack_from("<BH", payload, pos)
            pos += 3
            scaled[s] = f
        tables[ctx] = (scaled, _cumfreq(scaled))
    return tables, pos


def encode(data: bytes, order: int = 1) -> bytes:
    n = len(data)
    if n == 0:
        return bytes([_HEADER_MAGIC])
    if n == 1:
        return bytes([_HEADER_MAGIC, data[0]])

    tables = _build_context_tables(data)
    header = _encode_header(tables)

    state = RANS_L
    emitted = bytearray()
    for i in range(n - 1, 0, -1):
        ctx = data[i - 1]
        s = data[i]
        scaled, cum = tables[ctx]
        f = scaled[s]
        c = cum[s]
        while state >= ((RANS_L >> 12) * f << 8):
            emitted.append(state & 0xFF)
            state >>= 8
        state = ((state // f) << 12) + (state % f) + c

    return bytes([_HEADER_MAGIC]) + header + bytes([data[0]]) + struct.pack("<Q", state) + bytes(reversed(emitted))


def decode(payload: bytes, size: int, order: int = 1) -> bytes:
    if size == 0:
        return b""
    if not payload or payload[0] != _HEADER_MAGIC:
        raise ValueError("invalid order-1 payload")
    pos = 1
    if size == 1:
        if pos >= len(payload):
            raise ValueError("truncated order-1 payload")
        return bytes([payload[pos]])

    tables, pos = _decode_header(payload, pos)
    if pos >= len(payload):
        raise ValueError("truncated order-1 payload")
    first = payload[pos]
    pos += 1
    if pos + 8 > len(payload):
        raise ValueError("truncated order-1 state")
    state = struct.unpack_from("<Q", payload, pos)[0]
    pos += 8
    stream = payload[pos:]
    sp = 0

    out = bytearray(size)
    out[0] = first
    inv_cache = {}
    for i in range(1, size):
        ctx = out[i - 1]
        if ctx not in tables:
            raise ValueError("unknown order-1 context")
        scaled, cum = tables[ctx]
        inv = inv_cache.get(ctx)
        if inv is None:
            inv = [0] * TOT
            for sym in range(256):
                f = scaled[sym]
                if f:
                    c0 = cum[sym]
                    for x in range(c0, c0 + f):
                        inv[x] = sym
            inv_cache[ctx] = inv
        x = state & (TOT - 1)
        s = inv[x]
        f = scaled[s]
        c = cum[s]
        out[i] = s
        state = f * (state >> 12) + (x - c)
        while state < RANS_L:
            if sp >= len(stream):
                raise ValueError("truncated order-1 stream")
            state = (state << 8) | stream[sp]
            sp += 1
    return bytes(out)


def context_score(data: bytes, order: int = 1) -> float:
    """Cheap hint for the selector: how much does knowing the previous byte
    reduce uncertainty about the next one, roughly? Higher is more promising
    for this codec. Not used for correctness, only for candidate ordering."""
    if len(data) < 64:
        return 0.0
    tables = _build_context_tables(data)
    n = len(data) - 1
    if n <= 0:
        return 0.0
    total_bits = 0.0
    import math
    for ctx, freq_raw in _raw_counts(data).items():
        total = sum(freq_raw)
        for f in freq_raw:
            if f:
                p = f / total
                total_bits += -f * math.log2(p)
    return 1.0 - (total_bits / (n * 8)) if n else 0.0


def _raw_counts(data: bytes):
    counts = defaultdict(lambda: [0] * 256)
    prev = data[0]
    for b in data[1:]:
        counts[prev][b] += 1
        prev = b
    return counts

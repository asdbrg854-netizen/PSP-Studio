"""LZ77 + rANS: entropy-code the token stream instead of storing it raw.

Every LZ candidate elsewhere in this codebase (gpx.codecs.lz) stores its
token stream as fixed-width raw bytes: a literal is exactly 2 bytes, a
match is exactly 5 bytes, regardless of how skewed the underlying
literal/length/distance distributions are. That's a real, ordinary gap --
DEFLATE Huffman-codes its LZ77 tokens, LZMA range-codes them, zstd
FSE-codes them; storing them raw leaves compression on the table (this
project didn't have a codec for this at all until now, not even the
"conservative stub" honesty pattern used elsewhere -- there was just no LZ
entropy stage).

This reuses gpx.codecs.lz's matcher via parse_tokens() (identical search,
so identical matches to the raw LZ candidate) and separates the tokens into
independent streams before entropy coding each with order-0 rANS:

- control: one byte per token, literal (0) or match (1)
- literals: the literal byte values, in order
- length_lo / length_hi: low/high byte of (match_length - MIN_MATCH)
- dist_lo / dist_hi: low/high byte of (match_distance - 1)

Splitting into these six streams rather than entropy-coding the raw
interleaved bytes matters because each has its own, usually much more
skewed, distribution than the mixed stream: mostly-small lengths mean
length_hi is very often the same byte, run lengths concentrate distances
in a handful of common values, and literals keep whatever skew the
original data had without matched-out bytes diluting it. Since this is
built as its own selector candidate (see gpx/selector.py), it can only
ever help -- if it doesn't beat gpx.codecs.lz's raw output for a given
chunk, the size competition drops it.
"""
import struct

from .rans import encode as _rans_encode, decode_n as _rans_decode_n
from .lz import parse_tokens, MIN_MATCH


def _write_varint(out: bytearray, value: int):
    while True:
        b = value & 0x7F
        value >>= 7
        if value:
            out.append(b | 0x80)
        else:
            out.append(b)
            return


def _read_varint(payload: bytes, pos: int):
    value = 0
    shift = 0
    while True:
        b = payload[pos]
        pos += 1
        value |= (b & 0x7F) << shift
        if not (b & 0x80):
            return value, pos
        shift += 7


def _rans_pack(out: bytearray, raw: bytes):
    # Empty streams (e.g. no matches at all in this chunk -> no length/
    # distance streams needed) cost a single zero byte instead of paying
    # rANS's own small fixed per-call overhead on nothing.
    _write_varint(out, len(raw))
    if raw:
        z = _rans_encode(raw)
        _write_varint(out, len(z))
        out += z


def _rans_unpack(payload: bytes, pos: int):
    orig_len, pos = _read_varint(payload, pos)
    if not orig_len:
        return b"", pos
    comp_len, pos = _read_varint(payload, pos)
    raw = _rans_decode_n(payload[pos:pos + comp_len], orig_len)
    return raw, pos + comp_len


def encode(data: bytes, level: int = 3) -> bytes:
    return serialize(parse_tokens(data, level))


def serialize(tokens) -> bytes:
    control = bytearray()
    literals = bytearray()
    length_lo = bytearray()
    length_hi = bytearray()
    dist_lo = bytearray()
    dist_hi = bytearray()

    for tok in tokens:
        if tok[0] == "L":
            control.append(0)
            literals.append(tok[1])
        else:
            control.append(1)
            dist, ln = tok[1], tok[2]
            d = dist - 1
            l = ln - MIN_MATCH
            dist_lo.append(d & 0xFF)
            dist_hi.append((d >> 8) & 0xFF)
            length_lo.append(l & 0xFF)
            length_hi.append((l >> 8) & 0xFF)

    out = bytearray()
    _write_varint(out, len(tokens))
    for stream in (control, literals, length_lo, length_hi, dist_lo, dist_hi):
        _rans_pack(out, bytes(stream))
    return bytes(out)


def decode(payload: bytes, size: int) -> bytes:
    n_tokens, pos = _read_varint(payload, 0)

    control, pos = _rans_unpack(payload, pos)
    literals, pos = _rans_unpack(payload, pos)
    length_lo, pos = _rans_unpack(payload, pos)
    length_hi, pos = _rans_unpack(payload, pos)
    dist_lo, pos = _rans_unpack(payload, pos)
    dist_hi, pos = _rans_unpack(payload, pos)

    if len(control) != n_tokens:
        raise ValueError("lz_entropy control stream length mismatch")

    out = bytearray()
    li = mi = 0  # cursor into literals / match-field streams
    for c in control:
        if c == 0:
            if li >= len(literals):
                raise ValueError("truncated lz_entropy literals stream")
            out.append(literals[li])
            li += 1
        elif c == 1:
            if mi >= len(dist_lo):
                raise ValueError("truncated lz_entropy match stream")
            dist = (dist_lo[mi] | (dist_hi[mi] << 8)) + 1
            ln = (length_lo[mi] | (length_hi[mi] << 8)) + MIN_MATCH
            mi += 1
            if not dist or dist > len(out):
                raise ValueError("invalid lz_entropy distance")
            src = len(out) - dist
            for k in range(ln):
                out.append(out[src + k])
        else:
            raise ValueError("invalid lz_entropy control byte")

    if len(out) != size:
        raise ValueError("lz_entropy decoded size mismatch")
    return bytes(out)

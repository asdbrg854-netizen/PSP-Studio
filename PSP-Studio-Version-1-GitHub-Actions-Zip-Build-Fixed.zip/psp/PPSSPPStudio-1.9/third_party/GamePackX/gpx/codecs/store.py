def encode(data: bytes) -> bytes:
    return bytes(data)

def decode(data: bytes) -> bytes:
    return bytes(data)

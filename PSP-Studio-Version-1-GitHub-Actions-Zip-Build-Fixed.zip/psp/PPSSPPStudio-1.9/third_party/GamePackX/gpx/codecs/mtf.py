"""Move-to-front. Uses gpx._native's C implementation when available (same
algorithm, bit-exact output either way) since MTF's per-symbol list
search/shift is a tight loop that benefits from compiled code the same way
LZ and rANS do; see gpx/_native.py and gpx/native/gpx_native.c."""
from .. import _native

def _encode_py(data: bytes) -> bytes:
    alphabet = list(range(256))
    out = bytearray()
    for b in data:
        idx = alphabet.index(b)
        out.append(idx)
        alphabet.pop(idx)
        alphabet.insert(0, b)
    return bytes(out)

def _decode_py(data: bytes) -> bytes:
    alphabet = list(range(256))
    out = bytearray()
    for idx in data:
        if idx >= 256:
            raise ValueError("invalid MTF symbol")
        b = alphabet.pop(idx)
        out.append(b)
        alphabet.insert(0, b)
    return bytes(out)

def encode(data: bytes) -> bytes:
    if _native.AVAILABLE:
        return _native.mtf_encode(data)
    return _encode_py(data)

def decode(data: bytes) -> bytes:
    if _native.AVAILABLE:
        return _native.mtf_decode(data)
    return _decode_py(data)

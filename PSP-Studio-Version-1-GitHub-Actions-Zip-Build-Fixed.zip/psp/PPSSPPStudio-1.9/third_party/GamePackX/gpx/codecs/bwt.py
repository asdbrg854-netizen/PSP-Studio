"""Block BWT using an O(n log^2 n) prefix-doubling *cyclic* suffix array.

v1.0 used a naive rotation sort that materialized a full rotated copy of the
block for every comparison key (`data[i:] + data[:i]`), which is O(n^2) time
and O(n^2) memory pressure from string concatenation. That made BWT
unusable above a few tens of KB, so the encoder gated it out for any
real-sized chunk.

This version sorts the n cyclic rotations with prefix doubling: rank[i]
starts as the byte at i, and each round compares (rank[i], rank[i+k mod n])
to double the resolved comparison length, for O(log n) rounds of an O(n log n)
sort. When NumPy is available the per-round work (roll, combine, argsort,
cumulative rank) runs as vectorized C code, so multi-megabyte blocks finish
in a fraction of a second instead of not finishing at all. A pure-Python
fallback with the same asymptotic complexity is used if NumPy is missing.

Ties (identical rotations, which only happen for periodic data) are broken
by ascending original index -- the standard, provably-correct convention for
cyclic BWT -- via a stable sort applied to indices 0..n-1 every round.

The on-disk format (uint32 primary index + last column) is unchanged, so
this is a drop-in replacement for the previous encode()/decode() pair.
"""
import struct

try:
    import numpy as _np
    _HAVE_NUMPY = True
except ImportError:  # pragma: no cover - exercised only without numpy installed
    _HAVE_NUMPY = False


def _suffix_array_numpy(data: bytes):
    n = len(data)
    if n <= 1:
        return list(range(n))
    rank = _np.frombuffer(data, dtype=_np.uint8).astype(_np.int64)
    # The packed key must not let the secondary component spill into the
    # primary component's bucket. Ranks start as raw byte values (0..255)
    # before the first round collapses them to dense 0..n-1 ranks, so the
    # modulus has to cover whichever is larger.
    mod = _np.int64(max(n, 256) + 1)
    L = 1
    sa = None
    while True:
        shift = L  # guaranteed < n by the loop condition below
        rank2 = _np.roll(rank, -shift)
        combined = (rank + 1) * mod + (rank2 + 1)
        sa = _np.argsort(combined, kind="stable")
        sorted_combined = combined[sa]
        diff = _np.empty(n, dtype=_np.int64)
        diff[0] = 0
        _np.not_equal(sorted_combined[1:], sorted_combined[:-1], out=diff[1:])
        ranks_sorted = _np.cumsum(diff)
        new_rank = _np.empty(n, dtype=_np.int64)
        new_rank[sa] = ranks_sorted
        rank = new_rank
        if rank[sa[-1]] == n - 1:
            break
        L *= 2
        if L >= n:
            break
    return sa.tolist()


def _suffix_array_python(data: bytes):
    """Pure-Python fallback with the same O(n log^2 n) algorithm."""
    n = len(data)
    if n <= 1:
        return list(range(n))
    rank = list(data)
    L = 1
    idx = range(n)
    while True:
        shift = L
        pair = [(rank[i], rank[i - n + shift] if i + shift >= n else rank[i + shift]) for i in idx]
        sa = sorted(idx, key=pair.__getitem__)
        new_rank = [0] * n
        prev = pair[sa[0]]
        r = 0
        new_rank[sa[0]] = 0
        for i in range(1, n):
            cur = pair[sa[i]]
            if cur != prev:
                r += 1
                prev = cur
            new_rank[sa[i]] = r
        rank = new_rank
        if rank[sa[-1]] == n - 1:
            break
        L *= 2
        if L >= n:
            break
    return sa


def _suffix_array(data: bytes):
    if _HAVE_NUMPY:
        return _suffix_array_numpy(data)
    return _suffix_array_python(data)


def encode(data: bytes) -> bytes:
    n = len(data)
    if n == 0:
        return struct.pack("<I", 0)
    sa = _suffix_array(data)
    last = bytes(data[(i - 1) % n] for i in sa)
    primary = sa.index(0)
    return struct.pack("<I", primary) + last


def decode(payload: bytes) -> bytes:
    if len(payload) < 4:
        raise ValueError("truncated BWT")
    primary = struct.unpack_from("<I", payload, 0)[0]
    last = payload[4:]
    n = len(last)
    if n == 0:
        return b""
    if primary >= n:
        raise ValueError("invalid BWT primary index")
    counts = [0] * 256
    for b in last:
        counts[b] += 1
    starts = [0] * 256
    s = 0
    for b in range(256):
        starts[b] = s
        s += counts[b]
    occ = [0] * 256
    lf = [0] * n
    for i, b in enumerate(last):
        lf[i] = starts[b] + occ[b]
        occ[b] += 1
    out = bytearray(n)
    row = primary
    for i in range(n - 1, -1, -1):
        out[i] = last[row]
        row = lf[row]
    return bytes(out)

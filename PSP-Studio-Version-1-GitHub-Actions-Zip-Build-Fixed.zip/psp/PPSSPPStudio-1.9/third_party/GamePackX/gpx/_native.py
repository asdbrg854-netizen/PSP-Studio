"""Optional C acceleration, loaded via ctypes with a transparent fallback.

Every pure-Python codec in this project (gpx/codecs/lz.py, rans.py, mtf.py,
gpx/crc32c.py) remains fully correct and independently usable on its own --
this module is purely an accelerator, following the same pattern already
used for BWT's NumPy suffix array (gpx/codecs/bwt.py): try to use the fast
path, fall back cleanly if it isn't available, and never let its absence
change what gets produced, only how fast.

`AVAILABLE` is False (and every function in this module unusable) if:
- no C compiler is found (checks $CC, then `cc`, then `gcc`)
- compilation fails for any reason
- the resulting shared library fails to load

Callers must check AVAILABLE before calling anything else here; nothing in
this module raises ImportError as a way of signaling unavailability.

The compiled library is cached (keyed by a hash of the source, so it
rebuilds automatically if gpx/native/gpx_native.c ever changes) next to the
source under gpx/native/_cache/, falling back to a per-user temp directory
if that location isn't writable (e.g. a read-only site-packages install).
"""
import ctypes
import hashlib
import os
import platform
import subprocess
import tempfile

_SRC = os.path.join(os.path.dirname(__file__), "native", "gpx_native.c")
_OVERFLOW = ctypes.c_size_t(-1).value


def _cache_path():
    with open(_SRC, "rb") as f:
        digest = hashlib.sha256(f.read()).hexdigest()[:16]
    tag = f"{platform.machine()}-{platform.system()}-{digest}"
    filename = f"gpx_native-{tag}.so"

    local_dir = os.path.join(os.path.dirname(__file__), "native", "_cache")
    try:
        os.makedirs(local_dir, exist_ok=True)
        candidate = os.path.join(local_dir, filename)
        # Confirm the directory is actually writable, not just creatable.
        probe = candidate + ".probe"
        with open(probe, "wb"):
            pass
        os.unlink(probe)
        return candidate
    except OSError:
        pass

    tmp_dir = os.path.join(tempfile.gettempdir(), "gamepack-x-native-cache")
    os.makedirs(tmp_dir, exist_ok=True)
    return os.path.join(tmp_dir, filename)


def _build_and_load():
    if not os.path.exists(_SRC):
        return None
    try:
        so_path = _cache_path()
    except OSError:
        return None

    if not os.path.exists(so_path):
        cc = os.environ.get("CC") or "cc"
        candidates = [cc] if cc == "cc" else [cc, "cc", "gcc"]
        built = False
        for compiler in candidates:
            cmd = [compiler, "-O3", "-fPIC", "-shared", "-o", so_path, _SRC]
            try:
                subprocess.run(cmd, check=True, capture_output=True, timeout=120)
                built = True
                break
            except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired, OSError):
                continue
        if not built:
            return None

    try:
        return ctypes.CDLL(so_path)
    except OSError:
        return None


_lib = _build_and_load()
AVAILABLE = _lib is not None

if AVAILABLE:
    _lib.gpx_lz_parse.restype = ctypes.c_size_t
    _lib.gpx_lz_parse.argtypes = [
        ctypes.c_char_p, ctypes.c_size_t, ctypes.c_int, ctypes.c_int,
        ctypes.c_int, ctypes.c_char_p, ctypes.c_size_t,
    ]
    _lib.gpx_rans_encode.restype = ctypes.c_size_t
    _lib.gpx_rans_encode.argtypes = [ctypes.c_char_p, ctypes.c_size_t, ctypes.c_char_p, ctypes.c_size_t]
    _lib.gpx_rans_decode_n.restype = ctypes.c_int
    _lib.gpx_rans_decode_n.argtypes = [ctypes.c_char_p, ctypes.c_size_t, ctypes.c_size_t, ctypes.c_char_p]
    _lib.gpx_mtf_encode.restype = None
    _lib.gpx_mtf_encode.argtypes = [ctypes.c_char_p, ctypes.c_size_t, ctypes.c_char_p]
    _lib.gpx_mtf_decode.restype = None
    _lib.gpx_mtf_decode.argtypes = [ctypes.c_char_p, ctypes.c_size_t, ctypes.c_char_p]
    _lib.gpx_crc32c.restype = ctypes.c_uint32
    _lib.gpx_crc32c.argtypes = [ctypes.c_char_p, ctypes.c_size_t, ctypes.c_uint32]


def lz_parse(data: bytes, chain_depth: int, lazy: bool, nice_match: int) -> bytes:
    """Returns the same raw token serialization as gpx.codecs.lz.serialize_raw()
    would for the same input/parameters -- gpx.codecs.lz.decode() (and its own
    serialize_raw, for the raw-format candidate) already understands this
    unchanged, and parse_tokens() re-derives the tuple form with a cheap
    linear rescan rather than needing a second C output format."""
    out_cap = 2 * len(data) + 16
    out = ctypes.create_string_buffer(out_cap)
    n = _lib.gpx_lz_parse(data, len(data), int(chain_depth), int(bool(lazy)), int(nice_match), out, out_cap)
    if n == _OVERFLOW:
        raise RuntimeError("gpx_lz_parse: output buffer too small (this should not happen)")
    return out.raw[:n]


def rans_encode(data: bytes) -> bytes:
    """Bit-exact with gpx.codecs.rans.encode() -- verified in
    tests/test_native.py by cross-decoding with the pure-Python decoder."""
    out_cap = 2 + 256 * 3 + 8 + 5 * len(data) + 64
    out = ctypes.create_string_buffer(out_cap)
    n = _lib.gpx_rans_encode(data, len(data), out, out_cap)
    if n == _OVERFLOW:
        raise RuntimeError("gpx_rans_encode: output buffer too small (this should not happen)")
    return out.raw[:n]


def rans_decode_n(payload: bytes, n: int) -> bytes:
    if n == 0:
        return b""
    out = ctypes.create_string_buffer(n)
    r = _lib.gpx_rans_decode_n(payload, len(payload), n, out)
    if r != 0:
        raise ValueError("native rANS decode: truncated or malformed payload")
    return out.raw[:n]


def mtf_encode(data: bytes) -> bytes:
    if not data:
        return b""
    out = ctypes.create_string_buffer(len(data))
    _lib.gpx_mtf_encode(data, len(data), out)
    return out.raw[:len(data)]


def mtf_decode(data: bytes) -> bytes:
    if not data:
        return b""
    out = ctypes.create_string_buffer(len(data))
    _lib.gpx_mtf_decode(data, len(data), out)
    return out.raw[:len(data)]


def crc32c(data: bytes, crc: int = 0) -> int:
    return _lib.gpx_crc32c(data, len(data), crc) & 0xFFFFFFFF

"""GamePack X lossless compression engine."""
__version__ = "1.2.0"

"""Streaming helpers for very large files."""
from typing import BinaryIO, Iterator

def iter_file_chunks(f: BinaryIO, chunk_size: int) -> Iterator[bytes]:
    if chunk_size <= 0:
        raise ValueError("chunk_size must be positive")
    while True:
        b = f.read(chunk_size)
        if not b:
            return
        yield b

def iter_path_chunks(path, chunk_size: int):
    with open(path, "rb") as f:
        yield from iter_file_chunks(f, chunk_size)

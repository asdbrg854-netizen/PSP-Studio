/* gpx_native.c -- optional C acceleration for GamePack X's hottest loops.
 *
 * This is NOT a replacement for the pure-Python codecs -- gpx/codecs/lz.py,
 * gpx/codecs/rans.py etc. remain the reference implementation and the
 * fallback when this can't be built (no compiler, restricted environment).
 * Every function here reproduces the *exact* algorithm and wire format of
 * its Python counterpart, checked in tests/test_native.py by cross-decoding
 * (encode in C, decode in Python, and the reverse) and by fuzzing against
 * the pure-Python implementation on thousands of random inputs.
 *
 * Built as a plain C shared library (no Python.h, no CPython ABI
 * dependency) loaded via ctypes from gpx/_native.py, specifically so it
 * doesn't need to match the exact Python version/build the way a real
 * CPython extension module would -- it only needs a C compiler to exist
 * once, at first use, and the compiled .so is cached under
 * gpx/native/_cache/ for reuse.
 *
 * Bit-exact format compatibility with the Python reference matters more
 * than usual here: a file compressed with this available and decompressed
 * later without it (or on a different machine) must still decode
 * correctly, so the *wire format* -- not just "a working implementation of
 * the same algorithm" -- has to match gpx/codecs/lz.py and
 * gpx/codecs/rans.py exactly.
 */
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdlib.h>

/* ---------------------------------------------------------------------
 * LZ77 parsing -- mirrors gpx/codecs/lz.py's parse_tokens()/serialize_raw()
 * combined: produces the same raw token stream directly (0x00+byte for a
 * literal, 0x01+dist:u16le+len:u16le for a match), so the existing Python
 * lz.decode() already understands this output unchanged, and
 * lz_entropy.py can re-derive tokens from it with a cheap linear rescan
 * instead of needing a second C output format.
 * ------------------------------------------------------------------- */

#define GPX_WINDOW 65535
#define GPX_MAX_LEN 65535
#define GPX_MIN_MATCH 3
#define GPX_HASH_BITS 16
#define GPX_HASH_SIZE (1u << GPX_HASH_BITS)
#define GPX_HASH_MASK (GPX_HASH_SIZE - 1u)

static inline uint32_t gpx_hash3(const uint8_t *p) {
    uint32_t v = ((uint32_t)p[0] << 16) | ((uint32_t)p[1] << 8) | (uint32_t)p[2];
    return (v * 2654435761u) >> (32 - GPX_HASH_BITS);
}

/* Returns bytes written on success, or (size_t)-1 if out_cap is too small
 * (should never happen when the caller sizes out_cap as 2*n, the
 * mathematical worst case: every input byte becomes a 2-byte literal
 * token, and any match token is at most 5 bytes for at least 3 input
 * bytes, i.e. never worse than 2 bytes/input-byte either). */
size_t gpx_lz_parse(const uint8_t *data, size_t n,
                     int chain_depth, int lazy, int nice_match,
                     uint8_t *out, size_t out_cap) {
    if (n == 0) return 0;

    int32_t *head = (int32_t *)malloc(GPX_HASH_SIZE * sizeof(int32_t));
    int32_t *prev = (int32_t *)malloc(n * sizeof(int32_t));
    if (!head || !prev) { free(head); free(prev); return (size_t)-1; }
    memset(head, -1, GPX_HASH_SIZE * sizeof(int32_t));

    size_t out_pos = 0;
    size_t i = 0;

#define GPX_INSERT(pos) do { \
        if ((pos) + 3 <= n) { \
            uint32_t h = gpx_hash3(data + (pos)); \
            prev[(pos)] = head[h]; \
            head[h] = (int32_t)(pos); \
        } \
    } while (0)

    while (i < n) {
        size_t best_len = 0;
        uint32_t best_dist = 0;
        size_t limit_outer = (n - i < (size_t)GPX_MAX_LEN) ? (n - i) : (size_t)GPX_MAX_LEN;

        if (i + 3 <= n) {
            uint32_t h = gpx_hash3(data + i);
            int32_t pos = head[h];
            int checked = 0;
            while (pos != -1 && checked < chain_depth) {
                size_t dist = i - (size_t)pos;
                if (dist > (size_t)GPX_WINDOW) break;
                checked++;
                if (best_len) {
                    size_t probe = best_len;
                    if ((size_t)pos + probe < n && i + probe < n &&
                        data[(size_t)pos + probe] != data[i + probe]) {
                        pos = prev[pos];
                        continue;
                    }
                }
                size_t ln = 0;
                while (ln < limit_outer && data[(size_t)pos + ln] == data[i + ln]) ln++;
                if (ln > best_len) {
                    best_len = ln;
                    best_dist = (uint32_t)dist;
                    if (best_len >= (size_t)nice_match || best_len >= limit_outer) break;
                }
                pos = prev[pos];
            }
        }

        if (lazy && best_len >= GPX_MIN_MATCH && i + 1 < n) {
            GPX_INSERT(i);
            size_t next_best_len = 0;
            if (i + 1 + 3 <= n) {
                uint32_t h2 = gpx_hash3(data + i + 1);
                int32_t pos2 = head[h2];
                int checked2 = 0;
                size_t limit_outer2 = (n - (i + 1) < (size_t)GPX_MAX_LEN) ? (n - (i + 1)) : (size_t)GPX_MAX_LEN;
                while (pos2 != -1 && checked2 < chain_depth) {
                    size_t dist2 = (i + 1) - (size_t)pos2;
                    if (dist2 > (size_t)GPX_WINDOW) break;
                    checked2++;
                    if (next_best_len) {
                        size_t probe = next_best_len;
                        if ((size_t)pos2 + probe < n && (i + 1) + probe < n &&
                            data[(size_t)pos2 + probe] != data[(i + 1) + probe]) {
                            pos2 = prev[pos2];
                            continue;
                        }
                    }
                    size_t ln2 = 0;
                    while (ln2 < limit_outer2 && data[(size_t)pos2 + ln2] == data[(i + 1) + ln2]) ln2++;
                    if (ln2 > next_best_len) {
                        next_best_len = ln2;
                        if (next_best_len >= (size_t)nice_match || next_best_len >= limit_outer2) break;
                    }
                    pos2 = prev[pos2];
                }
            }
            if (next_best_len > best_len) {
                if (out_pos + 2 > out_cap) { free(head); free(prev); return (size_t)-1; }
                out[out_pos++] = 0;
                out[out_pos++] = data[i];
                i++;
                continue;
            }
        }

        if (best_len >= GPX_MIN_MATCH) {
            if (out_pos + 5 > out_cap) { free(head); free(prev); return (size_t)-1; }
            out[out_pos++] = 1;
            out[out_pos++] = (uint8_t)(best_dist & 0xFF);
            out[out_pos++] = (uint8_t)((best_dist >> 8) & 0xFF);
            out[out_pos++] = (uint8_t)(best_len & 0xFF);
            out[out_pos++] = (uint8_t)((best_len >> 8) & 0xFF);
            size_t end = i + best_len;
            while (i < end) { GPX_INSERT(i); i++; }
        } else {
            if (out_pos + 2 > out_cap) { free(head); free(prev); return (size_t)-1; }
            out[out_pos++] = 0;
            out[out_pos++] = data[i];
            GPX_INSERT(i);
            i++;
        }
    }

#undef GPX_INSERT
    free(head);
    free(prev);
    return out_pos;
}

/* ---------------------------------------------------------------------
 * rANS order-0 -- mirrors gpx/codecs/rans.py exactly: same TOT=4096,
 * same RANS_L=1<<23, same header layout (u16 symbol count, then that many
 * (u8 symbol, u16 freq) pairs in ascending symbol order, then u64 final
 * state, then the renormalization byte stream), same deterministic
 * largest-remainder frequency normalization.
 * ------------------------------------------------------------------- */

#define GPX_RANS_L (1u << 23)
#define GPX_TOT 4096

static void gpx_rans_table(const uint8_t *data, size_t n, uint16_t *freq /* [256] */) {
    uint32_t raw[256];
    memset(raw, 0, sizeof(raw));
    for (size_t i = 0; i < n; i++) raw[data[i]]++;

    int symbols[256], n_symbols = 0;
    for (int s = 0; s < 256; s++) if (raw[s]) symbols[n_symbols++] = s;

    memset(freq, 0, 256 * sizeof(uint16_t));
    if (n_symbols == 0) return;

    long rem = GPX_TOT;
    for (int k = 0; k < n_symbols; k++) {
        int s = symbols[k];
        uint32_t f = (uint32_t)(((uint64_t)raw[s] * GPX_TOT) / n);
        if (f < 1) f = 1;
        freq[s] = (uint16_t)f;
        rem -= f;
    }
    int j = 0;
    while (rem > 0) {
        freq[symbols[j % n_symbols]]++;
        rem--; j++;
    }
    j = 0;
    while (rem < 0) {
        int s = symbols[j % n_symbols];
        if (freq[s] > 1) { freq[s]--; rem++; }
        j++;
    }
}

/* Returns bytes written, or (size_t)-1 on failure (out_cap too small).
 * Safe out_cap upper bound: 2 (count) + 256*3 (table) + 8 (state) + 5*n
 * (renormalization can emit at most ~2-3 bytes per symbol in the worst
 * case of a near-uniform table; 5*n is a deliberately generous margin). */
size_t gpx_rans_encode(const uint8_t *data, size_t n, uint8_t *out, size_t out_cap) {
    if (n == 0) {
        if (out_cap < 2) return (size_t)-1;
        out[0] = 0; out[1] = 0;
        return 2;
    }

    uint16_t freq[256];
    gpx_rans_table(data, n, freq);

    uint32_t cum[256];
    { uint32_t c = 0; for (int s = 0; s < 256; s++) { cum[s] = c; c += freq[s]; } }

    int n_symbols = 0;
    for (int s = 0; s < 256; s++) if (freq[s]) n_symbols++;
    size_t header_len = 2 + (size_t)n_symbols * 3;
    if (header_len + 8 > out_cap) return (size_t)-1;

    /* Encode into a scratch buffer growing from the end backward isn't
     * practical in C without a dynamic buffer, so emit forward into a
     * temporary buffer sized like the Python emitted bytearray, then
     * reverse it -- exactly mirroring encode()'s `bytes(reversed(emitted))`. */
    uint8_t *emitted = (uint8_t *)malloc(out_cap); /* upper bound, same buffer budget as final output */
    if (!emitted) return (size_t)-1;
    size_t emitted_len = 0;

    uint64_t state = GPX_RANS_L;
    for (size_t idx = n; idx > 0; idx--) {
        uint8_t s = data[idx - 1];
        uint32_t f = freq[s];
        uint64_t bound = ((uint64_t)(GPX_RANS_L >> 12) * f) << 8;
        while (state >= bound) {
            if (emitted_len >= out_cap) { free(emitted); return (size_t)-1; }
            emitted[emitted_len++] = (uint8_t)(state & 0xFF);
            state >>= 8;
        }
        state = ((state / f) << 12) + (state % f) + cum[s];
    }

    size_t pos = 0;
    out[pos++] = (uint8_t)(n_symbols & 0xFF);
    out[pos++] = (uint8_t)((n_symbols >> 8) & 0xFF);
    for (int s = 0; s < 256; s++) {
        if (freq[s]) {
            out[pos++] = (uint8_t)s;
            out[pos++] = (uint8_t)(freq[s] & 0xFF);
            out[pos++] = (uint8_t)((freq[s] >> 8) & 0xFF);
        }
    }
    for (int b = 0; b < 8; b++) out[pos++] = (uint8_t)((state >> (8 * b)) & 0xFF);

    if (pos + emitted_len > out_cap) { free(emitted); return (size_t)-1; }
    for (size_t k = 0; k < emitted_len; k++) out[pos++] = emitted[emitted_len - 1 - k];
    free(emitted);
    return pos;
}

/* Returns 0 on success, -1 on any format/bounds error. out must have
 * capacity >= n. */
int gpx_rans_decode_n(const uint8_t *payload, size_t payload_len, size_t n, uint8_t *out) {
    if (n == 0) return 0;
    if (payload_len < 2) return -1;
    uint16_t n_symbols = (uint16_t)(payload[0] | (payload[1] << 8));
    size_t pos = 2;
    uint16_t freq[256];
    memset(freq, 0, sizeof(freq));
    for (uint16_t k = 0; k < n_symbols; k++) {
        if (pos + 3 > payload_len) return -1;
        uint8_t s = payload[pos];
        uint16_t f = (uint16_t)(payload[pos + 1] | (payload[pos + 2] << 8));
        pos += 3;
        freq[s] = f;
    }
    if (pos + 8 > payload_len) return -1;
    uint64_t state = 0;
    for (int b = 0; b < 8; b++) state |= ((uint64_t)payload[pos + b]) << (8 * b);
    pos += 8;
    const uint8_t *stream = payload + pos;
    size_t stream_len = payload_len - pos;
    size_t sp = 0;

    uint32_t cum[256];
    static uint8_t inv[GPX_TOT]; /* static: this file is not thread-shared across concurrent calls */
    { uint32_t c = 0;
      for (int s = 0; s < 256; s++) {
          cum[s] = c;
          for (uint32_t x = c; x < c + freq[s]; x++) inv[x] = (uint8_t)s;
          c += freq[s];
      }
    }

    for (size_t i = 0; i < n; i++) {
        uint32_t x = (uint32_t)(state & (GPX_TOT - 1));
        uint8_t s = inv[x];
        out[i] = s;
        state = (uint64_t)freq[s] * (state >> 12) + (x - cum[s]);
        while (state < GPX_RANS_L) {
            if (sp >= stream_len) return -1;
            state = (state << 8) | stream[sp++];
        }
    }
    return 0;
}

/* ---------------------------------------------------------------------
 * MTF -- mirrors gpx/codecs/mtf.py.
 * ------------------------------------------------------------------- */
void gpx_mtf_encode(const uint8_t *data, size_t n, uint8_t *out) {
    uint8_t table[256];
    for (int i = 0; i < 256; i++) table[i] = (uint8_t)i;
    for (size_t i = 0; i < n; i++) {
        uint8_t b = data[i];
        int idx = 0;
        while (table[idx] != b) idx++;
        out[i] = (uint8_t)idx;
        memmove(table + 1, table, idx);
        table[0] = b;
    }
}

void gpx_mtf_decode(const uint8_t *data, size_t n, uint8_t *out) {
    uint8_t table[256];
    for (int i = 0; i < 256; i++) table[i] = (uint8_t)i;
    for (size_t i = 0; i < n; i++) {
        uint8_t idx = data[i];
        uint8_t b = table[idx];
        out[i] = b;
        memmove(table + 1, table, idx);
        table[0] = b;
    }
}

/* ---------------------------------------------------------------------
 * CRC32C -- mirrors gpx/crc32c.py's byte-at-a-time table method exactly
 * (that file explains why the slice-by-N trick was tried and dropped in
 * pure Python; the reasoning doesn't apply here since this runs as
 * compiled code, but it's included mainly for completeness/consistency
 * with the rest of the native module, not because it was the dominant
 * cost -- CRC was never the bottleneck; LZ and rANS were).
 * ------------------------------------------------------------------- */
static uint32_t gpx_crc32c_table[256];
static int gpx_crc32c_table_ready = 0;

static void gpx_crc32c_init(void) {
    const uint32_t poly = 0x82F63B78u;
    for (int n = 0; n < 256; n++) {
        uint32_t c = (uint32_t)n;
        for (int k = 0; k < 8; k++) c = (c >> 1) ^ (poly & (-(int32_t)(c & 1)));
        gpx_crc32c_table[n] = c;
    }
    gpx_crc32c_table_ready = 1;
}

uint32_t gpx_crc32c(const uint8_t *data, size_t n, uint32_t crc) {
    if (!gpx_crc32c_table_ready) gpx_crc32c_init();
    uint32_t c = crc ^ 0xFFFFFFFFu;
    for (size_t i = 0; i < n; i++) c = gpx_crc32c_table[(c ^ data[i]) & 0xFF] ^ (c >> 8);
    return c ^ 0xFFFFFFFFu;
}

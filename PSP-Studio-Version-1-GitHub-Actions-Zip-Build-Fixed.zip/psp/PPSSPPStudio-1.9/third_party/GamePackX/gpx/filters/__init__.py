from .delta import delta_encode, delta_decode
from .executable import executable_encode, executable_decode

FILTER_NONE = 0
FILTER_DELTA1 = 1
FILTER_DELTA2 = 2
FILTER_DELTA4 = 3
FILTER_DELTA8 = 4
FILTER_X86 = 10
FILTER_X64 = 11
FILTER_ARM = 12
FILTER_ARM64 = 13
FILTER_POINTER = 20
FILTER_TEXTURE = 21

__all__ = [
    "FILTER_NONE", "FILTER_DELTA1", "FILTER_DELTA2", "FILTER_DELTA4",
    "FILTER_DELTA8", "FILTER_X86", "FILTER_X64", "FILTER_ARM",
    "FILTER_ARM64", "FILTER_POINTER", "FILTER_TEXTURE",
    "delta_encode", "delta_decode", "executable_encode", "executable_decode",
]

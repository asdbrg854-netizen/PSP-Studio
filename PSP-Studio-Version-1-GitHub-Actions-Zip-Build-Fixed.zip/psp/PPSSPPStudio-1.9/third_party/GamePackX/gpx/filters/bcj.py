"""Conservative BCJ extension point.

The transform is intentionally identity in v1.1 unless a future
architecture-specific implementation is registered. This guarantees
reversibility rather than applying a risky heuristic.
"""
ARCH_X86 = 1
ARCH_X64 = 2
ARCH_ARM = 3
ARCH_ARM64 = 4

def encode(data: bytes, arch: int) -> bytes:
    if arch not in (ARCH_X86, ARCH_X64, ARCH_ARM, ARCH_ARM64):
        raise ValueError("unsupported BCJ architecture")
    return bytes(data)

def decode(data: bytes, arch: int) -> bytes:
    return encode(data, arch)

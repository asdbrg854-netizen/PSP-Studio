"""Conservative executable-filter extension point.

A full BCJ implementation is deliberately not enabled by default in v1.
The identity transform is always reversible and preserves compatibility.
"""

def executable_encode(data: bytes, arch: str) -> bytes:
    if arch not in {"x86", "x64", "arm", "arm64"}:
        raise ValueError("unsupported architecture")
    return bytes(data)

def executable_decode(data: bytes, arch: str) -> bytes:
    return executable_encode(data, arch)

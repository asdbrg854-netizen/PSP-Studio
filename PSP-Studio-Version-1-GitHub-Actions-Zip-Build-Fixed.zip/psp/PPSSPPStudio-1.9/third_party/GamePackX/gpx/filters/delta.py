"""Reversible byte-wise delta filters."""

def delta_encode(data: bytes, distance: int) -> bytes:
    if distance <= 0:
        raise ValueError("distance must be positive")
    out = bytearray(data)
    for i in range(len(out) - 1, distance - 1, -1):
        out[i] = (out[i] - out[i - distance]) & 0xFF
    return bytes(out)

def delta_decode(data: bytes, distance: int) -> bytes:
    if distance <= 0:
        raise ValueError("distance must be positive")
    out = bytearray(data)
    for i in range(distance, len(out)):
        out[i] = (out[i] + out[i - distance]) & 0xFF
    return bytes(out)

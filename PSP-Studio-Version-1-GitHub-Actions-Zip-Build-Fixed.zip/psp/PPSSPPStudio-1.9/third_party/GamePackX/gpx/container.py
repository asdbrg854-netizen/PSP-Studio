"""GPX v1 container reader/writer -- the .gpj file format.

All integers are little-endian. The fixed header is 64 bytes.
"""
import struct
from dataclasses import dataclass
from .integrity import sha256_bytes, crc32c

MAGIC=b"GPJ\x01"
VERSION=1
HEADER=struct.Struct("<4sHHQQQQQQ")
# magic, version, flags, original_size, chunk_count, metadata_off,
# index_off, data_off, footer_off
CHUNK=struct.Struct("<BBHQQ32sIQI")
# method, filter, flags, original_size, compressed_size, sha256, crc32c, payload_off, reference

@dataclass
class ChunkEntry:
    method:int; filter_id:int; flags:int; original_size:int; compressed_size:int
    digest:bytes; crc:int; payload_offset:int; reference:int

def write_gpx(path, original_size, chunks, metadata=b""):
    metadata_off=HEADER.size
    index_off=metadata_off+len(metadata)
    data_off=index_off+CHUNK.size*len(chunks)
    payload=bytearray()
    entries=[]
    for c in chunks:
        off=data_off+len(payload)
        payload += c["payload"]
        entries.append(ChunkEntry(c["method"],c["filter"],c.get("flags",0),
            c["original_size"],len(c["payload"]),c["sha256"],c["crc"],off,c.get("reference",0)))
    footer_off=data_off+len(payload)
    index=b"".join(CHUNK.pack(e.method,e.filter_id,e.flags,e.original_size,e.compressed_size,
                              e.digest,e.crc,e.payload_offset,e.reference) for e in entries)
    whole=bytearray()
    whole += HEADER.pack(MAGIC,VERSION,0,original_size,len(entries),metadata_off,index_off,data_off,footer_off)
    whole += metadata+index+payload
    whole_digest=sha256_bytes(whole)
    whole += b"GPJF"+whole_digest
    with open(path,"wb") as f: f.write(whole)
    return whole_digest

def read_gpx(path):
    with open(path,"rb") as f: raw=f.read()
    if len(raw)<HEADER.size+36: raise ValueError("truncated .gpj file")
    vals=HEADER.unpack_from(raw,0)
    magic,ver,flags,orig,count,meta,index,data,footer=vals
    if magic!=MAGIC or ver!=VERSION: raise ValueError("unsupported .gpj format or version")
    if not (HEADER.size<=meta<=index<=data<=footer<=len(raw)-36): raise ValueError("invalid offsets")
    if index+count*CHUNK.size>data: raise ValueError("invalid index bounds")
    entries=[]
    for i in range(count):
        v=CHUNK.unpack_from(raw,index+i*CHUNK.size)
        entries.append(ChunkEntry(*v))
    if raw[footer:footer+4] != b"GPJF": raise ValueError("invalid footer")
    stored=raw[footer+4:footer+36]
    if sha256_bytes(raw[:footer]) != stored: raise ValueError("file SHA-256 mismatch")
    return raw, vals, entries

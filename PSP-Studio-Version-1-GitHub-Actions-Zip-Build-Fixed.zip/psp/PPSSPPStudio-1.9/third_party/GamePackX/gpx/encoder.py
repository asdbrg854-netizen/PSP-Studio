"""Chunk-parallel GPX encoder.

v1.1 parallelized chunks with a ThreadPoolExecutor. Since every candidate
codec here is pure-Python CPU work, the GIL meant -j > 1 bought nothing --
threads just took turns on one core, so wall-clock time with -j 4 was the
same as -j 1 (sometimes slightly worse, from thread-switching overhead).
This now uses ProcessPoolExecutor so multiple chunks genuinely compress on
separate cores, with a safe fallback to sequential execution if process
pools aren't available in the current environment (e.g. some restricted
sandboxes disallow fork/spawn).

The actual candidate logic (what to try, in what order, gated by what
size/memory limits) lives in gpx.selector now, shared with the (previously
drifted, previously unused) selector.py cost model instead of being
duplicated here.
"""
import os
from concurrent.futures import ProcessPoolExecutor

from .chunker import fixed_chunks
from .integrity import sha256_bytes, crc32c
from .container import write_gpx
from .selector import select_candidate


def _worker(args):
    idx, data, level, mem = args
    c = select_candidate(data, level, mem)
    return idx, {
        "method": c.method, "filter": c.filter_id, "flags": 0,
        "original_size": len(data), "payload": c.payload,
        "sha256": sha256_bytes(data), "crc": crc32c(data), "name": c.name,
    }


def compress_file(src, dst, level=3, jobs=1, chunk_size=1024 * 1024, memory_limit=4 * 1024 ** 3):
    with open(src, "rb") as f:
        data = f.read()
    chunks = list(fixed_chunks(data, chunk_size))
    per = max(1, memory_limit // max(1, jobs))
    args = [(i, c, level, per) for i, c in enumerate(chunks)]

    if jobs > 1 and len(args) > 1:
        try:
            with ProcessPoolExecutor(max_workers=jobs) as ex:
                results = list(ex.map(_worker, args))
        except OSError:
            # Some sandboxed environments block fork()/spawn(); degrade to
            # sequential rather than fail the whole compression job.
            results = [_worker(a) for a in args]
    else:
        results = [_worker(a) for a in args]

    results.sort(key=lambda x: x[0])

    # Dedup identical chunks after compression selection.
    #
    # Bug #1 (v1.1): this recorded `seen[key] = len(seen)` -- the count of
    # distinct hashes seen so far -- instead of the chunk's real index.
    # Those only coincide by accident until the first dedup happens; after
    # that, a later *new* unique chunk could be assigned a target index that
    # didn't match its own position, and a further duplicate of it would
    # resolve to the wrong data on decode.
    #
    # Bug #2 (also present in v1.1, independent of bug #1): the container
    # format uses `reference == 0` to mean "not a dedup reference" (see the
    # `if e.reference:` check in decoder.py). But 0 is also a perfectly
    # valid target -- the file's first chunk. So if the first chunk's
    # content ever repeats later in the same file, the duplicate's
    # reference is indistinguishable from "no reference" and decode
    # corrupts that chunk. This was reproducible with plain STORE/RLE
    # chunks, unrelated to anything else changed in this pass -- see
    # tests/test_v1_2_improvements.py::TestDedupIndexBugfix.
    #
    # Fixed by storing references 1-based (0 stays reserved as the sentinel,
    # a real reference to chunk k is stored as k+1); decoder.py subtracts 1
    # back out.
    seen = {}
    for i, c in results:
        key = c["sha256"]
        if key in seen:
            c["reference"] = seen[key] + 1
            c["payload"] = b""
            c["method"] = 0
            c["filter"] = 0
        else:
            c["reference"] = 0
            seen[key] = i

    digest = write_gpx(dst, len(data), [c for _, c in results], metadata=b"GamePack X v1\n")
    return {
        "original": len(data), "chunks": len(chunks), "gpj_sha256": digest.hex(),
        "methods": [c["name"] for _, c in results],
    }

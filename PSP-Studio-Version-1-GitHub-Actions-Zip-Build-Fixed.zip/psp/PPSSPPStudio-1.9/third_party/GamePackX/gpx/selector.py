"""Cost-based adaptive candidate selection -- the single source of truth.

v1.1 had two independent implementations of "try every codec and keep the
smallest": one here, gated at data <= 2 MiB for BWT and <= 1 MiB for PPM,
and a second, different one inlined in gpx/encoder.py, gated at data <=
32768 bytes for both. Only the encoder.py copy was ever actually called, so
this file's gates were pure documentation that no longer matched reality.
That kind of drift is exactly how the BWT path ended up silently disabled
for any chunk over 32 KiB.

encoder.py now calls select_candidate() below, so there is one gate to
reason about. The BWT path is no longer a whole-chunk-size cutoff: it runs
through gpx.pipelines, which sub-blocks large input for the suffix sort
(see pipelines.bwt_block_size_for_level), so it stays reachable at normal
chunk sizes instead of being skipped above 32 KiB.
"""
from dataclasses import dataclass

from . import pipelines
from .analyzer import analyze, segment_entropy_spread
from .codecs import (
    METHOD_STORE, METHOD_RLE, METHOD_LZ, METHOD_BWT_MTF_RANS,
    METHOD_PPM_RANS, METHOD_PPM_ARITH, METHOD_LZ_ENTROPY,
)
from .codecs.store import encode as store_encode
from .codecs.rle import encode as rle_encode
from .codecs import lz as lz_codec
from .codecs import lz_entropy as lz_entropy_codec
from .codecs.ppm import encode as ppm_encode
from .codecs.arithmetic import encode as arithmetic_encode
from .filters.delta import delta_encode

# Above this, an order-0/order-1 rANS pass over the *whole* chunk is still
# linear-time and cheap, but the per-context header in the order-1 case can
# get large for small inputs relative to the savings, so it isn't worth
# attempting on tiny chunks. This just avoids wasted CPU; the size
# competition against STORE/RLE/LZ would reject a bad candidate anyway.
_PPM_MIN_SIZE = 256
_PPM_MAX_SIZE = {1: 0, 2: 0, 3: 512 * 1024, 4: 2 * 1024 * 1024, 5: 8 * 1024 * 1024}

# Both conditions together mark a chunk as *uniformly* close to random --
# not just "high average entropy" (which a chunk with a small repetitive
# pocket in an otherwise-random payload, like the mixed.bin case in
# docs/V1_2.md, can also have) but consistently close to random in every
# slice of it. Measured margin between the two cases that matter:
#   pure random 1 MiB chunk:            entropy=7.9998  spread=0.0004
#   500 KB random + repeated header/footer: entropy=7.9697  spread=0.8744
# 0.3 sits comfortably below the second case and far above the first, so
# there's real margin either way this could drift with different data.
_UNIFORM_ENTROPY = 7.9
_UNIFORM_SPREAD = 0.3


@dataclass(frozen=True)
class Candidate:
    method: int
    filter_id: int
    payload: bytes
    name: str

    @property
    def size(self):
        return len(self.payload)


def select_candidate(data: bytes, level: int = 3, memory_limit: int = 4 * 1024 ** 3):
    """Build every candidate encoding worth trying at this level and return
    the smallest. Every candidate here is a Candidate with a real method id,
    so callers (encoder.py) don't need a separate mapping step."""
    candidates = [Candidate(METHOD_STORE, 0, store_encode(data), "store")]

    if len(data) <= 16 * 1024 * 1024:
        candidates.append(Candidate(METHOD_RLE, 0, rle_encode(data), "rle"))

    a = analyze(data)
    # Computed once, up front, and reused for every gate below (LZ search
    # depth, BWT block size, whether to try PPM/order-0 at all) instead of
    # each candidate recomputing its own entropy estimate. Both calls are
    # cheap (Counter-based, no suffix sorting or matching) relative to
    # anything they gate.
    spread = segment_entropy_spread(data)
    uniformly_random = a["entropy"] > _UNIFORM_ENTROPY and spread < _UNIFORM_SPREAD

    # For a chunk that's close to random *everywhere* (not just on
    # average -- see _UNIFORM_SPREAD above), even level 5's full search
    # depth is spent finding that there's nothing to find. This was
    # measured as the single largest remaining cost for such a chunk: 2.9s
    # of a 1 MiB pure-random chunk's ~4s total went into level 5's LZ
    # search alone, for a result STORE was always going to beat.
    #
    # This does not mean *skipping* LZ, deliberately: a shallow, fast
    # search (level 1's settings) still reliably finds an exact repeat if
    # one exists -- depth mainly matters for choosing the *best* among
    # several imperfect candidates, not for detecting whether a repeat
    # exists at all, since an exact duplicate produces an exact hash hit
    # immediately. So a uniformly-random chunk still gets checked for
    # e.g. an accidentally-duplicated block, just cheaply instead of at
    # full cost.
    lz_level = 1 if uniformly_random else level

    # Match once, serialize two ways: raw tokens (cheap to decode, no
    # further entropy stage) and rANS-coded per-stream (gpx.codecs.lz_entropy
    # -- see its module docstring for why splitting control/literal/length/
    # distance into separate streams before entropy coding usually beats
    # coding the raw interleaved tokens). Both are built from the same
    # parse_tokens() call so the matcher only runs once per chunk.
    tokens = lz_codec.parse_tokens(data, lz_level)
    candidates.append(Candidate(METHOD_LZ, 0, lz_codec.serialize_raw(tokens), "lz"))
    candidates.append(Candidate(METHOD_LZ_ENTROPY, 0, lz_entropy_codec.serialize(tokens), "lz+entropy"))

    # High-entropy input (random data, or data that's already compressed/
    # encrypted) essentially never benefits from BWT clustering or context
    # modeling -- both add real CPU cost for output that STORE would beat
    # anyway. This is a speed optimization: it does NOT change which
    # candidate wins (the size competition below would reject a losing
    # candidate regardless), only whether the CPU is spent computing it.
    #
    # At levels 1-4 this is the plain whole-chunk entropy check (levels
    # that are explicitly balancing CPU against ratio). At level 5 it's
    # the *uniform* check above instead of being bypassed outright: a
    # chunk that's high-entropy only on average (a hidden structured
    # pocket in an otherwise-random payload) still gets the full
    # candidate set, since that's exactly the case level 5 exists to
    # catch and a plain average would miss; a chunk that's close to
    # random *everywhere* does not, since there is nothing there to find
    # regardless of how hard the search tries.
    worth_entropy_coding = (not uniformly_random) if level >= 5 else a["entropy"] < 7.9

    if level >= 3 and worth_entropy_coding:
        # Bigger BWT blocks give more context and usually compress better
        # *for locally homogeneous data*. For a chunk that mixes very
        # different regions, one large block forces a single suffix sort
        # to serve both, and the noisy region's rotations dilute the
        # ordering that would otherwise cluster the structured region
        # tightly. Measured on exactly that shape of input: a 1 MiB block
        # gave a *worse* result (642,287 bytes) than a 256 KiB block
        # (523,495 bytes) on the same data -- "more context" isn't
        # monotonic once the block stops being homogeneous.
        #
        # Rather than pay for BWT's suffix sort at *both* sizes and keep
        # the smaller (correct, but BWT is the single most expensive
        # candidate here -- profiled at ~3s and ~2s for the two sizes on
        # one 1 MiB chunk), decide which size to try from `spread`
        # (already computed above): high spread -> heterogeneous -> use
        # the smaller, level-3 block size even at higher levels.
        block_size = pipelines.bwt_block_size_for_level(level)
        if level >= 4 and spread > 1.0:
            block_size = pipelines.bwt_block_size_for_level(3)
        if block_size and memory_limit >= min(len(data), block_size) * 12:
            payload = pipelines.encode(data, block_size)
            candidates.append(Candidate(METHOD_BWT_MTF_RANS, 0, payload, "bwt+mtf+rans"))

    # Delta filters only make sense for raw structured binary records
    # (audio samples, pixel rows, fixed-width fields) where adjacent values
    # are numerically close. v1.1's gate (`alignment==4 and entropy<7.5`)
    # doesn't check for that -- it also fires on ordinary repetitive text
    # that merely happens to have a length divisible by 4, which is common.
    # Combined with running the *full* level-5 LZ search once per candidate
    # distance, that meant a ~930 KB log file spent over a minute
    # re-running expensive LZ on four delta transforms data delta
    # filtering was never going to help.
    #
    # Two fixes: only attempt this path for data actually classified as
    # generic "binary" (not text/archive/high_entropy/executable), and
    # screen the four distances with a cheap entropy estimate first,
    # running the expensive LZ search only on the single most promising
    # distance instead of all four.
    if level >= 4 and a["alignment"] == 4 and a["entropy"] < 7.5 and a["kind"] == "binary":
        best_d, best_entropy = None, None
        for d in (1, 2, 4, 8):
            if len(data) <= d:
                continue
            transformed = delta_encode(data, d)
            e = analyze(transformed)["entropy"]
            if best_entropy is None or e < best_entropy:
                best_d, best_entropy = d, e
        if best_d is not None:
            transformed = delta_encode(data, best_d)
            d_tokens = lz_codec.parse_tokens(transformed, lz_level)
            candidates.append(Candidate(METHOD_LZ, best_d, lz_codec.serialize_raw(d_tokens), f"delta{best_d}+lz"))
            candidates.append(Candidate(METHOD_LZ_ENTROPY, best_d, lz_entropy_codec.serialize(d_tokens), f"delta{best_d}+lz+entropy"))

    ppm_max = _PPM_MAX_SIZE.get(level, 0)
    # ppm/rans0 model the *whole* chunk with no sub-blocking option (unlike
    # BWT above), so they're even more exposed to the same dilution problem
    # a heterogeneous-but-high-average-entropy chunk causes. worth_entropy_coding
    # already accounts for this at level 5 via the uniform check.
    if (level >= 5 and worth_entropy_coding
            and _PPM_MIN_SIZE <= len(data) <= ppm_max and memory_limit >= len(data) * 8):
        candidates.append(Candidate(METHOD_PPM_RANS, 0, ppm_encode(data, 1), "ppm1+rans"))
        candidates.append(Candidate(METHOD_PPM_ARITH, 0, arithmetic_encode(data), "rans0"))

    return min(candidates, key=lambda c: (c.size, c.method))

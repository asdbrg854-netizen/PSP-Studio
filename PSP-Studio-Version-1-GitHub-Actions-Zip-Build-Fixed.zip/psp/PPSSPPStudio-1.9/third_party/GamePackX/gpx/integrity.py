"""Integrity helpers."""
from hashlib import sha256
from .crc32c import crc32c

def sha256_bytes(data: bytes) -> bytes:
    return sha256(data).digest()

def sha256_file(path, block_size: int = 1024 * 1024) -> bytes:
    h = sha256()
    with open(path, "rb") as f:
        while chunk := f.read(block_size):
            h.update(chunk)
    return h.digest()

__all__ = ["sha256_bytes", "sha256_file", "crc32c"]

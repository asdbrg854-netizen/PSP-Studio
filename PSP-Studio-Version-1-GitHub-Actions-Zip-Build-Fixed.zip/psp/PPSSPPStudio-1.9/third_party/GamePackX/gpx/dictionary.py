"""Dictionary architecture. v1 stores optional reusable prefixes."""
from collections import Counter

def build_dictionary(chunks, max_size=65536):
    c=Counter()
    for chunk in chunks:
        for i in range(0, max(0,len(chunk)-8), 8):
            c[chunk[i:i+8]] += 1
    out=bytearray()
    for token,count in c.most_common():
        if count < 2: break
        if len(out)+8 > max_size: break
        out += token
    return bytes(out)

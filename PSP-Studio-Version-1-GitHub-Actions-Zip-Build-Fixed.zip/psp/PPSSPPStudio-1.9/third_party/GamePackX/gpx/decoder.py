"""GPX decoder.

Mirrors the method IDs produced by gpx.selector: BWT+MTF+rANS and order-1
PPM now dispatch to gpx.pipelines / gpx.codecs.ppm instead of the old
single-block-only inline glue, so they can actually decode the larger,
sub-blocked payloads the encoder now produces.
"""
from . import pipelines
from .container import read_gpx
from .integrity import sha256_bytes, crc32c
from .codecs import (
    METHOD_STORE, METHOD_RLE, METHOD_LZ, METHOD_BWT_MTF_RANS,
    METHOD_PPM_RANS, METHOD_PPM_ARITH, METHOD_LZ_ENTROPY,
)
from .codecs.store import decode as store_decode
from .codecs.rle import decode as rle_decode
from .codecs.lz import decode as lz_decode
from .codecs.lz_entropy import decode as lz_entropy_decode
from .codecs.ppm import decode as ppm_decode
from .codecs.arithmetic import decode as arithmetic_decode
from .filters.delta import delta_decode


def _decode(method, payload, size, filter_id):
    if method == METHOD_STORE:
        out = store_decode(payload)
    elif method == METHOD_RLE:
        out = rle_decode(payload)
    elif method == METHOD_LZ:
        out = lz_decode(payload)
    elif method == METHOD_LZ_ENTROPY:
        out = lz_entropy_decode(payload, size)
    elif method == METHOD_BWT_MTF_RANS:
        out = pipelines.decode(payload)
    elif method == METHOD_PPM_RANS:
        out = ppm_decode(payload, size, 1)
    elif method == METHOD_PPM_ARITH:
        out = arithmetic_decode(payload, size)
    else:
        raise ValueError(f"unknown method {method}")
    if filter_id:
        if filter_id in (1, 2, 3, 4):
            out = delta_decode(out, filter_id)
        else:
            raise ValueError("unsupported filter")
    if len(out) != size:
        raise ValueError("decoded size mismatch")
    return out


def decompress_file(src, dst):
    raw, h, entries = read_gpx(src)
    chunks = [None] * len(entries)
    for i, e in enumerate(entries):
        if e.reference:
            # 1-based: reference == k+1 means "same content as chunk k".
            # (0 is the sentinel for "not a dedup reference" -- see the
            # comment in encoder.py's dedup loop for why this can't be
            # 0-based without colliding with a real reference to chunk 0.)
            target = e.reference - 1
            if target >= i:
                raise ValueError("invalid forward/cyclic reference")
            if chunks[target] is None:
                raise ValueError("unresolved reference")
            chunks[i] = chunks[target]
            continue
        if e.payload_offset + e.compressed_size > len(raw):
            raise ValueError("payload out of bounds")
        p = raw[e.payload_offset:e.payload_offset + e.compressed_size]
        out = _decode(e.method, p, e.original_size, e.filter_id)
        if sha256_bytes(out) != e.digest or crc32c(out) != e.crc:
            raise ValueError(f"chunk {i} integrity failure")
        chunks[i] = out
    result = b"".join(chunks)
    if len(result) != h[3]:
        raise ValueError("original size mismatch")
    with open(dst, "wb") as f:
        f.write(result)
    return sha256_bytes(result).hex()


def test_file(src):
    raw, h, entries = read_gpx(src)
    for i, e in enumerate(entries):
        if e.payload_offset + e.compressed_size > len(raw):
            raise ValueError(f"chunk {i}: bounds")
    return {"status": "OK", "chunks": len(entries), "original_size": h[3]}


def verify_file(gpx_path, original_path):
    import tempfile, os
    with tempfile.NamedTemporaryFile(delete=False) as t:
        tmp = t.name
    try:
        decompress_file(gpx_path, tmp)
        with open(original_path, "rb") as a, open(tmp, "rb") as b:
            ha = sha256_bytes(a.read())
            hb = sha256_bytes(b.read())
        if ha != hb:
            raise ValueError("SHA256 mismatch")
        if open(original_path, "rb").read() != open(tmp, "rb").read():
            raise ValueError("byte mismatch")
        return "VERIFIED\nSHA256 MATCH\nBYTE-FOR-BYTE MATCH"
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass

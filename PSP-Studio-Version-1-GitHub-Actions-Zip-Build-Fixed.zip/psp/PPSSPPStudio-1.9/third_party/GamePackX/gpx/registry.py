from dataclasses import dataclass
from typing import Callable

@dataclass(frozen=True)
class Codec:
    method_id: int
    name: str
    encode: Callable
    decode: Callable

class CodecRegistry:
    def __init__(self):
        self._items = {}
    def register(self, codec: Codec):
        if not 0 <= codec.method_id <= 255:
            raise ValueError("method_id must fit uint8")
        self._items[codec.method_id] = codec
    def get(self, method_id: int) -> Codec:
        if method_id not in self._items:
            raise KeyError(f"unknown method {method_id}")
        return self._items[method_id]
    def all(self):
        return tuple(self._items.values())

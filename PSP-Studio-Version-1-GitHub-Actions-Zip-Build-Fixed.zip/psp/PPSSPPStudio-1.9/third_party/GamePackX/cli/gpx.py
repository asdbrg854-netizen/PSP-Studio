import argparse, json
from gpx.encoder import compress_file
from gpx.decoder import decompress_file,test_file,verify_file

def main():
    p=argparse.ArgumentParser(prog="gpx")
    sub=p.add_subparsers(dest="cmd",required=True)
    c=sub.add_parser("compress")
    c.add_argument("input"); c.add_argument("output")
    c.add_argument("-l","--level",type=int,default=3,choices=range(1,6))
    c.add_argument("-j","--jobs",type=int,default=1)
    c.add_argument("--memory-limit",default="4G")
    c.add_argument("--chunk-size",type=int,default=1024*1024)
    c.add_argument("--solid",action="store_true")
    c.add_argument("--non-solid",action="store_true")
    d=sub.add_parser("decompress"); d.add_argument("input"); d.add_argument("output")
    t=sub.add_parser("test"); t.add_argument("input")
    v=sub.add_parser("verify"); v.add_argument("input"); v.add_argument("original")
    b=sub.add_parser("benchmark"); b.add_argument("input")

    a=p.parse_args()
    def mem(s):
        units={"K":1024,"M":1024**2,"G":1024**3,"T":1024**4}
        s=str(s).upper()
        return int(float(s[:-1])*units[s[-1]]) if s[-1:] in units else int(s)
    if a.cmd=="compress":
        print(json.dumps(compress_file(a.input,a.output,a.level,a.jobs,a.chunk_size,mem(a.memory_limit)),indent=2))
    elif a.cmd=="decompress": print(decompress_file(a.input,a.output))
    elif a.cmd=="test": print(json.dumps(test_file(a.input),indent=2))
    elif a.cmd=="verify": print(verify_file(a.input,a.original))
    elif a.cmd=="benchmark":
        import time, tempfile, os
        with tempfile.NamedTemporaryFile(suffix=".gpj",delete=False) as f: out=f.name
        try:
            t=time.perf_counter(); r=compress_file(a.input,out,3,1); ct=time.perf_counter()-t
            d=out+".raw"; t=time.perf_counter(); decompress_file(out,d); dt=time.perf_counter()-t
            print(json.dumps({"result":r,"compress_seconds":ct,"decompress_seconds":dt},indent=2))
            os.unlink(d)
        finally: os.unlink(out)

if __name__=="__main__": main()

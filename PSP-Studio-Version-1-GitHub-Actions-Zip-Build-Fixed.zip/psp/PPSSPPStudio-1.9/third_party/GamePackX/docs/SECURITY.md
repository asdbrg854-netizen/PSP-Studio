# Security model

The decoder validates:

- magic/version
- monotonic section offsets
- chunk index bounds
- payload bounds
- reference ordering
- method/filter IDs
- decoded sizes
- CRC32C and SHA-256

Forward references are rejected, preventing cyclic dependency chains.

Future implementations should additionally enforce configurable total allocation and decompression limits before allocating attacker-controlled sizes.

# Benchmark methodology

Do not claim superiority without measuring.

For each corpus record:
- original bytes
- GPX bytes
- ratio
- compression seconds
- decompression seconds
- peak RSS
- CPU utilization

Recommended comparison tools:
7-Zip/LZMA2, Zstandard, Brotli, XZ.

Corpora:
ISO, BIN, ROM, executable, textures, audio and mixed assets.

Run several repetitions and report median and range. Use identical source files and document versions/settings.

## v1.2 development-pass results (internal before/after only)

These are **not** a comparison against 7-Zip/Zstandard/Brotli/XZ -- follow
the methodology above for that. This is only v1.1 vs. v1.2 of this
codebase, on synthetic files, on a single-core sandbox (so `-j` can't show
its real multi-core benefit here). Full methodology and analysis in
`docs/V1_2.md`; raw numbers below for reference.

Level 5 (max ratio), single core, 5 synthetic files (structured text,
1 MB random binary, header+random+repeated-footer binary, a repetitive
log file, and a 1 MB all-zero file):

| file | orig bytes | v1.1 bytes (ratio) | v1.1 time | v1.2 bytes (ratio) | v1.2 time |
|---|---|---|---|---|---|
| text.bin | 203,199 | 662 (0.33%) | 0.20s | 560 (0.28%) | 0.78s |
| random.bin | 1,000,000 | 1,000,174 (100.02%) | 2.73s | 1,000,174 (100.02%) | 8.38s |
| mixed.bin | 522,025 | 522,199 (100.03%) | 0.83s | 502,955 (96.35%) | 4.41s |
| logs.bin | 930,000 | 1,497 (0.16%) | 12.69s | 372 (0.04%) | 3.87s |
| zeros.bin | 1,000,000 | 179 (0.02%) | 13.86s | 179 (0.02%) | 3.10s |
| **total** | 3,655,224 | 1,524,711 (41.71%) | 30.31s | 1,504,240 (41.15%) | 20.54s |

`random.bin` is included deliberately: it's the case where v1.2 does
*more* work (level 5 always tries the advanced candidates now, by design --
see the entropy-gating discussion in `docs/V1_2.md`) for the same,
correct STORE result, and is the main reason the total time saving isn't
larger. On files with real exploitable structure (`mixed.bin`, `logs.bin`),
both ratio and time improve, in `logs.bin`'s case by roughly 4x on each.


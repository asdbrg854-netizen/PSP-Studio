# Development

Run:

```bash
python -m unittest discover -s tests -v
```

Every new codec must have:
1. independent round-trip tests
2. malformed-input tests
3. deterministic encoding
4. size accounting
5. container integration
6. benchmark coverage
7. documentation

A codec must never be selected merely because it is more sophisticated.

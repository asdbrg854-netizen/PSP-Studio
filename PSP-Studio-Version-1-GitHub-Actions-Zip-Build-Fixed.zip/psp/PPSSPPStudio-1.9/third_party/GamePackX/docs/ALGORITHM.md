# Algorithms

The selector (`gpx/selector.py`, the single implementation used by the
encoder) evaluates STORE, RLE, LZ, BWT+MTF+rANS and bounded context-model
paths according to level and memory, and keeps whichever candidate is
smallest.

BWT is sub-blocked (`gpx/pipelines.py`) at a level-dependent size --
256 KiB / 1 MiB / 4 MiB for levels 3/4/5 -- rather than gated out above a
fixed chunk size, so it stays reachable at normal chunk sizes instead of
being silently skipped. Its suffix ordering is an O(n log^2 n)
prefix-doubling construction (`gpx/codecs/bwt.py`): each round compares
`(rank[i], rank[(i+k) mod n])` to double the resolved comparison length,
with ties (only possible for periodic input) broken by ascending original
index via a stable sort -- the standard, provably-correct convention for
cyclic BWT. This runs as vectorized NumPy when available, with a
pure-Python fallback of the same complexity when it isn't.

MTF converts the BWT last column into move-to-front ranks. rANS performs
deterministic frequency normalization. `gpx/codecs/ppm.py` builds on the
same rANS state machine with a real order-1 model: a separate static
frequency table per preceding byte, computed once from the whole block and
stored in the payload header, so encoder and decoder can look up the same
table for a given context without needing adaptive updates to stay in sync
(which would be awkward here since rANS encodes its input in reverse).
`gpx/codecs/arithmetic.py` is the order-0 baseline it's compared against.

Delta transforms are byte-wise reversible and are only considered where
analysis suggests structure -- specifically, generic binary data with
4-byte alignment and low entropy, not text or already-compressed content,
and only the single most promising byte-distance (of 1/2/4/8) is actually
run through the expensive LZ search rather than all four.

LZ (`gpx/codecs/lz.py`) is a hash-chain matcher whose search depth and use
of lazy (one-step-lookahead) matching are both level-dependent, so `level`
now actually changes the LZ candidate itself and not just which other
candidates are attempted alongside it.

The architecture separates:
- container
- chunking
- analysis
- transforms
- entropy coding
- selection
- scheduling

This makes a future Rust/C++ hot path possible without changing the GPX wire contract.

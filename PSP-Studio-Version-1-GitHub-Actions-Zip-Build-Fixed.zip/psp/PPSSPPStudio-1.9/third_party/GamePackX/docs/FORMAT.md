# GPX v1 format (.gpj files)

Magic bytes are `GPJ\x01` (header) and `GPJF` (footer) -- renamed from an
earlier internal `GPX`/`GPXF` convention to match the `.gpj` file
extension. This is a naming change only, not a wire-format redesign: field
layout, sizes, and semantics below are unchanged from the version described
elsewhere in these docs, and the "GPX" name lives on in the Python package
(`gpx/`) and CLI module (`cli/gpx.py`) purely as internal, historical
naming -- it has no bearing on what extension a compressed file uses.

Header (64 bytes):

| Field | Size |
|---|---:|
| Magic | 4 |
| Version | 2 |
| Flags | 2 |
| Original Size | 8 |
| Chunk Count | 8 |
| Metadata Offset | 8 |
| Index Offset | 8 |
| Data Offset | 8 |
| Footer Offset | 8 |

Each chunk index entry is 64 bytes:

- Method ID: 1
- Filter ID: 1
- Flags: 2
- Original Size: 8
- Compressed Size: 8
- SHA-256: 32
- CRC32C: 4
- Payload Offset: 8
- Reference ID: 4

**Reference ID is 1-based.** `0` means "this chunk is not a dedup
reference; decode it normally." A nonzero value `k` means "this chunk is
byte-identical to chunk index `k - 1`." The 1-based offset exists
specifically so a reference to the file's actual first chunk (real index 0)
can't collide with the "no reference" sentinel -- an earlier 0-based
version of this field had exactly that collision, and it silently
corrupted any file whose first chunk repeated later. See `docs/V1_2.md`.

The footer contains `GPJF` plus the SHA-256 of the bytes preceding the footer.

Method ID ranges are reserved as requested:

- 0–31 core (0=store, 1=rle, 2=lz, 3=bwt+mtf+rans, 4=ppm+rans, 5=order-0 rans, 6=lz+rans -- see `gpx/codecs/__init__.py` for the authoritative list)
- 32–63 experimental
- 64–127 future official
- 128–255 external/reserved

Unknown methods are rejected rather than guessed.

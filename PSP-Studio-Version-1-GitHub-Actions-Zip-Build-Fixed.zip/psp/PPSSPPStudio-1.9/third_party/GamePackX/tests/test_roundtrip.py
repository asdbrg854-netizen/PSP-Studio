import os, tempfile, unittest
from gpx.encoder import compress_file
from gpx.decoder import decompress_file, verify_file

class TestRoundTrip(unittest.TestCase):
    def test_patterns(self):
        data=(b"ABCD"*10000)+bytes(range(256))*100+b"\0"*5000
        with tempfile.TemporaryDirectory() as d:
            src=os.path.join(d,"a.bin"); gpx=os.path.join(d,"a.gpj"); out=os.path.join(d,"out.bin")
            open(src,"wb").write(data)
            compress_file(src,gpx,5,1,64*1024)
            decompress_file(gpx,out)
            self.assertEqual(open(src,"rb").read(),open(out,"rb").read())
            self.assertIn("VERIFIED",verify_file(gpx,src))

if __name__=="__main__": unittest.main()

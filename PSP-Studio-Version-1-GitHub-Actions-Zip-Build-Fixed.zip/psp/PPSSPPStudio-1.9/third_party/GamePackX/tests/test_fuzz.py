import os,random,unittest
from gpx.codecs.rle import encode as re,decode as rd
from gpx.codecs.lz import encode as le,decode as ld
from gpx.codecs.bwt import encode as be,decode as bd
from gpx.codecs.rans import encode as ae,decode_n as ad

class TestFuzz(unittest.TestCase):
    def test_random(self):
        r=random.Random(12345)
        for _ in range(100):
            n=r.randrange(0,4096)
            x=os.urandom(n)
            self.assertEqual(rd(re(x)),x)
            self.assertEqual(ld(le(x)),x)
            self.assertEqual(bd(be(x)),x)
            self.assertEqual(ad(ae(x),len(x)),x)

if __name__=="__main__": unittest.main()

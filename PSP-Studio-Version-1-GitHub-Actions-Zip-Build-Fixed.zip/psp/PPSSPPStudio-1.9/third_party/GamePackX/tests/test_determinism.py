import os,tempfile,unittest
from gpx.encoder import compress_file
class TestDeterminism(unittest.TestCase):
    def test_same(self):
        with tempfile.TemporaryDirectory() as d:
            src=os.path.join(d,"x"); a=os.path.join(d,"a.gpj"); b=os.path.join(d,"b.gpj")
            open(src,"wb").write((b"hello world"*10000))
            compress_file(src,a,3,1,65536)
            compress_file(src,b,3,4,65536)
            self.assertEqual(open(a,"rb").read(),open(b,"rb").read())
if __name__=="__main__": unittest.main()

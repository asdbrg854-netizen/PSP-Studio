import unittest
from gpx.codecs.rle import encode as re, decode as rd
from gpx.codecs.lz import encode as le, decode as ld
from gpx.codecs.bwt import encode as be, decode as bd
from gpx.codecs.mtf import encode as me, decode as md
from gpx.codecs.rans import encode as ae, decode_n as ad
from gpx.filters.delta import delta_encode,delta_decode

class TestCodecs(unittest.TestCase):
    def test_all(self):
        data=(b"mississippi "*1000)+bytes(range(256))
        self.assertEqual(rd(re(data)),data)
        self.assertEqual(ld(le(data)),data)
        self.assertEqual(bd(be(data)),data)
        self.assertEqual(md(me(data)),data)
        self.assertEqual(ad(ae(data),len(data)),data)
        for d in (1,2,4,8):
            self.assertEqual(delta_decode(delta_encode(data,d),d),data)

if __name__=="__main__": unittest.main()

"""Correctness tests for the optional C acceleration module (gpx/_native.py,
gpx/native/gpx_native.c).

This is the highest-risk code added in this project: C, manual buffer size
accounting, and -- for rANS specifically -- a hard requirement that a file
compressed with this available still decodes correctly on a machine
without a C compiler (or vice versa), since the compressed file doesn't
know or care which implementation made it. Every test here either:
  (a) round-trips purely within one implementation (native or pure-Python),
  (b) cross-checks native-encode against pure-Python-decode and the
      reverse, which is the property that actually matters for real
      portability, or
  (c) fuzzes both implementations against each other over many random
      inputs rather than a handful of hand-picked cases.

All tests are skipped (not failed) if a C compiler isn't available in this
environment, since gpx._native.AVAILABLE being False is an expected,
handled condition, not a bug.
"""
import random
import struct
import unittest

from gpx import _native


@unittest.skipUnless(_native.AVAILABLE, "no C compiler available in this environment")
class TestNativeLZ(unittest.TestCase):
    def test_native_output_decodes_with_python_lz_decode(self):
        from gpx.codecs.lz import decode as py_lz_decode, serialize_raw, _tokens_from_raw
        random.seed(100)
        samples = [b"", b"a", b"ab", bytes(range(256)) * 8]
        for _ in range(40):
            n = random.randrange(0, 4000)
            samples.append(bytes(random.randrange(256) for _ in range(n)))
        for data in samples:
            for chain_depth, lazy, nice in [(16, False, 64), (128, True, 1024)]:
                with self.subTest(n=len(data), chain_depth=chain_depth, lazy=lazy):
                    raw = _native.lz_parse(data, chain_depth, lazy, nice)
                    self.assertEqual(py_lz_decode(raw), data)
                    # And the tuple form must serialize back to the exact
                    # same raw bytes (round-trips through the shared format).
                    tokens = _tokens_from_raw(raw)
                    self.assertEqual(serialize_raw(tokens), raw)

    def test_matches_python_matcher_output_size_class(self):
        """Not requiring byte-identical output (the C and Python matchers
        are free to differ in tie-breaking), but the native path should
        never be *dramatically* worse -- a large regression here would
        indicate a logic bug, not just a different valid parse."""
        import gpx.codecs.lz as lzmod
        random.seed(101)
        text = b"the quick brown fox jumps over the lazy dog. " * 500
        for level in (1, 3, 5):
            tokens_native = lzmod.parse_tokens(text, level)  # native, since available
            size_native = len(lzmod.serialize_raw(tokens_native))
            # Force the pure-Python path for comparison.
            chain_depth, lazy, nice = lzmod._LEVEL_PARAMS[level]
            arr = None
            table = {}
            i, n = 0, len(text)
            py_tokens = []
            while i < n:
                best_len, best_dist = lzmod._find_match(text, i, table, chain_depth, nice, arr)
                if lazy and best_len >= lzmod.MIN_MATCH and i + 1 < n:
                    lzmod._insert(text, i, table)
                    nl, _ = lzmod._find_match(text, i + 1, table, chain_depth, nice, arr)
                    if nl > best_len:
                        py_tokens.append(("L", text[i])); i += 1; continue
                if best_len >= lzmod.MIN_MATCH:
                    py_tokens.append(("M", best_dist, best_len))
                    end = i + best_len
                    while i < end:
                        lzmod._insert(text, i, table); i += 1
                else:
                    py_tokens.append(("L", text[i]))
                    lzmod._insert(text, i, table); i += 1
            size_py = len(lzmod.serialize_raw(py_tokens))
            with self.subTest(level=level):
                self.assertLess(size_native, size_py * 1.05)


@unittest.skipUnless(_native.AVAILABLE, "no C compiler available in this environment")
class TestNativeRANS(unittest.TestCase):
    def test_cross_compatible_both_directions(self):
        """The property that actually matters: a file compressed on a
        machine with a C compiler must decode correctly on one without,
        and vice versa. Encode/decode implementation choice must not leak
        into the wire format."""
        from gpx.codecs.rans import _encode_py, _decode_n_py

        random.seed(102)
        samples = [b"", b"x", b"xy", bytes(range(256)) * 4]
        for _ in range(40):
            n = random.randrange(0, 4000)
            samples.append(bytes(random.randrange(256) for _ in range(n)))

        for data in samples:
            with self.subTest(n=len(data)):
                native_enc = _native.rans_encode(data) if data else struct.pack("<H", 0)
                self.assertEqual(_decode_n_py(native_enc, len(data)), data)

                py_enc = _encode_py(data)
                self.assertEqual(_native.rans_decode_n(py_enc, len(data)), data)

    def test_malformed_payload_raises_not_crashes(self):
        """A decoder bug in C fails loud (crash/hang) instead of raising a
        catchable exception the way the pure-Python decoder does. This
        checks a handful of deliberately-truncated/corrupted payloads are
        rejected cleanly rather than segfaulting or reading out of bounds
        (run under normal conditions here; a memory-safety bug would most
        likely surface as a crash of the test process itself, not a clean
        failure, which is exactly why this is worth testing explicitly)."""
        good = _native.rans_encode(b"hello world, this is a test" * 20)
        for truncate_to in (0, 1, 2, 3, 5, 10, len(good) // 2):
            with self.subTest(truncate_to=truncate_to):
                with self.assertRaises(ValueError):
                    _native.rans_decode_n(good[:truncate_to], 400)


@unittest.skipUnless(_native.AVAILABLE, "no C compiler available in this environment")
class TestNativeMTF(unittest.TestCase):
    def test_bit_exact_with_python(self):
        from gpx.codecs.mtf import _encode_py, _decode_py
        random.seed(103)
        for _ in range(30):
            n = random.randrange(0, 2000)
            data = bytes(random.randrange(256) for _ in range(n))
            with self.subTest(n=n):
                self.assertEqual(_native.mtf_encode(data), _encode_py(data))
                enc = _encode_py(data)
                self.assertEqual(_decode_py(enc), data)
                self.assertEqual(_native.mtf_decode(enc), data)


@unittest.skipUnless(_native.AVAILABLE, "no C compiler available in this environment")
class TestNativeCRC32C(unittest.TestCase):
    def test_bit_exact_with_python(self):
        from gpx.crc32c import _crc32c_py
        random.seed(104)
        for _ in range(30):
            n = random.randrange(0, 3000)
            data = bytes(random.randrange(256) for _ in range(n))
            with self.subTest(n=n):
                self.assertEqual(_native.crc32c(data), _crc32c_py(data))


@unittest.skipUnless(_native.AVAILABLE, "no C compiler available in this environment")
class TestNativeFullPipeline(unittest.TestCase):
    """End-to-end: the actual compress_file/decompress_file path, with
    native acceleration active, on inputs varied enough to exercise every
    method the selector can choose."""

    def test_roundtrip_various_content(self):
        import os
        import tempfile
        from gpx.encoder import compress_file
        from gpx.decoder import decompress_file

        random.seed(105)
        samples = {
            "text": b"the quick brown fox jumps over the lazy dog. " * 3000,
            "random": bytes(random.randrange(256) for _ in range(200000)),
            "zeros": b"\x00" * 300000,
            "mixed": (b"HEADER" + bytes(random.randrange(256) for _ in range(150000)) + b"FOOTER" * 3000),
        }
        with tempfile.TemporaryDirectory() as d:
            for name, data in samples.items():
                src = os.path.join(d, f"{name}.bin")
                gpx_path = os.path.join(d, f"{name}.gpj")
                out = os.path.join(d, f"{name}.out")
                with open(src, "wb") as f:
                    f.write(data)
                for level in (1, 3, 5):
                    with self.subTest(name=name, level=level):
                        compress_file(src, gpx_path, level=level, jobs=1, chunk_size=262144)
                        decompress_file(gpx_path, out)
                        with open(out, "rb") as f:
                            self.assertEqual(f.read(), data)


class TestNativeUnavailableIsHandled(unittest.TestCase):
    """AVAILABLE being False must be a normal, silent fallback -- not an
    exception -- since environments without a C compiler are expected and
    supported, not an error condition."""

    def test_available_is_a_bool(self):
        self.assertIsInstance(_native.AVAILABLE, bool)


if __name__ == "__main__":
    unittest.main()

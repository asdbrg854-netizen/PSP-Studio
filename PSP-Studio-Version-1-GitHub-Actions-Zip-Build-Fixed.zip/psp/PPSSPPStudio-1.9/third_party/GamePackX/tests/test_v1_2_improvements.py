"""Regression tests for the v1.2 development pass.

Each test here documents a specific bug found, or capability added, while
developing v1.2 from v1.1 -- not just "does it still round-trip", which the
existing suite already covers, but the specific things that were broken or
missing before this pass.
"""
import os
import random
import struct
import tempfile
import unittest

from gpx.codecs import bwt, ppm
from gpx import pipelines
from gpx.encoder import compress_file
from gpx.decoder import decompress_file
from gpx.container import write_gpx, read_gpx
from gpx.integrity import sha256_bytes, crc32c


class TestBWTScales(unittest.TestCase):
    """v1.1's BWT used data[i:]+data[:i] rotation keys: O(n^2) time and
    memory. It was gated to <=32768 bytes in the encoder for exactly that
    reason. This checks the replacement suffix-array implementation stays
    correct well past that old ceiling, at a size that would not have
    finished in any reasonable time under the old approach."""

    def test_quarter_megabyte_roundtrip(self):
        random.seed(2024)
        data = bytes(random.randrange(256) for _ in range(120_000))
        data += (b"structured repeating segment " * 3000)
        enc = bwt.encode(data)
        self.assertEqual(bwt.decode(enc), data)

    def test_periodic_data_ties_broken_correctly(self):
        # Fully periodic input forces every rotation-sort tie-break path.
        for period, reps in ((1, 5000), (2, 5000), (3, 4000), (7, 2000)):
            data = (bytes(range(period)) * reps)[: period * reps]
            with self.subTest(period=period):
                self.assertEqual(bwt.decode(bwt.encode(data)), data)


class TestOrder1PPM(unittest.TestCase):
    """v1.1's ppm.encode() ignored its `order` argument entirely and just
    called the order-0 rANS coder -- correctly documented as a stub, but a
    stub nonetheless. This checks the real order-1 model round-trips and
    that it actually captures context (meaningfully beats order-0 on data
    with strong byte-to-byte correlation)."""

    def test_roundtrip_various(self):
        random.seed(11)
        samples = [
            b"",
            b"x",
            b"xy",
            bytes(range(256)),
            b"the quick brown fox jumps over the lazy dog. " * 200,
            bytes(random.randrange(256) for _ in range(2000)),
        ]
        for data in samples:
            with self.subTest(n=len(data)):
                enc = ppm.encode(data)
                self.assertEqual(ppm.decode(enc, len(data)), data)

    def test_beats_order0_on_structured_text(self):
        from gpx.codecs.rans import encode as rans_encode
        text = b"the quick brown fox jumps over the lazy dog. " * 500
        order0_size = len(rans_encode(text))
        order1_size = len(ppm.encode(text))
        self.assertLess(order1_size, order0_size * 0.5)


class TestPipelineSubBlocking(unittest.TestCase):
    """BWT+MTF+rANS must now handle input far larger than one suffix-sort
    call would comfortably take by splitting into sub-blocks, and decode
    must reassemble them in order."""

    def test_multi_subblock_roundtrip(self):
        random.seed(3)
        data = bytes(random.randrange(256) for _ in range(30000))
        enc = pipelines.encode(data, block_size=4096)
        self.assertGreater(struct.unpack_from("<I", enc, 0)[0], 1)  # actually split
        self.assertEqual(pipelines.decode(enc), data)


class TestDedupIndexBugfix(unittest.TestCase):
    """v1.1's chunk-level dedup recorded `seen[key] = len(seen)` (the count
    of distinct hashes so far) instead of the chunk's real index. Those
    only match by coincidence before the first dedup happens; once a repeat
    occurs, a later *new* unique chunk could be assigned a reference target
    that doesn't correspond to its own position, and a further duplicate of
    that chunk would then resolve to the wrong data on decode. This drives
    the encoder with input handcrafted so the bug (if reintroduced) would
    corrupt output, and checks the round trip is exact."""

    def test_dedup_with_interleaved_uniques(self):
        chunk_size = 16
        # Chunk pattern: A, B, A, C, B  (each a distinct 16-byte block).
        A, B, C = b"A" * chunk_size, b"B" * chunk_size, b"C" * chunk_size
        data = A + B + A + C + B
        with tempfile.TemporaryDirectory() as d:
            src = os.path.join(d, "in.bin")
            gpx_path = os.path.join(d, "out.gpj")
            dst = os.path.join(d, "out.bin")
            with open(src, "wb") as f:
                f.write(data)
            compress_file(src, gpx_path, level=1, jobs=1, chunk_size=chunk_size)
            decompress_file(gpx_path, dst)
            with open(dst, "rb") as f:
                result = f.read()
            self.assertEqual(result, data)


class TestCRC32CUnchanged(unittest.TestCase):
    """crc32c() must still match a from-scratch reference table implementation
    bit-for-bit; this project's integrity checks depend on it."""

    def test_matches_reference(self):
        poly = 0x82F63B78

        # Bit-at-a-time CRC32C, written independently of gpx.crc32c's own
        # table construction, as an external oracle.
        def bitwise_crc32c(data, crc=0):
            c = crc ^ 0xFFFFFFFF
            for byte in data:
                c ^= byte
                for _ in range(8):
                    mask = -(c & 1)
                    c = (c >> 1) ^ (poly & mask)
            return (c ^ 0xFFFFFFFF) & 0xFFFFFFFF

        random.seed(4)
        for length in (0, 1, 2, 3, 4, 5, 100, 4096, 4097):
            data = bytes(random.randrange(256) for _ in range(length))
            self.assertEqual(crc32c(data), bitwise_crc32c(data))


class TestLZEntropy(unittest.TestCase):
    """LZ token streams were stored completely raw in every earlier
    version -- literal tokens always 2 bytes, match tokens always 5,
    regardless of skew. gpx.codecs.lz_entropy entropy-codes the split
    token streams instead; this checks it round-trips and that the shared
    parse_tokens() refactor didn't change what gpx.codecs.lz itself
    produces."""

    def test_roundtrip_various(self):
        from gpx.codecs import lz_entropy
        random.seed(17)
        samples = [
            b"",
            b"x",
            bytes(range(256)) * 20,
            b"the quick brown fox jumps over the lazy dog. " * 300,
            bytes(random.randrange(256) for _ in range(4000)),
        ]
        for data in samples:
            for level in (1, 3, 5):
                with self.subTest(n=len(data), level=level):
                    enc = lz_entropy.encode(data, level)
                    self.assertEqual(lz_entropy.decode(enc, len(data)), data)

    def test_shared_tokens_match_raw_lz(self):
        """serialize_raw(tokens) via the shared parse_tokens() must decode
        identically to lz.encode()'s own (still independent) call path."""
        from gpx.codecs import lz
        random.seed(18)
        data = bytes(random.randrange(256) for _ in range(5000))
        for level in (1, 3, 5):
            tokens = lz.parse_tokens(data, level)
            self.assertEqual(lz.serialize_raw(tokens), lz.encode(data, level))

    def test_selector_can_choose_lz_entropy(self):
        """Not a fixed assertion on which candidate wins (that's data-
        dependent and allowed to change as codecs improve) -- just that
        the method round-trips correctly through the full encoder/decoder
        when it *is* chosen."""
        from gpx.selector import select_candidate
        from gpx.codecs import METHOD_LZ_ENTROPY
        from gpx.decoder import _decode
        random.seed(19)
        data = bytes(random.randrange(256) for _ in range(6000))
        c = select_candidate(data, level=5)
        if c.method == METHOD_LZ_ENTROPY:
            self.assertEqual(_decode(c.method, c.payload, len(data), c.filter_id), data)


if __name__ == "__main__":
    unittest.main()

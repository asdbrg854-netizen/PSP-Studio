import argparse,time,tempfile,os
from gpx.encoder import compress_file
from gpx.decoder import decompress_file

p=argparse.ArgumentParser()
p.add_argument("input"); p.add_argument("-j",type=int,default=1)
a=p.parse_args()
with tempfile.TemporaryDirectory() as d:
    g=os.path.join(d,"x.gpj"); out=os.path.join(d,"out")
    t=time.perf_counter(); r=compress_file(a.input,g,5,a.j,1024*1024); ct=time.perf_counter()-t
    t=time.perf_counter(); decompress_file(g,out); dt=time.perf_counter()-t
    orig=os.path.getsize(a.input); comp=os.path.getsize(g)
    print(f"Original: {orig}")
    print(f"Compressed: {comp}")
    print(f"Ratio: {comp/orig if orig else 0:.4f}")
    print(f"Compression time: {ct:.3f}s")
    print(f"Decompression time: {dt:.3f}s")
